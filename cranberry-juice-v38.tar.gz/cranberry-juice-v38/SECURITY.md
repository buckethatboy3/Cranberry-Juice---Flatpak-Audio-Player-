# Cranberry Juice — Security & Privacy

Cranberry Juice is designed to be a **local-first, offline** music player. This
document describes its security posture as of v34. v31–v33 added only local UI (a
welcome tour, the Just Peachy and Grimace themes, a Cairo-drawn click effect, and
album/song metadata + art editing — all of which write only to the app's own
library cache and art folder, never to your audio files). **v34 adds CD ripping**
(Tools → Burn CD to Library): it reads an audio disc and writes the imported FLAC
tracks into your Music library. That is the first feature that writes audio files,
and under Flatpak it needs two extra permissions — see the sandbox table below.

## Network: nothing leaves your machine without your token

- The app has **exactly one** piece of network code: the optional **Discogs**
  integration (`src/Discogs.vala`).
- It makes **zero** network connections unless **both** are true: Discogs is
  **enabled** in Settings **and** you have entered a **personal API token**.
  Every request path first checks `Discogs.available()`
  (`discogs_enabled == true && discogs_token != ""`); with no token, no socket is
  ever opened.
- There is **no telemetry, no analytics, no update check, no "phone home."**
  Audio is played from local `file://` paths only — playback never touches the
  network.
- Discogs requests are **HTTPS only**. Artist images are downloaded only from
  `https://` URLs (an `http://` URL in a response is rejected — no downgrade).
- Responses are **size-capped** (4 MB for API JSON, 12 MB for images) to guard
  against a malicious or oversized response exhausting memory.
- Search terms are URL-escaped (`Uri.escape_string`) before being placed in a
  request, so they cannot alter the request structure.

## Flatpak sandbox (least privilege)

The Flatpak manifest requests the minimum it needs:

| Permission | Why |
|---|---|
| `--filesystem=home:ro` | Read music from anywhere in your home (read-only). The app's own settings/cache live in its private Flatpak data dir. |
| `--filesystem=xdg-music:create` | **CD ripping only** — read-write to your standard **Music** folder so imported tracks can be saved there. The rest of home stays read-only. |
| `--device=all` | **CD ripping only** — read the optical drive. Flatpak has no narrower optical-device permission, so this grants device access; it is used solely to read audio CDs. |
| `--share=network` | Only so the **optional** Discogs feature *can* connect. No traffic flows without your token (see above). |
| `--socket=wayland` / `--socket=fallback-x11` / `--device=dri` | Display + GPU rendering. |
| `--socket=pulseaudio` | Audio output. |
| `--own-name=org.mpris.MediaPlayer2.cranberryjuice` | The sound-indicator (MPRIS) integration. |
| `--share=ipc` | Shared-memory rendering. |

The app does **not** request: arbitrary host filesystem read-write (writes are
limited to its private data dir and — for CD ripping — your Music folder), the
session bus beyond its own MPRIS name, or the ability to talk to other apps.

## Code-level notes

- **No shell or process execution** with user/file data — there is no
  `Process.spawn`, `system()`, or similar, so there is no command-injection
  surface. "Show in Files" uses the safe `Gtk.FileLauncher` portal. (The bundled
  uninstaller — `uninstall.sh`, and the `cranberry-juice-purge` helper that the
  menu's Uninstall action runs via pkexec — is separate packaging, not the running
  app. It executes only when you choose to uninstall, and removes only Cranberry
  Juice's own files.)
- **No dynamic code / eval / plugin loading.**
- Written in **Vala** (ref-counted, memory-managed) — no manual `malloc`/`free`.
- Album art and Discogs images are decoded by the system `gdk-pixbuf`; JSON by
  `json-glib`. Both are standard, well-tested parsers.
- **CD ripping** builds GStreamer pipeline strings (e.g. `cdparanoiasrc … ! flacenc
  ! filesink`) via `Gst.parse_launch` — GStreamer's own pipeline parser, **not a
  shell**. File names and tag values are sanitised before use, and the only thing
  written is FLAC files inside your chosen Music folder.

## Known trade-offs

- The Discogs **token is stored in plaintext** in your own config file
  (`settings.conf`, readable only by your user). This matches how many desktop
  apps store API tokens. A future option could move it to the system keyring
  (libsecret). The token is a *personal, read-only* Discogs token.

## Reporting

This is a personal project. If you spot a security issue, note it for the next
build.
