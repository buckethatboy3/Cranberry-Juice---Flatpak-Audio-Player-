#!/usr/bin/env bash
#
# Build (if needed) and run Cranberry Juice straight from this folder, without
# installing it system-wide. Handy for trying it out or development.
#
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

if [ ! -d build ]; then
  meson setup build
fi
ninja -C build
exec ./build/io.github.cranberry.juice
