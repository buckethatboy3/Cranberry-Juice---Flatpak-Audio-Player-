#!/usr/bin/env bash
#
# Remove Cranberry Juice from this computer — both the Flatpak and the native
# (/usr) build, in one go. Run it from a terminal:
#
#     ./uninstall.sh
#
# It will ask before deleting your settings/library cache.
#
set -u
APP=io.github.cranberry.juice
bold() { printf "\033[1m%s\033[0m\n" "$1"; }

bold "Removing Cranberry Juice…"

# --- Flatpak: your own (user) scope, then system scope ---
flatpak uninstall -y "$APP" 2>/dev/null || true
flatpak uninstall --user -y "$APP" 2>/dev/null || true
sudo flatpak uninstall --system -y "$APP" 2>/dev/null || true

# --- Native (/usr) build — needs your password ---
if command -v "$APP" >/dev/null 2>&1 || [ -e "/usr/bin/$APP" ]; then
  bold "Removing the native install from /usr (you may be asked for your password)…"
  sudo rm -f "/usr/bin/$APP" \
             "/usr/share/applications/$APP.desktop" \
             "/usr/share/metainfo/$APP.metainfo.xml" \
             "/usr/share/icons/hicolor/128x128/apps/$APP.png" \
             "/usr/bin/cranberry-juice-purge"
  sudo update-desktop-database /usr/share/applications 2>/dev/null || true
  sudo gtk-update-icon-cache /usr/share/icons/hicolor 2>/dev/null || true
fi

echo
read -r -p "Also delete your settings and library cache (~/.config/cranberry-juice)? [y/N] " ans
case "$ans" in
  y|Y) rm -rf "$HOME/.config/cranberry-juice"; echo "Settings removed." ;;
  *)   echo "Keeping your settings." ;;
esac

echo
bold "Done — Cranberry Juice has been removed."
