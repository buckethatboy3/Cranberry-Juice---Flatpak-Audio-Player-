/*
 * A single song. GObject so it can live in a GLib.ListStore and feed a
 * Gtk.ColumnView directly.
 */

public class CranberryJuice.Track : GLib.Object {
    public string path { get; set; default = ""; }
    public string uri { get; set; default = ""; }
    public string title { get; set; default = ""; }
    public string artist { get; set; default = "Unknown Artist"; }
    public string album_artist { get; set; default = "Unknown Artist"; }
    public string album { get; set; default = "Unknown Album"; }
    public string genre { get; set; default = ""; }
    public string composer { get; set; default = ""; }
    public int year { get; set; default = 0; }
    public int track_no { get; set; default = 0; }
    public int64 duration { get; set; default = 0; }   // seconds
    public string album_key { get; set; default = ""; }

    public string duration_str () {
        int mins = (int) (duration / 60);
        int secs = (int) (duration % 60);
        return "%d:%02d".printf (mins, secs);
    }
}
