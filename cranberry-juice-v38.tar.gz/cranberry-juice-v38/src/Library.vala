/*
 * Scans a folder for audio files, reads tags + embedded artwork via the
 * GStreamer discoverer (no extra tag library needed), and exposes the result
 * as a GLib.ListStore of Track objects. Scanning runs on a worker thread;
 * results are marshalled back to the main loop.
 */

public class CranberryJuice.Library : GLib.Object {

    public GLib.ListStore store;                       // of Track
    private GLib.HashTable<string, Bytes> art_cache;   // album_key -> image bytes
    private GLib.HashTable<string, Gdk.Texture> tex_cache; // "album_key@size" -> decoded texture
    private GLib.HashTable<string, bool>? scan_seen = null; // albums whose art we already grabbed (worker thread only)
    private bool scanning = false;
    private string cache_file;
    private string art_dir;
    private string last_folder = "";   // remembered so edits can re-save the cache

    public signal void scan_started (uint total);
    public signal void scan_progress (uint done, uint total);
    public signal void scan_finished (uint count);

    construct {
        store = new GLib.ListStore (typeof (Track));
        art_cache = new GLib.HashTable<string, Bytes> (str_hash, str_equal);
        tex_cache = new GLib.HashTable<string, Gdk.Texture> (str_hash, str_equal);
        var cdir = Path.build_filename (Environment.get_user_config_dir (), "cranberry-juice");
        DirUtils.create_with_parents (cdir, 0755);
        cache_file = Path.build_filename (cdir, "library.tsv");
        art_dir = Path.build_filename (cdir, "art");
        DirUtils.create_with_parents (art_dir, 0755);
    }

    public Bytes? get_art (string album_key) {
        return art_cache.lookup (album_key);
    }

    // A file:// URL to the cached cover, for the MPRIS metadata (sound indicator).
    public string? art_url (string album_key) {
        if (album_key == "") return null;
        var p = art_path (album_key);
        if (!FileUtils.test (p, FileTest.EXISTS)) return null;
        return File.new_for_path (p).get_uri ();
    }

    // Store fetched artwork (e.g. a Discogs artist photo) under any key.
    public void put_art (string key, Bytes bytes) {
        if (key == "") return;
        art_cache.insert (key, bytes);
        tex_cache.remove ("%s@88".printf (key));
        write_art_file (key, bytes);
    }

    // Replace the artwork stored under `key` (an album_key, or "track:<path>" for
    // a single song) with a user-picked image, clearing every cached texture size
    // for that key so all views redraw with the new art.
    public void set_art (string key, Bytes bytes) {
        if (key == "") return;
        art_cache.insert (key, bytes);
        clear_tex_for (key);
        write_art_file (key, bytes);
    }

    private void clear_tex_for (string key) {
        string[] doomed = {};
        tex_cache.foreach ((k, v) => { if (k.has_prefix (key + "@")) doomed += k; });
        foreach (var dk in doomed) tex_cache.remove (dk);
    }

    // Texture for a track: a per-song override ("track:<path>") wins over the
    // album cover, so a single song can carry its own art.
    public Gdk.Texture? get_texture_for_track (Track t, int size) {
        var tex = get_texture ("track:" + t.path, size);
        return tex != null ? tex : get_texture (t.album_key, size);
    }

    // Artist photos are cached under an "artist:<name>" key.
    public Gdk.Texture? get_artist_texture (string artist, int size) {
        if (artist == "" || artist == "Unknown Artist") return null;
        return get_texture ("artist:" + artist, size);
    }
    public bool has_artist_art (string artist) {
        if (artist == "" || artist == "Unknown Artist") return false;
        string k = "artist:" + artist;
        if (art_cache.contains (k)) return true;
        return FileUtils.test (art_path (k), FileTest.EXISTS);
    }

    // Decoded, size-keyed texture cache so artwork isn't re-decoded on every view.
    public Gdk.Texture? get_texture (string album_key, int size) {
        if (album_key == "") return null;
        string k = "%s@%d".printf (album_key, size);
        var cached = tex_cache.lookup (k);
        if (cached != null) return cached;
        Bytes? bytes = art_cache.lookup (album_key);
        if (bytes == null) bytes = read_art_file (album_key);   // from a previous session
        if (bytes == null) return null;
        var tex = texture_from_bytes (bytes, size);
        if (tex != null) tex_cache.insert (k, tex);
        return tex;
    }

    private string art_path (string key) {
        var hash = Checksum.compute_for_string (ChecksumType.MD5, key);
        return Path.build_filename (art_dir, hash + ".img");
    }

    private Bytes? read_art_file (string album_key) {
        var f = File.new_for_path (art_path (album_key));
        try {
            uint8[] data;
            string etag;
            f.load_contents (null, out data, out etag);
            return new Bytes (data);
        } catch (Error e) {
            return null;
        }
    }

    private void write_art_file (string key, Bytes bytes) {
        try {
            var f = File.new_for_path (art_path (key));
            string etag;
            f.replace_contents (bytes.get_data (), null, false,
                FileCreateFlags.REPLACE_DESTINATION, out etag);
        } catch (Error e) { /* best effort */ }
    }

    private string esc (string s) {
        return s.replace ("\t", " ").replace ("\n", " ");
    }

    // The album grouping key. Albums live in one folder, so we group by the
    // track's folder + album name. That keeps every song of a collaboration
    // album together even when each track has a different track-artist (which
    // used to split one album into many). The 0x1F byte can't appear in a folder
    // path or album name, so it is a safe separator.
    public static string album_key_for (string path, string album) {
        return Path.get_dirname (path) + "\x1f" + album;
    }

    private void save_library_cache (string folder) {
        var sb = new StringBuilder ();
        sb.append (folder);
        sb.append_c ('\n');
        uint n = store.get_n_items ();
        for (uint i = 0; i < n; i++) {
            var t = (Track) store.get_item (i);
            string[] fields = {
                esc (t.path), esc (t.title), esc (t.artist), esc (t.album_artist),
                esc (t.album), esc (t.genre), esc (t.composer),
                t.year.to_string (), t.track_no.to_string (), t.duration.to_string (), esc (t.album_key)
            };
            sb.append (string.joinv ("\t", fields));
            sb.append_c ('\n');
        }
        try { FileUtils.set_contents (cache_file, sb.str); } catch (Error e) { }
    }

    // Re-write the library cache after an in-app metadata edit, so the change
    // persists across restarts (until the next folder rescan re-reads file tags).
    public void save_now () {
        save_library_cache (last_folder);
    }

    // Load the previous scan from disk so we don't re-scan on every launch.
    public bool load_cache () {
        string contents;
        try {
            if (!FileUtils.get_contents (cache_file, out contents)) return false;
        } catch (Error e) {
            return false;
        }
        var lines = contents.split ("\n");
        if (lines.length > 0) last_folder = lines[0];
        GLib.Object[] batch = {};
        for (int i = 1; i < lines.length; i++) {   // line 0 = the scanned folder
            if (lines[i] == "") continue;
            var f = lines[i].split ("\t");
            if (f.length < 11) continue;
            var t = new Track ();
            t.path = f[0];
            t.title = f[1];
            t.artist = f[2];
            t.album_artist = f[3];
            t.album = f[4];
            t.genre = f[5];
            t.composer = f[6];
            t.year = int.parse (f[7]);
            t.track_no = int.parse (f[8]);
            t.duration = int64.parse (f[9]);
            t.album_key = album_key_for (f[0], f[4]);   // re-derive: folder + album
            t.uri = File.new_for_path (t.path).get_uri ();
            batch += (GLib.Object) t;
        }
        if (batch.length == 0) return false;
        store.remove_all ();
        store.splice (0, 0, batch);
        return true;
    }

    public void scan (string folder) {
        if (scanning) return;
        last_folder = folder;
        scanning = true;
        store.remove_all ();
        art_cache.remove_all ();
        tex_cache.remove_all ();

        new Thread<void*> ("cj-scan", () => {
            scan_seen = new GLib.HashTable<string, bool> (str_hash, str_equal);
            var files = new GenericArray<string> ();
            collect_files (File.new_for_path (folder), files);
            uint total = files.length;
            Idle.add (() => { scan_started (total); return false; });

            var disco = make_discoverer ();
            uint done = 0;
            GLib.Object[] batch = {};
            for (uint i = 0; i < files.length; i++) {
                Track? t = parse_file (disco, files[i]);
                done++;
                if (t != null) batch += (GLib.Object) t;
                // Flush in chunks so the UI updates once per batch, not per track.
                if (batch.length >= 60 || done == total) {
                    var chunk = batch;
                    batch = {};
                    uint d = done;
                    Idle.add (() => {
                        if (chunk.length > 0) store.splice (store.get_n_items (), 0, chunk);
                        scan_progress (d, total);
                        return false;
                    });
                }
            }
            Idle.add (() => {
                scanning = false;
                save_library_cache (folder);
                scan_finished (total);
                return false;
            });
            return null;
        });
    }

    private Gst.PbUtils.Discoverer? make_discoverer () {
        try { return new Gst.PbUtils.Discoverer (5 * Gst.SECOND); }
        catch (Error e) { return null; }
    }

    private void collect_files (File dir, GenericArray<string> acc) {
        try {
            var en = dir.enumerate_children (
                "standard::name,standard::type",
                FileQueryInfoFlags.NOFOLLOW_SYMLINKS);
            FileInfo info;
            while ((info = en.next_file ()) != null) {
                var name = info.get_name ();
                if (name.has_prefix (".")) continue;
                var child = dir.get_child (name);
                if (info.get_file_type () == FileType.DIRECTORY) {
                    collect_files (child, acc);
                } else if (is_audio (name)) {
                    var p = child.get_path (); if (p != null) acc.add (p);
                }
            }
        } catch (Error e) {
            // Unreadable directory — skip.
        }
    }

    private bool is_audio (string name) {
        string l = name.down ();
        return l.has_suffix (".mp3") || l.has_suffix (".m4a") || l.has_suffix (".m4b") ||
               l.has_suffix (".aac") || l.has_suffix (".flac") || l.has_suffix (".ogg") ||
               l.has_suffix (".oga") || l.has_suffix (".opus") || l.has_suffix (".wav") ||
               l.has_suffix (".wma") || l.has_suffix (".aiff") || l.has_suffix (".aif");
    }

    private Track? parse_file (Gst.PbUtils.Discoverer? disco, string fpath) {
        var t = new Track ();
        t.path = fpath;
        t.uri = File.new_for_path (fpath).get_uri ();
        t.title = strip_ext (Path.get_basename (fpath));

        if (disco == null) return t;
        try {
            var info = disco.discover_uri (t.uri);
            t.duration = (int64) (info.get_duration () / Gst.SECOND);

            unowned Gst.TagList? tags = info.get_tags ();
            if (tags != null) {
                string s;
                if (tags.get_string (Gst.Tags.TITLE, out s)) t.title = s;
                if (tags.get_string (Gst.Tags.ARTIST, out s)) t.artist = s;
                // Prefer a real album-artist tag — compilations / collaborations
                // set this to the shared album artist; fall back to the track artist.
                string aa;
                if (tags.get_string ("album-artist", out aa) && aa != "") t.album_artist = aa;
                else t.album_artist = t.artist;
                if (tags.get_string (Gst.Tags.ALBUM, out s)) t.album = s;
                if (tags.get_string (Gst.Tags.GENRE, out s)) t.genre = s;
                if (tags.get_string (Gst.Tags.COMPOSER, out s)) t.composer = s;

                uint tn;
                if (tags.get_uint (Gst.Tags.TRACK_NUMBER, out tn)) t.track_no = (int) tn;

                Gst.DateTime dt;
                if (tags.get_date_time (Gst.Tags.DATE_TIME, out dt) && dt.has_year ()) {
                    t.year = dt.get_year ();
                }

                t.album_key = album_key_for (t.path, t.album);
                extract_art (tags, t.album_key);
            }
        } catch (Error e) {
            // Undiscoverable — keep filename-based defaults.
        }
        if (t.album_key == "") t.album_key = album_key_for (t.path, t.album);
        return t;
    }

    private void extract_art (Gst.TagList tags, string key) {
        // Only pull artwork once per album (huge speedup on big libraries).
        if (scan_seen != null) {
            if (scan_seen.contains (key)) return;
            scan_seen.insert (key, true);
        }
        Gst.Sample sample;
        if (!tags.get_sample (Gst.Tags.IMAGE, out sample) &&
            !tags.get_sample (Gst.Tags.PREVIEW_IMAGE, out sample)) {
            return;
        }
        var buf = sample.get_buffer ();
        if (buf == null) return;
        Gst.MapInfo map;
        if (buf.map (out map, Gst.MapFlags.READ)) {
            var bytes = new Bytes (map.data);   // copies, safe after unmap
            buf.unmap (map);
            var k = key;
            var b = bytes;
            // Insert on the main thread to keep the hash table single-threaded.
            Idle.add (() => {
                if (!art_cache.contains (k)) art_cache.insert (k, b);
                return false;
            });
            // Persist to disk (worker thread) so next launch needs no re-scan.
            write_art_file (key, bytes);
        }
    }

    private string strip_ext (string name) {
        int dot = name.last_index_of_char ('.');
        return dot > 0 ? name.substring (0, dot) : name;
    }

    // Build a square texture from cached album art, or null if none.
    public static Gdk.Texture? texture_from_bytes (Bytes? bytes, int size) {
        if (bytes == null) return null;
        try {
            var loader = new Gdk.PixbufLoader ();
            loader.set_size (size, size);
            loader.write (bytes.get_data ());
            loader.close ();
            var pix = loader.get_pixbuf ();
            return pix != null ? Gdk.Texture.for_pixbuf (pix) : null;
        } catch (Error e) {
            return null;
        }
    }
}
