/*
 * Optional Discogs (https://www.discogs.com) integration: fetch artist photos
 * and genre/style tags. All network work happens on a worker thread and is
 * delivered back on the main loop; everything is gated behind the user's
 * "enable" toggle + personal API token (Settings → Discogs).
 *
 * Uses libsoup-3 for HTTP and json-glib for parsing.
 */

public class CranberryJuice.Discogs : GLib.Object {

    private const string API = "https://api.discogs.com";   // HTTPS only
    private const string UA = "CranberryJuice/1.0 +https://github.com/cranberry-juice";
    private const int64 MAX_JSON = 4 * 1024 * 1024;     // 4 MB — reject oversized API responses
    private const int64 MAX_IMG  = 12 * 1024 * 1024;    // 12 MB — reject oversized images

    public delegate void ImageReady (Bytes? bytes);
    public delegate void StylesReady (string[] styles);

    public bool available () {
        return Application.settings.get_flag ("discogs_enabled", false)
            && Application.settings.get_str ("discogs_token", "") != "";
    }

    private string token () {
        return Application.settings.get_str ("discogs_token", "");
    }

    // Fetch an artist photo. Result bytes (or null) are delivered on the main loop.
    public void fetch_artist_image (string artist, owned ImageReady cb) {
        if (!available () || artist == "" || artist == "Unknown Artist") { cb (null); return; }
        string tk = token ();
        string who = artist;
        new Thread<void*> ("cj-discogs-img", () => {
            Bytes? result = blocking_artist_image (who, tk);
            Idle.add (() => { cb (result); return false; });
            return null;
        });
    }

    // Fetch genre + style tags for a release (artist + album). For smart playlists.
    public void fetch_styles (string artist, string album, owned StylesReady cb) {
        if (!available ()) { cb (new string[0]); return; }
        string tk = token ();
        string a = artist, al = album;
        new Thread<void*> ("cj-discogs-sty", () => {
            string[] s = blocking_styles (a, al, tk);
            Idle.add (() => { cb (s); return false; });
            return null;
        });
    }

    // ---- worker-thread helpers (synchronous libsoup) ----

    private Bytes? blocking_artist_image (string artist, string tk) {
        try {
            var session = new Soup.Session ();
            session.user_agent = UA;

            string url = "%s/database/search?type=artist&per_page=1&q=%s"
                .printf (API, Uri.escape_string (artist, null, false));
            var msg = new Soup.Message ("GET", url);
            msg.request_headers.append ("Authorization", "Discogs token=" + tk);
            var body = session.send_and_read (msg, null);
            if (body == null || body.get_size () > MAX_JSON) return null;

            var parser = new Json.Parser ();
            parser.load_from_data ((string) body.get_data (), (ssize_t) body.get_size ());
            var root = parser.get_root ();
            if (root == null) return null;
            var obj = root.get_object ();
            if (obj == null || !obj.has_member ("results")) return null;
            var results = obj.get_array_member ("results");
            if (results == null || results.get_length () == 0) return null;

            var first = results.get_object_element (0);
            string img = "";
            if (first.has_member ("cover_image")) img = first.get_string_member ("cover_image");
            else if (first.has_member ("thumb")) img = first.get_string_member ("thumb");
            // Only download over HTTPS (no downgrade / off-host fetch).
            if (!img.has_prefix ("https://")) return null;

            var imsg = new Soup.Message ("GET", img);
            imsg.request_headers.append ("Authorization", "Discogs token=" + tk);
            var ibody = session.send_and_read (imsg, null);
            if (ibody == null || ibody.get_size () > MAX_IMG) return null;
            return ibody;
        } catch (Error e) {
            return null;
        }
    }

    private string[] blocking_styles (string artist, string album, string tk) {
        string[] tags = {};
        try {
            var session = new Soup.Session ();
            session.user_agent = UA;
            string q = Uri.escape_string (artist + " " + album, null, false);
            string url = "%s/database/search?type=release&per_page=1&q=%s".printf (API, q);
            var msg = new Soup.Message ("GET", url);
            msg.request_headers.append ("Authorization", "Discogs token=" + tk);
            var body = session.send_and_read (msg, null);
            if (body == null || body.get_size () > MAX_JSON) return tags;

            var parser = new Json.Parser ();
            parser.load_from_data ((string) body.get_data (), (ssize_t) body.get_size ());
            var root = parser.get_root ();
            if (root == null) return tags;
            var obj = root.get_object ();
            if (obj == null || !obj.has_member ("results")) return tags;
            var results = obj.get_array_member ("results");
            if (results == null || results.get_length () == 0) return tags;

            var first = results.get_object_element (0);
            if (first.has_member ("style")) {
                var arr = first.get_array_member ("style");
                for (uint i = 0; i < arr.get_length (); i++) tags += arr.get_string_element (i);
            }
            if (first.has_member ("genre")) {
                var arr = first.get_array_member ("genre");
                for (uint i = 0; i < arr.get_length (); i++) tags += arr.get_string_element (i);
            }
        } catch (Error e) {
            // best effort
        }
        return tags;
    }
}
