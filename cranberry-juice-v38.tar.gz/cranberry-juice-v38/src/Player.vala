/*
 * Audio playback via a GStreamer playbin, with a "spectrum" element inserted
 * as the audio filter so the visualizer can react to the frequency bands.
 * Queue / shuffle / repeat logic lives in MainWindow; this class just plays a
 * URI and reports state, position, end-of-stream, and spectrum data.
 */

public class CranberryJuice.Player : GLib.Object {

    public Gst.Element playbin;
    private Gst.Element? spectrum;

    public signal void spectrum_update (float[] magnitudes, float threshold);
    public signal void position_changed (int64 pos_sec, int64 dur_sec);
    public signal void playing_changed (bool playing);
    public signal void track_finished ();

    public bool is_playing { get; private set; default = false; }

    private const float THRESHOLD = -70.0f;
    private const int BANDS = 128;

    construct {
        playbin = Gst.ElementFactory.make ("playbin", "cj-playbin");

        spectrum = Gst.ElementFactory.make ("spectrum", "cj-spectrum");
        if (spectrum != null) {
            spectrum.set ("bands", BANDS);
            spectrum.set ("threshold", (int) THRESHOLD);
            spectrum.set ("interval", (uint64) 30000000);   // 30 ms
            spectrum.set ("post-messages", true);
            spectrum.set ("message-magnitude", true);
            playbin.set ("audio-filter", spectrum);
        }

        var bus = playbin.get_bus ();
        bus.add_signal_watch ();
        bus.message.connect (on_bus_message);

        Timeout.add (250, () => {
            if (is_playing) query_position ();
            return true;
        });
    }

    public void load_and_play (string uri) {
        playbin.set_state (Gst.State.NULL);
        playbin.set ("uri", uri);
        playbin.set_state (Gst.State.PLAYING);
        set_playing (true);
    }

    public void toggle () {
        if (is_playing) pause ();
        else resume ();
    }

    public void resume () { playbin.set_state (Gst.State.PLAYING); set_playing (true); }
    public void pause ()  { playbin.set_state (Gst.State.PAUSED); set_playing (false); }
    public void stop ()   { playbin.set_state (Gst.State.NULL); set_playing (false); }

    public void set_volume (double v) { playbin.set ("volume", v); }

    public void seek_fraction (double frac) {
        int64 dur;
        if (playbin.query_duration (Gst.Format.TIME, out dur) && dur > 0) {
            int64 target = (int64) (frac * dur);
            playbin.seek_simple (Gst.Format.TIME,
                Gst.SeekFlags.FLUSH | Gst.SeekFlags.KEY_UNIT, target);
        }
    }

    private void set_playing (bool p) {
        if (is_playing != p) {
            is_playing = p;
            playing_changed (p);
        }
    }

    private void query_position () {
        int64 pos = 0;
        int64 dur = 0;
        if (playbin.query_position (Gst.Format.TIME, out pos) &&
            playbin.query_duration (Gst.Format.TIME, out dur)) {
            position_changed (pos, dur);   // nanoseconds — the UI interpolates for smoothness
        }
    }

    private void on_bus_message (Gst.Message message) {
        switch (message.type) {
            case Gst.MessageType.EOS:
                set_playing (false);
                track_finished ();
                break;

            case Gst.MessageType.ELEMENT:
                unowned Gst.Structure? st = message.get_structure ();
                if (st != null && st.get_name () == "spectrum") {
                    unowned GLib.Value? val = st.get_value ("magnitude");
                    if (val != null) {
                        uint n = Gst.ValueList.get_size (val);
                        float[] mags = new float[n];
                        for (uint i = 0; i < n; i++) {
                            unowned GLib.Value v = Gst.ValueList.get_value (val, i);
                            mags[i] = (float) v.get_float ();
                        }
                        spectrum_update (mags, THRESHOLD);
                    }
                }
                break;

            case Gst.MessageType.ERROR:
                Error err;
                string dbg;
                message.parse_error (out err, out dbg);
                warning ("GStreamer error: %s", err.message);
                set_playing (false);
                break;

            default:
                break;
        }
    }
}
