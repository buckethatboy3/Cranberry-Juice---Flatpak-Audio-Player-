/*
 * Audio-reactive visuals — a fullscreen-capable window that renders Cairo
 * graphics driven by the GStreamer spectrum data from Player. Each visual is a
 * draw_* method dispatched by index; a trail surface persists between frames so
 * motion-blur effects work.
 */

public class CranberryJuice.Visualizer : Gtk.Window {

    private const double TAU = 6.283185307179586;
    private const int CAP = 700;

    private Player player;
    private Gtk.DrawingArea area;
    private Cairo.ImageSurface? surface = null;
    private int sw = 0;
    private int sh = 0;
    private int64 last_us = 0;

    // analysis
    private double[] bands = new double[64];
    private double bass = 0;
    private double mid = 0;
    private double treble = 0;
    private double level = 0;
    private double beat = 0;
    private double bass_avg = 0;
    private double hue = 0;
    private double clock = 0;
    private double auto_peak = 0.20;   // CAVA-style auto-sensitivity (running peak)
    private int fw_cooldown = 0;       // fireworks: frames until the next launch is allowed
    private double fw_last = 0;

    // particle pools (interpretation varies per visual)
    private double[] ax;
    private double[] ay;
    private double[] avx;
    private double[] avy;
    private double[] alife;
    private double[] ahue;
    private double[] ar;
    private double[] aang;
    private double[] asp;
    private int pcount = 0;
    private bool pinit = false;

    private int current = 0;
    private bool auto_cycle = false;
    private double cycle_at = 0;
    private bool is_full = false;

    private Gtk.Label name_label;
    private Gtk.Label group_label;
    private Gtk.Button auto_button;
    private Gtk.ScrolledWindow gallery;

    private const string[] VNAMES = {
        "Magnetosphere", "Supernova", "Plasma Drift", "Lava Lamp", "Aurora", "Jelly",
        "Spectrum Bars", "Mirror Bars", "Radial Spectrum", "Oscilloscope", "Liquid Bands",
        "Tunnel", "Sunburst", "Pulse Rings", "Vortex", "Neon Horizon",
        "Warp Stars", "Galaxy", "Fireworks"
    };
    private const string[] VGROUPS = {
        "Classic", "Classic", "Classic", "Classic", "Classic", "Classic",
        "Spectrum", "Spectrum", "Spectrum", "Spectrum", "Spectrum",
        "Geometry", "Geometry", "Geometry", "Geometry", "Geometry",
        "Particles", "Particles", "Particles"
    };
    private const string[] VC1 = {
        "#7b2ff7", "#ff6a00", "#00c6ff", "#ff512f", "#43e97b", "#f953c6",
        "#fa2d4b", "#11998e", "#f857a6", "#00f2fe", "#4776e6",
        "#00dbde", "#f7971e", "#ff0099", "#5f2c82", "#ff2079",
        "#000428", "#41295a", "#f12711"
    };
    private const string[] VC2 = {
        "#f72f8f", "#ffd200", "#ff00cc", "#dd2476", "#38f9d7", "#b91d73",
        "#ff8a3c", "#38ef7d", "#ff5858", "#4facfe", "#8e54e9",
        "#fc00ff", "#ffd200", "#493240", "#49a09d", "#7a04eb",
        "#004e92", "#2F0743", "#f5af19"
    };

    public Visualizer (Player player) {
        Object (title: "Audio-reactive visuals");
        this.player = player;
        // MUST connect here, NOT in construct{} — construct runs during Object()
        // above, before this.player is assigned, so there it would bind to null
        // and the visuals would never receive any audio spectrum data.
        player.spectrum_update.connect (on_spectrum);
    }

    construct {
        default_width = 1100;
        default_height = 700;
        add_css_class ("viz-window");

        ax = new double[CAP]; ay = new double[CAP];
        avx = new double[CAP]; avy = new double[CAP];
        alife = new double[CAP]; ahue = new double[CAP];
        ar = new double[CAP]; aang = new double[CAP]; asp = new double[CAP];

        area = new Gtk.DrawingArea ();
        area.hexpand = true;
        area.vexpand = true;
        area.set_draw_func ((da, cr, w, h) => {
            if (surface != null) {
                cr.set_source_surface (surface, 0, 0);
                cr.paint ();
            }
        });
        area.resize.connect ((w, h) => ensure_surface (w, h));

        var overlay = new Gtk.Overlay ();
        overlay.set_child (area);

        // top control bar
        name_label = new Gtk.Label (VNAMES[0]);
        name_label.add_css_class ("viz-name");
        name_label.halign = Gtk.Align.START;
        group_label = new Gtk.Label (VGROUPS[0]);
        group_label.add_css_class ("viz-group");
        group_label.halign = Gtk.Align.START;
        var labels = new Gtk.Box (Gtk.Orientation.VERTICAL, 0);
        labels.append (name_label);
        labels.append (group_label);

        auto_button = icon_button ("media-playlist-repeat-symbolic");
        auto_button.tooltip_text = "Auto-cycle (A)";
        auto_button.clicked.connect (toggle_auto);
        var gallery_button = icon_button ("view-grid-symbolic");
        gallery_button.tooltip_text = "Browse visuals (G)";
        gallery_button.clicked.connect (toggle_gallery);
        var full_button = icon_button ("view-fullscreen-symbolic");
        full_button.tooltip_text = "Fullscreen (F)";
        full_button.clicked.connect (toggle_fullscreen);
        var close_button = icon_button ("window-close-symbolic");
        close_button.tooltip_text = "Close (Esc)";
        close_button.clicked.connect (() => set_visible (false));

        var actions = new Gtk.Box (Gtk.Orientation.HORIZONTAL, 8);
        actions.halign = Gtk.Align.END;
        actions.hexpand = true;
        actions.append (auto_button);
        actions.append (gallery_button);
        actions.append (full_button);
        actions.append (close_button);

        var bar = new Gtk.Box (Gtk.Orientation.HORIZONTAL, 10);
        bar.add_css_class ("viz-bar");
        bar.valign = Gtk.Align.START;
        bar.append (labels);
        bar.append (actions);
        overlay.add_overlay (bar);

        var prev_button = arrow_button ("go-previous-symbolic");
        prev_button.halign = Gtk.Align.START;
        prev_button.valign = Gtk.Align.CENTER;
        prev_button.margin_start = 18;
        prev_button.clicked.connect (() => select (current - 1));
        overlay.add_overlay (prev_button);

        var next_button = arrow_button ("go-next-symbolic");
        next_button.halign = Gtk.Align.END;
        next_button.valign = Gtk.Align.CENTER;
        next_button.margin_end = 18;
        next_button.clicked.connect (() => select (current + 1));
        overlay.add_overlay (next_button);

        gallery = build_gallery ();
        gallery.visible = false;
        overlay.add_overlay (gallery);

        set_child (overlay);

        // input
        var keys = new Gtk.EventControllerKey ();
        keys.key_pressed.connect (on_key);
        ((Gtk.Widget) this).add_controller (keys);

        area.add_tick_callback (on_tick);
    }

    public void open () {
        last_us = 0;
        present ();
    }

    private Gtk.Button icon_button (string icon) {
        var b = new Gtk.Button.from_icon_name (icon);
        b.add_css_class ("viz-button");
        return b;
    }

    private Gtk.Button arrow_button (string icon) {
        var b = new Gtk.Button.from_icon_name (icon);
        b.add_css_class ("viz-arrow");
        return b;
    }

    // ----------------------------------------------------------------- input
    private bool on_key (uint keyval, uint keycode, Gdk.ModifierType state) {
        switch (keyval) {
            case Gdk.Key.Escape:
                if (gallery.visible) gallery.visible = false;
                else set_visible (false);
                return true;
            case Gdk.Key.Left:  select (current - 1); return true;
            case Gdk.Key.Right: select (current + 1); return true;
            case Gdk.Key.f:
            case Gdk.Key.F:     toggle_fullscreen (); return true;
            case Gdk.Key.g:
            case Gdk.Key.G:     toggle_gallery (); return true;
            case Gdk.Key.a:
            case Gdk.Key.A:     toggle_auto (); return true;
            default: return false;
        }
    }

    private void toggle_fullscreen () {
        // Use the window's real state so the button and F key never desync.
        if (fullscreened) unfullscreen (); else fullscreen ();
    }

    private void toggle_auto () {
        auto_cycle = !auto_cycle;
        cycle_at = clock + 20;
        if (auto_cycle) auto_button.add_css_class ("active");
        else auto_button.remove_css_class ("active");
    }

    private void toggle_gallery () { gallery.visible = !gallery.visible; }

    private void select (int i) {
        int n = VNAMES.length;
        current = ((i % n) + n) % n;
        pinit = false;
        if (surface != null) {
            var cr = new Cairo.Context (surface);
            cr.set_source_rgb (0, 0, 0);
            cr.paint ();
        }
        name_label.label = VNAMES[current];
        group_label.label = VGROUPS[current];
    }

    // ----------------------------------------------------------------- gallery
    private Gtk.ScrolledWindow build_gallery () {
        var flow = new Gtk.FlowBox ();
        flow.selection_mode = Gtk.SelectionMode.NONE;
        flow.homogeneous = true;
        flow.max_children_per_line = 6;
        flow.margin_start = 18;
        flow.margin_end = 18;
        flow.margin_bottom = 18;

        for (int i = 0; i < VNAMES.length; i++) {
            flow.append (make_tile (i));
        }

        var title = new Gtk.Label ("Audio-reactive visuals");
        title.add_css_class ("viz-gallery-title");
        title.halign = Gtk.Align.START;

        var box = new Gtk.Box (Gtk.Orientation.VERTICAL, 0);
        box.append (title);
        box.append (flow);

        var sc = new Gtk.ScrolledWindow ();
        sc.add_css_class ("viz-gallery");
        sc.set_child (box);
        return sc;
    }

    private Gtk.Widget make_tile (int idx) {
        var art = new Gtk.DrawingArea ();
        art.set_size_request (168, 94);
        art.set_draw_func ((da, cr, w, h) => {
            double r1, g1, b1, r2, g2, b2;
            hex_rgb (VC1[idx], out r1, out g1, out b1);
            hex_rgb (VC2[idx], out r2, out g2, out b2);
            var pat = new Cairo.Pattern.linear (0, 0, w, h);
            pat.add_color_stop_rgb (0, r1, g1, b1);
            pat.add_color_stop_rgb (1, r2, g2, b2);
            cr.set_source (pat);
            rounded (cr, 0, 0, w, h, 11);
            cr.fill ();
        });

        var name = new Gtk.Label (VNAMES[idx]);
        name.add_css_class ("viz-tile-name");
        name.halign = Gtk.Align.START;
        var grp = new Gtk.Label (VGROUPS[idx]);
        grp.add_css_class ("viz-tile-group");
        grp.halign = Gtk.Align.START;

        var box = new Gtk.Box (Gtk.Orientation.VERTICAL, 2);
        box.append (art);
        box.append (name);
        box.append (grp);

        var button = new Gtk.Button ();
        button.add_css_class ("viz-tile");
        button.set_child (box);
        button.clicked.connect (() => {
            select (idx);
            gallery.visible = false;
        });
        return button;
    }

    // ----------------------------------------------------------------- engine
    private void ensure_surface (int w, int h) {
        if (w <= 0 || h <= 0) return;
        if (surface != null && sw == w && sh == h) return;
        surface = new Cairo.ImageSurface (Cairo.Format.ARGB32, w, h);
        sw = w; sh = h;
        var cr = new Cairo.Context (surface);
        cr.set_source_rgb (0, 0, 0);
        cr.paint ();
    }

    private bool on_tick (Gtk.Widget widget, Gdk.FrameClock fc) {
        int64 now = fc.get_frame_time ();
        double dt = (last_us == 0) ? 0.016 : (now - last_us) / 1000000.0;
        if (dt > 0.1) dt = 0.016;
        last_us = now;

        clock += dt;
        hue = Math.fmod (hue + dt * 11.0, 360.0);
        beat *= 0.92;

        if (auto_cycle && clock > cycle_at) {
            select ((current + 1) % VNAMES.length);
            cycle_at = clock + 20;
        }

        render ();
        area.queue_draw ();
        return true;
    }

    // Spectrum processing, sharpened with the techniques cava uses: a perceptual
    // (log-magnitude) curve, auto-sensitivity so quiet and loud tracks both fill
    // the frame, and gravity smoothing — bars jump up instantly and fall slowly.
    private void on_spectrum (float[] mags, float threshold) {
        int n = mags.length;
        if (n <= 0) return;
        if (bands.length != n) bands = new double[n];
        double inv = -threshold;

        // Pass 1: perceptual magnitude per bin + this frame's peak.
        double frame_peak = 0;
        var raw = new double[n];
        for (int i = 0; i < n; i++) {
            double v = clampd ((mags[i] - threshold) / inv, 0, 1);
            v = Math.pow (v, 0.6);
            raw[i] = v;
            if (v > frame_peak) frame_peak = v;
        }

        // Auto-sensitivity: track a running peak (snap up, decay slowly) and scale
        // toward it, with a floor so silence doesn't blow the gain up to infinity.
        if (frame_peak > auto_peak) auto_peak = frame_peak;
        else auto_peak = auto_peak * 0.9985 + frame_peak * 0.0015;
        if (auto_peak < 0.20) auto_peak = 0.20;
        double gain = 1.0 / auto_peak;

        // Pass 2: apply gain, then gravity smoothing (fast rise, slow fall).
        for (int i = 0; i < n; i++) {
            double v = clampd (raw[i] * gain, 0, 1);
            if (v >= bands[i]) bands[i] = v;                     // rise instantly
            else bands[i] = bands[i] * 0.78 + v * 0.22;          // fall slowly
        }

        bass = band (0.0, 0.08);
        mid = band (0.08, 0.40);
        treble = band (0.40, 0.90);
        level = band (0.0, 0.80);
        bass_avg = bass_avg * 0.92 + bass * 0.08;
        double hit = (bass > bass_avg * 1.10 && bass > 0.10)
            ? clampd ((bass - bass_avg) / (bass_avg + 0.001), 0, 1) : 0;
        if (hit > beat) beat = hit;
    }

    // A single display bar, cava-style: map bar i of `count` to a logarithmically
    // spaced slice of the FFT (more resolution in the bass), peak-biased so it reads
    // crisply. Used by the bar/spectrum visuals.
    private double bar (int i, int count) {
        int n = bands.length;
        if (n <= 1 || count <= 0) return 0;
        double top = n * 0.85;                       // skip the very top (mostly hiss)
        int a = (int) (Math.pow ((double) i / count, 2.0) * top);
        int b = (int) (Math.pow ((double) (i + 1) / count, 2.0) * top);
        if (b <= a) b = a + 1;
        if (b > n) b = n;
        if (a < 0) a = 0;
        double s = 0, mx = 0;
        for (int k = a; k < b; k++) { s += bands[k]; if (bands[k] > mx) mx = bands[k]; }
        return clampd (0.45 * (s / (b - a)) + 0.55 * mx, 0, 1);
    }

    private void render () {
        if (surface == null) return;
        var cr = new Cairo.Context (surface);
        int w = sw, h = sh;
        switch (current) {
            case 0:  draw_magnetosphere (cr, w, h); break;
            case 1:  draw_supernova (cr, w, h); break;
            case 2:  draw_plasma (cr, w, h); break;
            case 3:  draw_lavalamp (cr, w, h); break;
            case 4:  draw_aurora (cr, w, h); break;
            case 5:  draw_jelly (cr, w, h); break;
            case 6:  draw_bars (cr, w, h); break;
            case 7:  draw_mirror_bars (cr, w, h); break;
            case 8:  draw_radial (cr, w, h); break;
            case 9:  draw_oscilloscope (cr, w, h); break;
            case 10: draw_liquid (cr, w, h); break;
            case 11: draw_tunnel (cr, w, h); break;
            case 12: draw_sunburst (cr, w, h); break;
            case 13: draw_rings (cr, w, h); break;
            case 14: draw_vortex (cr, w, h); break;
            case 15: draw_neon (cr, w, h); break;
            case 16: draw_starfield (cr, w, h); break;
            case 17: draw_galaxy (cr, w, h); break;
            case 18: draw_fireworks (cr, w, h); break;
            default: draw_bars (cr, w, h); break;
        }
    }

    // ----------------------------------------------------------------- helpers
    private double band (double lo, double hi) {
        int n = bands.length;
        int a = (int) (lo * n);
        int b = (int) (hi * n);
        if (b <= a) b = a + 1;
        if (b > n) b = n;
        if (a < 0) a = 0;
        double s = 0;
        for (int i = a; i < b; i++) s += bands[i];
        return s / (b - a);
    }

    private static double clampd (double v, double a, double b) {
        return v < a ? a : (v > b ? b : v);
    }

    private void hsl (double h, double s, double l, out double r, out double g, out double b) {
        h = Math.fmod (h, 360.0);
        if (h < 0) h += 360.0;
        double c = (1 - Math.fabs (2 * l - 1)) * s;
        double hh = h / 60.0;
        double x = c * (1 - Math.fabs (Math.fmod (hh, 2) - 1));
        double r1 = 0, g1 = 0, b1 = 0;
        if (hh < 1) { r1 = c; g1 = x; }
        else if (hh < 2) { r1 = x; g1 = c; }
        else if (hh < 3) { g1 = c; b1 = x; }
        else if (hh < 4) { g1 = x; b1 = c; }
        else if (hh < 5) { r1 = x; b1 = c; }
        else { r1 = c; b1 = x; }
        double m = l - c / 2;
        r = r1 + m; g = g1 + m; b = b1 + m;
    }

    private void set_hsl (Cairo.Context cr, double h, double s, double l, double a) {
        double r, g, b;
        hsl (h, s / 100.0, l / 100.0, out r, out g, out b);
        cr.set_source_rgba (r, g, b, a);
    }

    private void fade (Cairo.Context cr, int w, int h, double a) {
        cr.set_operator (Cairo.Operator.OVER);
        cr.set_source_rgba (0, 0, 0, a);
        cr.rectangle (0, 0, w, h);
        cr.fill ();
    }

    private void clear_bg (Cairo.Context cr, int w, int h) {
        cr.set_operator (Cairo.Operator.OVER);
        cr.set_source_rgb (0, 0, 0);
        cr.rectangle (0, 0, w, h);
        cr.fill ();
    }

    private void rounded (Cairo.Context cr, double x, double y, double w, double h, double r) {
        cr.new_sub_path ();
        cr.arc (x + w - r, y + r, r, -Math.PI / 2, 0);
        cr.arc (x + w - r, y + h - r, r, 0, Math.PI / 2);
        cr.arc (x + r, y + h - r, r, Math.PI / 2, Math.PI);
        cr.arc (x + r, y + r, r, Math.PI, 3 * Math.PI / 2);
        cr.close_path ();
    }

    private int hexval (char c) {
        if (c >= '0' && c <= '9') return c - '0';
        if (c >= 'a' && c <= 'f') return c - 'a' + 10;
        if (c >= 'A' && c <= 'F') return c - 'A' + 10;
        return 0;
    }

    private void hex_rgb (string hex, out double r, out double g, out double b) {
        int o = hex.has_prefix ("#") ? 1 : 0;
        r = (hexval (hex[o]) * 16 + hexval (hex[o + 1])) / 255.0;
        g = (hexval (hex[o + 2]) * 16 + hexval (hex[o + 3])) / 255.0;
        b = (hexval (hex[o + 4]) * 16 + hexval (hex[o + 5])) / 255.0;
    }

    // ============================ VISUALS ============================
    private void draw_magnetosphere (Cairo.Context cr, int w, int h) {
        if (!pinit) {
            pcount = 260;
            for (int i = 0; i < pcount; i++) {
                aang[i] = Random.next_double () * TAU;
                ar[i] = 40 + Random.next_double () * 220;
                asp[i] = 0.2 + Random.next_double () * 0.8;
                ahue[i] = Random.next_double () * 360;
            }
            pinit = true;
        }
        fade (cr, w, h, 0.10);
        cr.set_operator (Cairo.Operator.ADD);
        double push = 1 + bass * 2.2 + beat * 1.5;
        double cx = w / 2.0, cy = h / 2.0;
        for (int i = 0; i < pcount; i++) {
            aang[i] += (0.003 + mid * 0.02) * asp[i];
            double wob = Math.sin (clock * asp[i] + ahue[i]) * 26;
            double r = (ar[i] + wob) * (0.55 + 0.45 * push);
            double x = cx + Math.cos (aang[i]) * r;
            double y = cy + Math.sin (aang[i]) * r * 0.82;
            double sz = 1.4 + bass * 3 + beat * 2;
            set_hsl (cr, hue + ar[i], 90, 62, 0.9);
            cr.arc (x, y, sz, 0, TAU);
            cr.fill ();
        }
        cr.set_operator (Cairo.Operator.OVER);
    }

    private void draw_supernova (Cairo.Context cr, int w, int h) {
        if (!pinit) { pcount = 0; pinit = true; }
        fade (cr, w, h, 0.12);
        double cx = w / 2.0, cy = h / 2.0;
        if (beat > 0.4 || pcount < 40) {
            int n = 18 + (int) (beat * 60);
            for (int i = 0; i < n && pcount < CAP; i++) {
                double a = Random.next_double () * TAU;
                double sp = 1 + Random.next_double () * 6 * (0.5 + beat);
                ax[pcount] = cx; ay[pcount] = cy;
                avx[pcount] = Math.cos (a) * sp; avy[pcount] = Math.sin (a) * sp;
                alife[pcount] = 1; ahue[pcount] = Math.fmod (hue + Random.next_double () * 60, 360);
                pcount++;
            }
        }
        cr.set_operator (Cairo.Operator.ADD);
        for (int i = 0; i < pcount; i++) {
            ax[i] += avx[i]; ay[i] += avy[i];
            avx[i] *= 0.985; avy[i] *= 0.985; alife[i] -= 0.012;
            if (alife[i] <= 0) { remove_particle (i); i--; continue; }
            set_hsl (cr, ahue[i], 95, 60, alife[i]);
            cr.arc (ax[i], ay[i], 1.5 + alife[i] * 2.5 + level * 2, 0, TAU);
            cr.fill ();
        }
        cr.set_operator (Cairo.Operator.OVER);
    }

    private void draw_plasma (Cairo.Context cr, int w, int h) {
        cr.set_operator (Cairo.Operator.OVER);
        int cell = 22;
        double k = 0.012 + bass * 0.02;
        for (int x = 0; x < w; x += cell) {
            for (int y = 0; y < h; y += cell) {
                double v = Math.sin (x * k + clock)
                    + Math.sin (y * k * 1.3 + clock * 1.1)
                    + Math.sin ((x + y) * k * 0.7 + clock * 0.7)
                    + Math.sin (Math.hypot (x - w / 2.0, y - h / 2.0) * k - clock);
                double hh = Math.fmod (hue + v * 50 + 360, 360);
                set_hsl (cr, hh, 80, 12 + (v + 4) / 8 * (28 + level * 30), 1.0);
                cr.rectangle (x, y, cell + 1, cell + 1);
                cr.fill ();
            }
        }
    }

    private void draw_lavalamp (Cairo.Context cr, int w, int h) {
        if (!pinit) {
            pcount = 9;
            for (int i = 0; i < pcount; i++) {
                ax[i] = Random.next_double () * w;
                ay[i] = Random.next_double () * h;
                ar[i] = 60 + Random.next_double () * 90;
                asp[i] = 0.2 + Random.next_double () * 0.6;
                ahue[i] = Random.next_double () * TAU;
            }
            pinit = true;
        }
        clear_bg (cr, w, h);
        cr.set_operator (Cairo.Operator.ADD);
        for (int i = 0; i < pcount; i++) {
            ay[i] -= asp[i] * (0.5 + mid * 2);
            if (ay[i] < -ar[i]) ay[i] = h + ar[i];
            double x = ax[i] + Math.sin (clock * asp[i] + ahue[i]) * 50;
            double r = ar[i] * (0.8 + bass * 0.6);
            double hh = Math.fmod (hue + ahue[i] * 40, 360);
            double cr1, cg1, cb1;
            hsl (hh, 0.9, 0.55, out cr1, out cg1, out cb1);
            var pat = new Cairo.Pattern.radial (x, ay[i], 0, x, ay[i], r);
            pat.add_color_stop_rgba (0, cr1, cg1, cb1, 0.9);
            pat.add_color_stop_rgba (1, cr1, cg1, cb1, 0.0);
            cr.set_source (pat);
            cr.arc (x, ay[i], r, 0, TAU);
            cr.fill ();
        }
        cr.set_operator (Cairo.Operator.OVER);
    }

    private void draw_aurora (Cairo.Context cr, int w, int h) {
        fade (cr, w, h, 0.14);
        cr.set_operator (Cairo.Operator.ADD);
        for (int layer = 0; layer < 5; layer++) {
            double amp = band (0.02 + layer * 0.04, 0.08 + layer * 0.05) * h * 0.6 + 30;
            double y_base = h * (0.3 + layer * 0.12);
            cr.move_to (0, h);
            for (int x = 0; x <= w; x += 14) {
                double y = y_base
                    + Math.sin (x * 0.006 + clock * (0.6 + layer * 0.2) + layer) * amp
                    + Math.sin (x * 0.013 - clock) * amp * 0.4;
                cr.line_to (x, y);
            }
            cr.line_to (w, h);
            cr.close_path ();
            set_hsl (cr, hue + layer * 40, 85, 55, 0.16 + level * 0.18);
            cr.fill ();
        }
        cr.set_operator (Cairo.Operator.OVER);
    }

    private void draw_jelly (Cairo.Context cr, int w, int h) {
        fade (cr, w, h, 0.12);
        cr.set_operator (Cairo.Operator.ADD);
        double cx = w / 2.0, cy = h / 2.0;
        double R = double.min (cx, cy) * (0.45 + bass * 0.4);
        bool first = true;
        for (double a = 0; a <= TAU + 0.1; a += 0.08) {
            double r = R * (1 + 0.18 * Math.sin (a * 6 + clock * 3)
                + 0.12 * Math.sin (a * 3 - clock * 2)
                + level * 0.3 * Math.sin (a * 9 + clock));
            double x = cx + Math.cos (a) * r, y = cy + Math.sin (a) * r;
            if (first) { cr.move_to (x, y); first = false; } else cr.line_to (x, y);
        }
        cr.close_path ();
        double cr1, cg1, cb1, cr2, cg2, cb2;
        hsl (hue, 0.9, 0.6, out cr1, out cg1, out cb1);
        hsl (Math.fmod (hue + 60, 360), 0.9, 0.5, out cr2, out cg2, out cb2);
        var pat = new Cairo.Pattern.radial (cx, cy, 0, cx, cy, R * 1.4);
        pat.add_color_stop_rgba (0, cr1, cg1, cb1, 0.85);
        pat.add_color_stop_rgba (1, cr2, cg2, cb2, 0.05);
        cr.set_source (pat);
        cr.fill ();
        cr.set_operator (Cairo.Operator.OVER);
    }

    private void draw_bars (Cairo.Context cr, int w, int h) {
        clear_bg (cr, w, h);
        int count = 72;
        double bw = (double) w / count;
        for (int i = 0; i < count; i++) {
            double m = bar (i, count);
            double bh = m * h * 0.92;
            set_hsl (cr, hue + i * 3, 90, 58, 1.0);
            cr.rectangle (i * bw + 1, h - bh, bw - 2, bh);
            cr.fill ();
        }
    }

    private void draw_mirror_bars (Cairo.Context cr, int w, int h) {
        fade (cr, w, h, 0.25);
        int count = 64;
        double bw = (double) w / count, cy = h / 2.0;
        for (int i = 0; i < count; i++) {
            double m = bar (i, count);
            double bh = m * h * 0.46;
            set_hsl (cr, hue + i * 4, 88, 58, 1.0);
            cr.rectangle (i * bw + 1, cy - bh, bw - 2, bh);
            cr.fill ();
            set_hsl (cr, hue + i * 4, 88, 42, 1.0);
            cr.rectangle (i * bw + 1, cy, bw - 2, bh);
            cr.fill ();
        }
    }

    private void draw_radial (Cairo.Context cr, int w, int h) {
        fade (cr, w, h, 0.2);
        double cx = w / 2.0, cy = h / 2.0;
        int count = 96;
        double base_r = double.min (cx, cy) * 0.34 * (1 + bass * 0.3);
        cr.set_line_width (3.2);
        cr.set_line_cap (Cairo.LineCap.ROUND);
        cr.save ();
        cr.translate (cx, cy);
        cr.rotate (clock * 0.1);
        for (int i = 0; i < count; i++) {
            double m = bar (i, count);
            double len = m * base_r * 1.6;
            double a = (double) i / count * TAU;
            double c = Math.cos (a), s = Math.sin (a);
            set_hsl (cr, hue + i * 4, 92, 60, 1.0);
            cr.move_to (c * base_r, s * base_r);
            cr.line_to (c * (base_r + len), s * (base_r + len));
            cr.stroke ();
        }
        cr.restore ();
    }

    private void draw_oscilloscope (Cairo.Context cr, int w, int h) {
        fade (cr, w, h, 0.18);
        cr.set_operator (Cairo.Operator.ADD);
        double cy = h / 2.0;
        double a1 = band (0.0, 0.05), a2 = band (0.05, 0.12), a3 = band (0.12, 0.30);
        cr.set_line_width (2 + level * 3);
        set_hsl (cr, hue, 95, 62, 0.9);
        bool first = true;
        for (int x = 0; x <= w; x += 3) {
            double ph = x * 0.02;
            double y = cy
                + Math.sin (ph + clock * 3) * a1 * h * 0.32
                + Math.sin (ph * 2 - clock * 2) * a2 * h * 0.2
                + Math.sin (ph * 3.3 + clock * 4) * a3 * h * 0.12;
            if (first) { cr.move_to (x, y); first = false; } else cr.line_to (x, y);
        }
        cr.stroke ();
        cr.set_operator (Cairo.Operator.OVER);
    }

    private void draw_liquid (Cairo.Context cr, int w, int h) {
        clear_bg (cr, w, h);
        cr.set_operator (Cairo.Operator.ADD);
        double[] bb = { band (0, 0.05), band (0.05, 0.15), band (0.15, 0.4) };
        for (int b = 0; b < 3; b++) {
            double amp = bb[b] * h * 0.5 + 14, y_base = h * (0.62 + b * 0.06);
            cr.move_to (0, h);
            for (int x = 0; x <= w; x += 12) {
                double y = y_base - Math.sin (x * (0.008 + b * 0.004) + clock * (1 + b * 0.5)) * amp;
                cr.line_to (x, y);
            }
            cr.line_to (w, h);
            cr.close_path ();
            set_hsl (cr, hue + b * 50, 85, 55, 0.4);
            cr.fill ();
        }
        cr.set_operator (Cairo.Operator.OVER);
    }

    private void draw_tunnel (Cairo.Context cr, int w, int h) {
        fade (cr, w, h, 0.16);
        double cx = w / 2.0, cy = h / 2.0;
        double maxR = Math.hypot (cx, cy);
        cr.set_line_width (2.5);
        for (int i = 0; i < 22; i++) {
            double f = Math.fmod (clock * (0.4 + bass) + (double) i / 22, 1.0);
            double r = f * maxR;
            set_hsl (cr, hue + i * 16, 90, 55, 1 - f);
            cr.save ();
            cr.translate (cx, cy);
            cr.rotate (clock * 0.2 + i * 0.1);
            bool first = true;
            for (int k = 0; k <= 6; k++) {
                double a = (double) k / 6 * TAU;
                double rr = r * (1 + beat * 0.1 * Math.sin (a * 3));
                double x = Math.cos (a) * rr, y = Math.sin (a) * rr;
                if (first) { cr.move_to (x, y); first = false; } else cr.line_to (x, y);
            }
            cr.close_path ();
            cr.stroke ();
            cr.restore ();
        }
    }

    private void draw_sunburst (Cairo.Context cr, int w, int h) {
        fade (cr, w, h, 0.2);
        double cx = w / 2.0, cy = h / 2.0;
        int rays = 120;
        cr.save ();
        cr.translate (cx, cy);
        cr.rotate (clock * 0.06);
        double base_r = 20 + bass * 40;
        cr.set_line_width (2);
        for (int i = 0; i < rays; i++) {
            double m = bar (i, rays);
            double len = base_r + m * double.min (cx, cy) * 1.3;
            double a = (double) i / rays * TAU;
            set_hsl (cr, hue + i * 3, 95, 58, 0.9);
            cr.move_to (0, 0);
            cr.line_to (Math.cos (a) * len, Math.sin (a) * len);
            cr.stroke ();
        }
        cr.restore ();
    }

    private void draw_rings (Cairo.Context cr, int w, int h) {
        if (!pinit) { pcount = 0; pinit = true; }
        fade (cr, w, h, 0.14);
        double cx = w / 2.0, cy = h / 2.0;
        if (beat > 0.45 && pcount < CAP) {
            ar[pcount] = 8; alife[pcount] = 1; ahue[pcount] = hue;
            asp[pcount] = 3 + beat * 6; pcount++;
        }
        cr.set_line_width (3);
        for (int i = 0; i < pcount; i++) {
            ar[i] += asp[i]; alife[i] -= 0.012;
            if (alife[i] <= 0) { remove_particle (i); i--; continue; }
            set_hsl (cr, ahue[i], 90, 60, alife[i]);
            cr.arc (cx, cy, ar[i], 0, TAU);
            cr.stroke ();
        }
    }

    private void draw_vortex (Cairo.Context cr, int w, int h) {
        fade (cr, w, h, 0.1);
        cr.set_operator (Cairo.Operator.ADD);
        double cx = w / 2.0, cy = h / 2.0;
        int arms = 400;
        double maxR = double.min (cx, cy) * 1.2;
        for (int i = 0; i < arms; i++) {
            double f = (double) i / arms;
            double a = f * TAU * 8 + clock * (1 + bass);
            double r = f * maxR * (0.6 + level * 0.6);
            double x = cx + Math.cos (a) * r, y = cy + Math.sin (a) * r;
            set_hsl (cr, hue + f * 360, 90, 60, 0.7);
            cr.arc (x, y, 1.6 + level * 2, 0, TAU);
            cr.fill ();
        }
        cr.set_operator (Cairo.Operator.OVER);
    }

    private void draw_neon (Cairo.Context cr, int w, int h) {
        clear_bg (cr, w, h);
        double hor = h * 0.55;
        var sky = new Cairo.Pattern.linear (0, 0, 0, hor);
        double r1, g1, b1, r2, g2, b2;
        hsl (Math.fmod (hue + 240, 360), 0.7, 0.10, out r1, out g1, out b1);
        hsl (Math.fmod (hue + 300, 360), 0.8, 0.22, out r2, out g2, out b2);
        sky.add_color_stop_rgb (0, r1, g1, b1);
        sky.add_color_stop_rgb (1, r2, g2, b2);
        cr.set_source (sky);
        cr.rectangle (0, 0, w, hor);
        cr.fill ();

        double sr = 80 + bass * 30;
        double sr1, sg1, sb1;
        hsl (Math.fmod (hue + 30, 360), 0.95, 0.65, out sr1, out sg1, out sb1);
        var sun = new Cairo.Pattern.radial (w / 2.0, hor - 10, 10, w / 2.0, hor - 10, sr);
        sun.add_color_stop_rgba (0, sr1, sg1, sb1, 1);
        sun.add_color_stop_rgba (1, sr1, sg1, sb1, 0);
        cr.set_source (sun);
        cr.arc (w / 2.0, hor - 10, sr, 0, TAU);
        cr.fill ();

        set_hsl (cr, Math.fmod (hue + 180, 360), 95, 60, 0.8);
        cr.set_line_width (1.5);
        for (int i = -10; i <= 10; i++) {
            cr.move_to (w / 2.0, hor);
            cr.line_to (w / 2.0 + i * w * 0.12, h);
            cr.stroke ();
        }
        double speed = Math.fmod (clock * (0.4 + level), 1.0);
        for (int i = 0; i < 14; i++) {
            double f = ((double) i + speed) / 14;
            double y = hor + f * f * (h - hor);
            cr.set_source_rgba (1, 0.2, 0.5, clampd (f * 1.5, 0, 1));
            cr.move_to (0, y);
            cr.line_to (w, y);
            cr.stroke ();
        }
    }

    private void draw_starfield (Cairo.Context cr, int w, int h) {
        if (!pinit) {
            pcount = 360;
            for (int i = 0; i < pcount; i++) {
                ax[i] = (Random.next_double () - 0.5) * w;
                ay[i] = (Random.next_double () - 0.5) * h;
                ar[i] = Random.next_double () * w;   // z
            }
            pinit = true;
        }
        fade (cr, w, h, 0.25);
        cr.set_operator (Cairo.Operator.ADD);
        double cx = w / 2.0, cy = h / 2.0;
        double sp = 4 + level * 30 + beat * 30;
        for (int i = 0; i < pcount; i++) {
            ar[i] -= sp;
            if (ar[i] <= 1) {
                ar[i] = w;
                ax[i] = (Random.next_double () - 0.5) * w;
                ay[i] = (Random.next_double () - 0.5) * h;
            }
            double k = 200 / ar[i];
            double x = cx + ax[i] * k, y = cy + ay[i] * k;
            double k2 = 200 / (ar[i] + sp);
            double px = cx + ax[i] * k2, py = cy + ay[i] * k2;
            double a = clampd (1 - ar[i] / w, 0, 1);
            set_hsl (cr, hue, 40, 90, a);
            cr.set_line_width (a * 2.2);
            cr.move_to (px, py);
            cr.line_to (x, y);
            cr.stroke ();
        }
        cr.set_operator (Cairo.Operator.OVER);
    }

    private void draw_galaxy (Cairo.Context cr, int w, int h) {
        if (!pinit) {
            pcount = 600;
            for (int i = 0; i < pcount; i++) {
                aang[i] = Random.next_double ();         // 0..1 along arm
                asp[i] = i % 3;                          // arm index
                ahue[i] = Random.next_double () * 0.3;   // offset
            }
            pinit = true;
        }
        fade (cr, w, h, 0.12);
        cr.set_operator (Cairo.Operator.ADD);
        double cx = w / 2.0, cy = h / 2.0;
        double maxR = double.min (cx, cy) * 1.15;
        for (int i = 0; i < pcount; i++) {
            double d = aang[i];
            double a = d * 6 + asp[i] * (TAU / 3) + clock * (0.3 + bass * 0.5) + ahue[i];
            double r = d * maxR * (0.7 + level * 0.4);
            double x = cx + Math.cos (a) * r, y = cy + Math.sin (a) * r;
            set_hsl (cr, hue + d * 120, 85, 65, 0.8 * (1 - d * 0.5));
            cr.arc (x, y, 1.4, 0, TAU);
            cr.fill ();
        }
        cr.set_operator (Cairo.Operator.OVER);
    }

    private void draw_fireworks (Cairo.Context cr, int w, int h) {
        if (!pinit) { pcount = 0; pinit = true; }
        fade (cr, w, h, 0.16);
        // Launch on a beat (now a much lower, reachable threshold) OR on a steady
        // music-driven cadence, so fireworks always fire while a song is playing.
        if (fw_cooldown > 0) fw_cooldown--;
        bool on_beat = beat > 0.22 && fw_cooldown == 0;
        bool on_cadence = level > 0.10 && fw_cooldown == 0 && (clock - fw_last) > 0.30;
        if (on_beat || on_cadence) {
            fw_cooldown = 5;
            fw_last = clock;
            double energy = clampd (beat + level * 0.8, 0.25, 1.4);
            double ex = Random.next_double () * w;
            double ey = h * (0.2 + Random.next_double () * 0.4);
            int n = 44 + (int) (energy * 60);
            double hh = Math.fmod (hue + Random.next_double () * 80, 360);
            for (int i = 0; i < n && pcount < CAP; i++) {
                double a = Random.next_double () * TAU;
                double sp = 1 + Random.next_double () * 5 * (0.6 + energy);
                ax[pcount] = ex; ay[pcount] = ey;
                avx[pcount] = Math.cos (a) * sp; avy[pcount] = Math.sin (a) * sp;
                alife[pcount] = 1; ahue[pcount] = hh;
                pcount++;
            }
        }
        cr.set_operator (Cairo.Operator.ADD);
        for (int i = 0; i < pcount; i++) {
            avy[i] += 0.05;
            ax[i] += avx[i]; ay[i] += avy[i]; avx[i] *= 0.99; alife[i] -= 0.014;
            if (alife[i] <= 0) { remove_particle (i); i--; continue; }
            set_hsl (cr, ahue[i], 95, 62, alife[i]);
            cr.arc (ax[i], ay[i], 1.8 * alife[i] + 0.6, 0, TAU);
            cr.fill ();
        }
        cr.set_operator (Cairo.Operator.OVER);
    }

    // swap-remove a particle from the active pool
    private void remove_particle (int i) {
        pcount--;
        ax[i] = ax[pcount]; ay[i] = ay[pcount];
        avx[i] = avx[pcount]; avy[i] = avy[pcount];
        alife[i] = alife[pcount]; ahue[i] = ahue[pcount];
        ar[i] = ar[pcount]; aang[i] = aang[pcount]; asp[i] = asp[pcount];
    }
}
