/*
 * Cranberry Juice — a native GTK4 music player for elementary OS.
 * Application entry point: GStreamer init, dark glass styling, main window.
 */

public class CranberryJuice.Application : Gtk.Application {

    // Single shared settings store (KeyFile-backed).
    public static Settings settings;

    public Application () {
        Object (
            application_id: "io.github.cranberry.juice",
            flags: ApplicationFlags.HANDLES_OPEN
        );
    }

    construct {
        settings = new Settings ();
    }

    protected override void startup () {
        base.startup ();

        // Always-on dark glass theme, independent of the system preference.
        var gtk_settings = Gtk.Settings.get_default ();
        gtk_settings.gtk_application_prefer_dark_theme = true;

        var provider = new Gtk.CssProvider ();
        provider.load_from_resource ("/io/github/cranberry/juice/application.css");
        Gtk.StyleContext.add_provider_for_display (
            Gdk.Display.get_default (),
            provider,
            Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION + 1
        );

        // A second, higher-priority provider holds the theme override (Light /
        // Cranberry Red). Default loads an empty override = the dark glass base.
        theme_provider = new Gtk.CssProvider ();
        Gtk.StyleContext.add_provider_for_display (
            Gdk.Display.get_default (),
            theme_provider,
            Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION + 2
        );
        apply_theme (settings.get_str ("theme", "dark"));
    }

    // Theme switching: swaps the override stylesheet live. Stored as a setting.
    public static Gtk.CssProvider theme_provider;
    // The currently active theme key. Read by MainWindow to decide whether the
    // gold-star click effect runs (only the "peachy" theme uses it).
    public static string current_theme = "dark";
    public static void apply_theme (string theme) {
        if (theme_provider == null) return;
        string res = (theme == "light")     ? "theme-light.css"
                   : (theme == "cranberry") ? "theme-cranberry.css"
                   : (theme == "leaf")      ? "theme-leaf.css"
                   : (theme == "ocean")     ? "theme-ocean.css"
                   : (theme == "peachy")    ? "theme-peachy.css"
                   : (theme == "grimace")   ? "theme-grimace.css"
                   : "theme-empty.css";
        theme_provider.load_from_resource ("/io/github/cranberry/juice/" + res);
        current_theme = theme;
        settings.set_str ("theme", theme);
    }

    protected override void activate () {
        var window = active_window;
        if (window == null) {
            window = new MainWindow (this);
        }
        window.present ();
    }

    // Launched as the default music player with one or more files — play them in
    // the compact Mini Player window rather than the full app.
    protected override void open (File[] files, string hint) {
        activate ();
        var win = active_window as MainWindow;
        if (win != null) win.play_files_in_mini (files);
    }

    public static int main (string[] args) {
        Gst.init (ref args);
        return new Application ().run (args);
    }
}
