/*
 * Lightweight persistence using a GLib.KeyFile stored under the user's config
 * directory. Avoids a GSettings schema install so the app runs straight from
 * the build tree.
 */

public class CranberryJuice.Settings : GLib.Object {

    private GLib.KeyFile keyfile;
    private string file_path;

    construct {
        keyfile = new GLib.KeyFile ();
        var dir = Path.build_filename (Environment.get_user_config_dir (), "cranberry-juice");
        DirUtils.create_with_parents (dir, 0755);
        file_path = Path.build_filename (dir, "settings.conf");
        try {
            keyfile.load_from_file (file_path, KeyFileFlags.NONE);
        } catch (Error e) {
            // First run — no file yet.
        }
    }

    public string get_str (string key, string fallback) {
        try { return keyfile.get_string ("General", key); }
        catch (Error e) { return fallback; }
    }

    public void set_str (string key, string val) {
        keyfile.set_string ("General", key, val);
        save ();
    }

    public double get_num (string key, double fallback) {
        try { return keyfile.get_double ("General", key); }
        catch (Error e) { return fallback; }
    }

    public void set_num (string key, double val) {
        keyfile.set_double ("General", key, val);
        save ();
    }

    public bool get_flag (string key, bool fallback) {
        try { return keyfile.get_boolean ("General", key); }
        catch (Error e) { return fallback; }
    }

    public void set_flag (string key, bool val) {
        keyfile.set_boolean ("General", key, val);
        save ();
    }

    // --- Playlists are stored as groups named "Playlist:<name>" -------------
    public string[] list_playlists () {
        string[] names = {};
        foreach (unowned string grp in keyfile.get_groups ()) {
            if (grp.has_prefix ("Playlist:")) {
                names += grp.substring (9);
            }
        }
        return names;
    }

    public string[] get_playlist (string name) {
        try { return keyfile.get_string_list ("Playlist:" + name, "paths"); }
        catch (Error e) { return new string[0]; }
    }

    public void set_playlist (string name, string[] paths) {
        keyfile.set_string_list ("Playlist:" + name, "paths", paths);
        save ();
    }

    public void remove_playlist (string name) {
        try { keyfile.remove_group ("Playlist:" + name); save (); }
        catch (Error e) { /* ignore */ }
    }

    private void save () {
        try { keyfile.save_to_file (file_path); }
        catch (Error e) { warning ("Could not save settings: %s", e.message); }
    }
}
