/*
 * MPRIS2 (org.mpris.MediaPlayer2) over GDBus, so the elementary OS sound
 * indicator (volume drop-down) shows the current track and play/pause/next/prev.
 * Only GIO's D-Bus is used — no extra dependencies.
 */

namespace CranberryJuice {

    [DBus (name = "org.mpris.MediaPlayer2")]
    public class MprisRoot : GLib.Object {
        public signal void raise_requested ();
        public signal void quit_requested ();

        public bool can_quit { get { return true; } }
        public bool can_raise { get { return true; } }
        public bool has_track_list { get { return false; } }
        public string identity { owned get { return "Cranberry Juice"; } }
        public string desktop_entry { owned get { return "io.github.cranberry.juice"; } }
        public string[] supported_uri_schemes { owned get { return { "file" }; } }
        public string[] supported_mime_types {
            owned get { return { "audio/mpeg", "audio/flac", "audio/mp4", "audio/ogg", "audio/x-wav" }; }
        }

        public void raise () { raise_requested (); }
        public void quit () { quit_requested (); }
    }

    [DBus (name = "org.mpris.MediaPlayer2.Player")]
    public class MprisPlayer : GLib.Object {
        public signal void play_pause_requested ();
        public signal void next_requested ();
        public signal void previous_requested ();
        public signal void stop_requested ();
        public signal void seeked (int64 position);

        public string playback_status { owned get; set; default = "Stopped"; }
        public GLib.HashTable<string, Variant> metadata { owned get; set; }
        public double volume { get; set; default = 1.0; }

        construct {
            metadata = new GLib.HashTable<string, Variant> (str_hash, str_equal);
        }
        public int64 position { get { return 0; } }
        public double rate { get; set; default = 1.0; }
        public double minimum_rate { get { return 1.0; } }
        public double maximum_rate { get { return 1.0; } }
        public bool can_go_next { get { return true; } }
        public bool can_go_previous { get { return true; } }
        public bool can_play { get { return true; } }
        public bool can_pause { get { return true; } }
        public bool can_seek { get { return false; } }
        public bool can_control { get { return true; } }

        public void play_pause () { play_pause_requested (); }
        public void play () { play_pause_requested (); }
        public void pause () { play_pause_requested (); }
        public void stop () { stop_requested (); }
        public void next () { next_requested (); }
        public void previous () { previous_requested (); }
        public void seek (int64 offset) { }
        public void set_position (string track_id, int64 pos) { }
        public void open_uri (string uri) { }
    }

    // Owns the bus name, registers the objects, and pushes property updates.
    public class Mpris : GLib.Object {
        private unowned MainWindow window;
        private uint owner_id = 0;
        private DBusConnection? connection = null;
        private MprisRoot root_iface;
        private MprisPlayer player_iface;
        private uint root_reg = 0;
        private uint player_reg = 0;

        public Mpris (MainWindow win) {
            window = win;
            owner_id = Bus.own_name (
                BusType.SESSION,
                "org.mpris.MediaPlayer2.cranberryjuice",
                BusNameOwnerFlags.NONE,
                on_bus_acquired,
                null,
                null
            );
        }

        private void on_bus_acquired (DBusConnection conn, string name) {
            connection = conn;
            root_iface = new MprisRoot ();
            player_iface = new MprisPlayer ();

            root_iface.raise_requested.connect (() => window.present ());
            root_iface.quit_requested.connect (() => window.close ());
            player_iface.play_pause_requested.connect (() => window.mpris_play_pause ());
            player_iface.next_requested.connect (() => window.mpris_next ());
            player_iface.previous_requested.connect (() => window.mpris_previous ());
            player_iface.stop_requested.connect (() => window.mpris_play_pause ());

            try {
                root_reg = conn.register_object ("/org/mpris/MediaPlayer2", root_iface);
                player_reg = conn.register_object ("/org/mpris/MediaPlayer2", player_iface);
            } catch (Error e) {
                warning ("MPRIS: could not register objects: %s", e.message);
            }
        }

        // Push the current track + state to the sound indicator.
        public void update (string status, string title, string artist, string album, string? art_url) {
            if (connection == null || player_iface == null) return;

            var meta = new GLib.HashTable<string, Variant> (str_hash, str_equal);
            meta.insert ("mpris:trackid", new Variant.object_path ("/io/github/cranberry/juice/track0"));
            meta.insert ("xesam:title", new Variant.string (title));
            meta.insert ("xesam:artist", new Variant.strv ({ artist }));
            meta.insert ("xesam:album", new Variant.string (album));
            if (art_url != null && art_url != "") meta.insert ("mpris:artUrl", new Variant.string (art_url));

            player_iface.playback_status = status;
            player_iface.metadata = meta;

            var changed = new VariantBuilder (new VariantType ("a{sv}"));
            changed.add ("{sv}", "PlaybackStatus", new Variant.string (status));
            changed.add ("{sv}", "Metadata", ht_to_variant (meta));
            var invalidated = new VariantBuilder (new VariantType ("as"));
            try {
                connection.emit_signal (null, "/org/mpris/MediaPlayer2",
                    "org.freedesktop.DBus.Properties", "PropertiesChanged",
                    new Variant ("(sa{sv}as)", "org.mpris.MediaPlayer2.Player",
                        changed, invalidated));
            } catch (Error e) {
                warning ("MPRIS: PropertiesChanged failed: %s", e.message);
            }
        }

        private static Variant ht_to_variant (GLib.HashTable<string, Variant> ht) {
            var b = new VariantBuilder (new VariantType ("a{sv}"));
            ht.foreach ((k, v) => { b.add ("{sv}", k, v); });
            return b.end ();
        }
    }
}
