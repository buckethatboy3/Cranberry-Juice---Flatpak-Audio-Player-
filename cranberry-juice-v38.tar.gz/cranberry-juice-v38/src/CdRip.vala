/*
 * CdRip — read an audio CD from an optical drive and import its tracks into the
 * music library as tagged FLAC files, in an Artist/Album/NN Title.flac layout.
 *
 * Uses GStreamer only (no extra tag library): cdparanoiasrc reads CD audio and
 * posts a TOC (track list) + any CD-TEXT tags; each track is encoded to FLAC and
 * tagged via taginject. Everything is best-effort and degrades gracefully — if a
 * plugin or the drive is missing, detection returns null and ripping reports the
 * failure rather than crashing. All heavy work runs on a worker thread.
 */

public class CranberryJuice.CdRip : GLib.Object {

    // Emitted on the main loop.
    public signal void detected (Disc? disc);          // null = no disc / no support
    public signal void progress (int done, int total, double frac);
    public signal void finished (int ripped, string album_dir);
    public signal void failed (string message);

    // Optical device node. Empty = let GStreamer use its default (/dev/cdrom).
    public string device { get; set; default = ""; }

    // Output format: "flac" (default, lossless), "ogg", or "mp3".
    public string format { get; set; default = "flac"; }

    private string ext_for (string fmt) {
        return (fmt == "ogg") ? "ogg" : (fmt == "mp3") ? "mp3" : "flac";
    }
    private string encoder_for (string fmt) {
        if (fmt == "ogg") return "vorbisenc ! oggmux";
        if (fmt == "mp3") return "lamemp3enc";
        return "flacenc";
    }

    public class Disc : GLib.Object {
        public int n_tracks = 0;
        public string album = "";
        public string artist = "";
        public string[] titles = {};   // per-track CD-TEXT title (may be empty strings)
    }

    public static bool have_element (string name) {
        var f = Gst.ElementFactory.find (name);
        return f != null;
    }

    // True if the machine has what CD ripping needs.
    public static bool supported () {
        return have_element ("cdparanoiasrc") && have_element ("flacenc");
    }

    // Detect the disc on a worker thread; emits `detected` on the main loop.
    public void detect_async () {
        new Thread<void*> ("cj-cd-detect", () => {
            Disc? d = detect ();
            Idle.add (() => { detected (d); return false; });
            return null;
        });
    }

    // Read the disc TOC + CD-TEXT. Blocks up to ~6s. Returns null if unavailable.
    private Disc? detect () {
        if (!have_element ("cdparanoiasrc")) return null;
        Disc disc = new Disc ();
        try {
            var pipe = (Gst.Pipeline) Gst.parse_launch ("cdparanoiasrc name=src ! fakesink");
            var src = pipe.get_by_name ("src");
            if (src != null && device != "") src.set ("device", device);
            pipe.set_state (Gst.State.PAUSED);
            var bus = pipe.get_bus ();
            for (int i = 0; i < 12; i++) {
                var msg = bus.timed_pop_filtered (500 * Gst.MSECOND,
                    Gst.MessageType.TOC | Gst.MessageType.TAG |
                    Gst.MessageType.ERROR | Gst.MessageType.ASYNC_DONE);
                if (msg == null) continue;
                if (msg.type == Gst.MessageType.ERROR) break;
                if (msg.type == Gst.MessageType.TOC) {
                    Gst.Toc toc; bool upd;
                    msg.parse_toc (out toc, out upd);
                    parse_toc (toc, disc);
                }
                if (msg.type == Gst.MessageType.TAG) {
                    Gst.TagList tags;
                    msg.parse_tag (out tags);
                    string s;
                    if (tags.get_string (Gst.Tags.ALBUM, out s)) disc.album = s;
                    if (tags.get_string (Gst.Tags.ARTIST, out s)) disc.artist = s;
                }
                if (disc.n_tracks > 0 && (msg.type == Gst.MessageType.ASYNC_DONE)) break;
            }
            pipe.set_state (Gst.State.NULL);
        } catch (Error e) {
            return null;
        }
        return disc.n_tracks > 0 ? disc : null;
    }

    private void parse_toc (Gst.Toc toc, Disc disc) {
        int count = 0;
        string[] titles = {};
        foreach (unowned Gst.TocEntry e in toc.get_entries ()) {
            if (e.get_entry_type () == Gst.TocEntryType.TRACK) {
                count++;
                string s = "";
                unowned Gst.TagList? t = e.get_tags ();
                if (t != null) t.get_string (Gst.Tags.TITLE, out s);
                titles += (s == null ? "" : s);
            }
        }
        disc.n_tracks = count;
        disc.titles = titles;
    }

    // Rip every track to dest_root/<artist>/<album>/NN Title.flac on a worker thread.
    public void rip_async (string dest_root, string album_artist, string album, string[] titles) {
        string dr = dest_root, aa = album_artist, al = album;
        string[] tl = titles;
        new Thread<void*> ("cj-cd-rip", () => {
            int total = tl.length;
            if (total == 0) {
                Idle.add (() => { failed ("No tracks to rip."); return false; });
                return null;
            }
            string adir = Path.build_filename (dr, sanitize (aa), sanitize (al));
            if (DirUtils.create_with_parents (adir, 0755) != 0) {
                Idle.add (() => { failed ("Could not create the album folder in your library."); return false; });
                return null;
            }
            int ripped = 0;
            for (int i = 0; i < total; i++) {
                int trackno = i + 1;
                string title = (tl[i] != null && tl[i] != "") ? tl[i] : "Track %d".printf (trackno);
                string fname = "%02d %s.%s".printf (trackno, sanitize (title), ext_for (format));
                string outpath = Path.build_filename (adir, fname);
                if (rip_one (trackno, outpath, aa, al, title)) ripped++;
                int done = trackno;
                double frac = (double) done / total;
                Idle.add (() => { progress (done, total, frac); return false; });
            }
            int rr = ripped; string ad = adir;
            Idle.add (() => { finished (rr, ad); return false; });
            return null;
        });
        return;
    }

    private bool rip_one (int trackno, string outpath, string artist, string album, string title) {
        string head = "cdparanoiasrc track=%d".printf (trackno);
        if (device != "") head += " device=\"%s\"".printf (device);
        head += " ! audioconvert ! audioresample";
        string tags = "title=%s,artist=%s,album=%s,album-artist=%s,track-number=%d".printf (
            tagval (title), tagval (artist), tagval (album), tagval (artist), trackno);
        string enc = encoder_for (format);
        string with_tags = " ! taginject tags=\"%s\" ! %s ! filesink location=\"%s\"".printf (tags, enc, outpath);
        string no_tags   = " ! %s ! filesink location=\"%s\"".printf (enc, outpath);
        // Prefer the tagged pipeline; if taginject is unavailable, rip untagged.
        if (run_pipeline (head + with_tags)) return true;
        return run_pipeline (head + no_tags);
    }

    private bool run_pipeline (string desc) {
        try {
            var pipe = Gst.parse_launch (desc);
            pipe.set_state (Gst.State.PLAYING);
            var bus = pipe.get_bus ();
            bool ok = false;
            bool done = false;
            while (!done) {
                var msg = bus.timed_pop_filtered (Gst.CLOCK_TIME_NONE,
                    Gst.MessageType.EOS | Gst.MessageType.ERROR);
                if (msg == null) break;
                if (msg.type == Gst.MessageType.EOS) { ok = true; done = true; }
                else if (msg.type == Gst.MessageType.ERROR) { ok = false; done = true; }
            }
            pipe.set_state (Gst.State.NULL);
            return ok;
        } catch (Error e) {
            return false;
        }
    }

    // Make a string safe for a file/folder name.
    private string sanitize (string s) {
        var r = s.replace ("/", "-").replace ("\\", "-").replace (":", "-").strip ();
        return r == "" ? "Unknown" : r;
    }

    // Keep a value safe inside taginject's tags="k=v,k=v" string.
    private string tagval (string s) {
        return s.replace (",", " ").replace ("=", " ").replace ("\"", "'").strip ();
    }
}
