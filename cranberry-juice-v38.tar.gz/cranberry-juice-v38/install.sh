#!/usr/bin/env bash
#
# Cranberry Juice — one-shot installer for elementary OS 8 / Ubuntu 24.04.
# Installs build dependencies, compiles the app, and installs it system-wide
# so it shows up in your Applications menu.
#
set -euo pipefail

APP_ID="io.github.cranberry.juice"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

bold() { printf "\033[1m%s\033[0m\n" "$1"; }

bold "==> [1/4] Installing build dependencies (you may be prompted for your password)…"
sudo apt-get update
sudo apt-get install -y \
  meson ninja-build valac \
  libgtk-4-dev libgranite-7-dev \
  libgstreamer1.0-dev libgstreamer-plugins-base1.0-dev \
  libgdk-pixbuf-2.0-dev libcairo2-dev libpango1.0-dev \
  libsoup-3.0-dev libjson-glib-dev \
  desktop-file-utils shared-mime-info \
  gstreamer1.0-plugins-base \
  gstreamer1.0-plugins-good gstreamer1.0-plugins-bad \
  gstreamer1.0-plugins-ugly gstreamer1.0-libav

bold "==> [2/4] Configuring the build…"
rm -rf build
meson setup build --prefix=/usr

bold "==> [3/4] Compiling…"
ninja -C build

bold "==> [4/4] Installing system-wide…"
sudo ninja -C build install

# Register the app as an audio handler so it shows up in
# System Settings → Defaults → Music Player. (Rebuilds the MIME cache; harmless
# to run again.) desktop-file-utils provides update-desktop-database.
bold "==> Registering as an audio player…"
desktop-file-validate "data/${APP_ID}.desktop" || true
sudo update-desktop-database /usr/share/applications 2>/dev/null || true
sudo update-mime-database /usr/share/mime 2>/dev/null || true

echo
bold "✅ Cranberry Juice is installed!"
echo "   • Open it from your Applications menu (search \"Cranberry Juice\"), or"
echo "   • launch it from a terminal with:  ${APP_ID}"
echo "   • Set it as your default in System Settings → Defaults → Music Player,"
echo "     then double-clicking an audio file opens it in the Mini Player. 🎵"
echo
echo "On first launch, choose your Music folder (or use ~/Music) and enjoy. 🧃"
