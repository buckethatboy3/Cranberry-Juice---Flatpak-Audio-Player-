# 🧃 Cranberry Juice

A **native** music player for **elementary OS 8**, built in **Vala + GTK4 +
Granite**, with **GStreamer** for audio and **Cairo** for the visuals. It reads
a folder of your music and plays it locally — no web engine, no accounts, no
cloud. The look is an elegant dark translucent interface, and it ships
with a library of **audio-reactive visuals**.

This is a real compiled GTK application — not Electron, not a web view.

**Version 37.** **Albums stay together (final release).** Every song from the same
album is grouped by its **album folder**, so a collaboration album whose tracks each
have a different artist no longer splits into many — it shows as one album by
**Various Artists**. A real **album-artist** tag is used when a track has one. New
**Tools → Fix Album Grouping** explains the behaviour and offers a one-click rescan
to rebuild grouping and refresh artwork.

**Version 36.** **Easy uninstall.** Right-click Cranberry Juice in
your Applications menu and choose **Uninstall Cranberry Juice** to remove it with a
single admin password prompt (it clears the native install and, where possible, the
Flatpak). For a complete one-command wipe from a terminal, the included
**`./uninstall.sh`** removes the Flatpak (user + system) and the native build, and
offers to delete your settings too.

**Version 35.** **Gloss fix + new settings.** The album-cover gloss now fits each
cover exactly — covers are a fixed, clipped square, so the gloss can't render as an
inset box. **Settings → General** gained: which view opens at **startup**, **album
cover size** (Small / Medium / Large), a **gloss on/off** switch, **rescan library
on startup**, and for CD ripping a **format** choice (FLAC / OGG / MP3) and the **CD
device** path. The **View** menu now shows the Mini Player shortcut **(Ctrl+Shift+M)**.

**Version 34.** **Burn CD to Library.** A new **Tools** menu reads an audio CD from
your drive (Tools → Burn CD to Library) and imports it into your music folder as
**lossless FLAC**, organised as Album Artist / Album / NN Title.flac. Track titles
come from CD-TEXT when the disc has them (editable before ripping), tags are applied,
and the library refreshes automatically when it finishes. Best results on the native
`install.sh` build; the Flatpak needs optical-device + Music-folder write access (see
SECURITY.md). Also fixed the **album-cover gloss** so it fills the whole cover instead
of showing an inset box.

**Version 33.** **Album + song art and metadata editing.** Right-click any album
to edit its **album title, album artist, genre, year, and cover art** in one place
— and it applies to **every song in the album**. The song **Properties** editor can
now set **per-song art** as well. Both editors show the current cover (or the
Cranberry Juice icon if there isn't one); click it to pick an image from your files.
Everything is saved to your library cache — your original audio files are never
modified.

**Version 32.** **New Grimace theme** — a deep, dark purple look with **iridescent**
violet/magenta accents on the buttons and selections. Contrast was tuned for a
comfortable read: light lavender text on the dark aubergine surfaces, and white
button text only over the deeper part of the accent gradient. (There are now
seven themes; the gold-star click sparkle stays exclusive to Just Peachy.)

**Version 31.** (1) **A first-run welcome tour** — a short, four-page intro shown
the first time you open the app: Notable Features (with a quick explainer of how
Discogs works), choosing your music folder, themes, and a closing welcome. (2)
**New Just Peachy theme** — a salmon-pink, frosted-glass look; it's the only theme
that sends up a little burst of **gold stars** from the pointer on every click.
(3) The blue theme is now called **Deep Blue**. (4) **Theme-picker readability fix**
— the selected theme in Settings → Theme is now marked with a ring rather than a
filled card, so its name stays legible in every theme (in Cranberry Red the
selected card used to show white text on a near-white fill).

**Version 30.** **Security & privacy pass** (see SECURITY.md). The app makes **no network
connections at all** unless Discogs is enabled *and* you've entered a token — there's no
telemetry, analytics, or update check, and playback is local-only. Discogs downloads are
now **HTTPS-only** and **size-capped**, search terms are escaped, and the Flatpak sandbox
is tightened to **read-only home** so the app can never modify or delete your files. Audit
confirmed no shell/process execution and no dynamic code.

**Version 29.** (1) **Folder-aware open** — opening a single audio file now queues every
audio file in that folder (sorted) and starts at the one you opened, so **Skip / Next in
the Mini Player plays through the rest of the folder**. (2) **New Deep Blue theme** — a
deep, dark blue, sibling to Leaf Green (there are now five themes).

**Version 28.** (1) **New Leaf Green theme** — a deep, dark green look (near-black
surfaces, a green accent, white/grey text). (2) **The song list and search box now
follow the selected theme** — the ColumnView's internal listview and the entry fields were
keeping GTK's dark default; both are now themed/transparent. (3) **Album-cover gloss now
covers the whole cover** instead of a small box. (4) The **cranberry-cup loading indicator**
also shows during Discogs fetches (plus library scans). (5) The Flatpak build now also
produces a **single shareable `cranberry-juice.flatpak` file**.

**Version 27.** Verified checkpoint — a full sanity pass over every source file (balanced,
no Vala gotchas, consistent versioning, markup-safe), executable build scripts, and a
**corrected Flatpak build script**: it now adds elementary's own Flatpak repo (`appcenter`),
because the elementary runtime that provides Granite is **not on Flathub** — and it reports
the available runtime version if `8` isn't found. The fragile ffmpeg codec extension was
dropped from the manifest (the runtime's GStreamer already decodes MP3/FLAC/OGG/WAV).

**Version 26.** **Light-theme tracklist fix** — the song titles shown when you open an album
(the album detail page) were grey/hard to read because that list builds its own rows; they
now use the same per-theme colour as the main song list, so they're near-black in Light
(and the Up Next list got the same fix).

**Version 25.** (1) **Flatpak packaging** — `io.github.cranberry.juice.yml` + `build-flatpak.sh`
build it as a Flatpak on the elementary runtime; a Flatpak install also registers it as a
default audio handler (an alternative path to getting it into Defaults → Music Player). (2)
**Expanded Discogs settings** — an "auto-apply artist photos" toggle, a "create a random
playlist from a genre" picker, and a note that fetched photos + created playlists are saved
on disk so they persist even with Discogs turned off. (3) **About redesigned** — the app
icon now sits above the (non-selectable) title, and a **Version History** button opens a
scrollable changelog of every version, which will keep being updated going forward.

**Version 24.** (1) **Song names are now near-black in the Light theme** — the Name
column was inheriting the dark theme's light text; it now has its own colour set per
theme (black on Light, white on Cranberry/Dark). (2) **Default audio player** — the
installer now pulls in `desktop-file-utils` and rebuilds the desktop/MIME database, so
Cranberry Juice shows up under **System Settings → Defaults → Music Player** (that
registration step was previously being skipped when the tool was missing). (3) **Open a
file → Mini Player** — once it's your default music player, double-clicking an audio
file plays it in the compact **Mini Player** window instead of the full app.

**Version 23.** (1) **Light theme fixes** — text is now a near-black across the board
(the songs page is no longer washed-out grey), and the content/album area now follows
the selected theme instead of staying dark (content surfaces are transparent so the
themed window background shows through). (2) **Discogs is now live** (enable it + paste
your free token in Settings → Discogs): **artist photos** are fetched in the background
as you play and appear in the **Artists** view, and **Smart Shuffle** (Controls menu)
builds a "sensible random" playlist from a song's genre. Network work runs on a worker
thread; everything is gated behind the toggle + token. New build deps: **libsoup-3** and
**json-glib** (the installer adds them).

**Version 22.** (1) **Settings is now tabbed** (General · Theme · Discogs). (2) **Themes**
— a Theme tab with **Dark Glass** (default), **Light** (a clean heavy-white look), and
**Cranberry Red** (bold, vivid red with white text). Switching is live and remembered.
(3) **Sound-indicator integration (MPRIS)** — the current track and play/pause/next/prev
now appear in the elementary OS volume drop-down, via the standard
`org.mpris.MediaPlayer2` D-Bus interface (no new dependencies — it uses GIO's D-Bus).
(4) **Discogs (groundwork)** — a Discogs tab with an enable toggle and a token field
(saved to your settings). *How it will work:* with Discogs enabled and a free personal
token, the app will query the Discogs API to pull **artist photos** and richer
**genre/style tags**, cache them locally, and use the styles to build smarter "random"
shuffle playlists. The actual network fetching lands in the next version so any
build/dependency issue stays isolated; this version ships the toggle, token, and plumbing.

**Version 21.** (1) **Album labels line up under their covers** — each card is now
pinned to the cover width and centred, so the title and artist share the cover's left
edge (no more uneven text). (2) **The audio-reactive visuals were sharpened using the
approach from cava** (the console spectrum analyzer): the spectrum now uses
**log-frequency binning** (more detail in the bass, like human hearing), **gravity
smoothing** (bars snap up instantly and fall slowly), and **auto-sensitivity** (a
running-peak normaliser so quiet and loud tracks both fill the frame). These apply to
all the spectrum visuals (Spectrum Bars, Mirror Bars, Radial, Sunburst…). The
techniques are cava's; the code here is original (cava is GPL — none of its source was
copied). (3) **Fireworks now works** — it only ever launched on a very strong bass hit
that rarely happened; it now fires on a lower, reachable beat threshold *and* on a
steady music-level cadence, so it reliably bursts while a song plays.

**Version 20.** Album view polish + a big performance pass. (1) **Covers show only the
image now** — the grey frame/background is gone (the art fills the square). (2) Each
cover has a **glossy highlight** across the top and a **soft drop shadow** beneath it.
(3) **The album grid is now virtualized** (Gtk.GridView): only the covers actually on
screen are built, so a 1000+ album library scrolls smoothly and opens instantly —
the old grid built every single card up front. (4) That same change **fixes the laggy
vinyl roll-out**: the stutter came from tearing down the whole giant grid as the detail
page opened; with virtualization there's nothing heavy to tear down, so the animation
runs clean. (5) The album list is also **cached** between tab switches, so flipping
back to Albums is instant. Still exactly six columns.

**Version 19.** **Album covers are visible again.** v18's AspectFrame approach had no
minimum size, so the covers collapsed to zero height (you saw only text). Reverted to
a **fixed 150px square cover** that is centred in its cell — a fixed size can't collapse
and can't be stretched/cropped by the grid, and `CONTAIN` keeps the whole cover visible.
Still **exactly six columns**, rows for every album. (Cover size is one constant if you
want it bigger/smaller.) The Ctrl+Shift+M hotkey and the mini progress bubble from v18
are unchanged.

**Version 18.** (1) **Album covers now show in full.** v17 let the grid stretch each
cover wider than tall, so `COVER` cropped the art and you only saw a slice. Each cover
is now pinned to a true **1:1 square** (via an AspectFrame) and drawn with `CONTAIN`,
so the **entire cover is always visible**; the grid is locked to **exactly six columns**
that fill the width, with rows continuing for every album in your library. (2) **A
direct Ctrl+Shift+M hotkey** now toggles the Mini Player — so three ways total: click
the album art, View → Mini Player, or Ctrl+Shift+M. (3) A **small grey translucent
bubble** sits behind just the Mini Player's progress bar and timestamps (nothing else).

**Version 17.** **Albums view redesigned** — large, full,
edge-to-edge square covers in a clean grid (up to 6 across), each with the album
title and artist beneath. Covers are bigger (178px) with squared corners and a soft
drop shadow so the artwork reads as a full cover rather than a small framed thumbnail;
albums without embedded art show the vinyl image so every tile stays full.

**Version 16.** (1) **Spacebar is now play/pause** everywhere (it used to reach the
scrubber and restart the song); it's ignored while you're typing in a search/edit
field. (2) The **Mini Player updates live** — its cover changes with the song and its
play/pause button reflects the real state however you toggle it. (3) Right-click a
song for **Play Next** (drops it in right after the current track) and **Properties…**
— an editable metadata form (Title, Artist, Album, Composer, Genre, Year, Track) saved
to your library and kept across restarts (the file's embedded tags aren't modified).
(4) The **Albums tab no longer freezes** — the grid fills in small batches via the idle
loop, so it appears instantly even for big libraries. (5) A new **cranberry-cup loading
indicator** in the bottom-left: a floating jug pours juice into a cup, the cup fills as
the jug drains, then the cup drains while the jug refills — shown whenever the app is
scanning or building the album grid.

**Version 15.** Five things. (1) **Up Next is now shuffle-aware** — the queue keeps a
fixed play order, so the Up Next list shows the *actual* upcoming songs even when
shuffled (it used to pick the next track at random, so there was nothing real to
show or reorder). (2) **Reorder Up Next** with per-row ▲ / ▼ move buttons. (3) The
Mini Player hint no longer appears over the **empty-state Cranberry icon** at launch
— only over the album art of a playing song. (4) **Ctrl+Shift+M** toggles the Mini
Player, and there's now a **Mini Player** item under the **View** menu. (5) The
**library/playlist sidebar is now a slim icon rail** — labels moved to tooltips,
because a GTK box sizes to its widest child, so the text labels were what kept the
sidebar wide no matter the width set. Hover any icon for its name.

**Version 14.** Mini Player redesigned as a compact, cover-first player: idle shows
just the album cover; on hover a dark Cranberry-glass panel slides up with the
progress bar + times and a control row (prev / play / next / Up Next), with the
Cranberry icon top-right to return to the full window. The now-playing area also
shows a clean empty state (centred Cranberry icon, no text) until music plays.

**Version 13.** Mini Player polish: hovering the album art now shows a hint icon so
you know you can click it; entering the Mini Player **un-fullscreens / un-maximizes**
first so the window actually **shrinks** small (it was ignoring the resize while
fullscreen), and it's a compact ~300px player with a thin progress bar. Also: the
**progress bar is now fluid** — position is read with sub-second precision and
interpolated at the frame rate (it used to jump once per second).

**Version 12.** **The audio-reactive visuals now actually react to the music.** The
spectrum signal was being connected in the visualizer's `construct{}` block, which
in Vala runs *before* the player field is assigned — so it bound to a null player
and never received any audio data (only the idle, time-based motion showed). Moved
the connection into the constructor body. Every visual (especially the spectrum
ones) now responds to what's playing.

**Version 11.** **Mini Player** — click the album art in the player and the whole
window collapses to just the album cover; move the mouse to reveal play/skip + an
Up Next button, and a Cranberry icon (top-right) to return to the full window.
Also: **shuffle history** — Previous now walks back through the songs you actually
heard (correct for shuffle), and Next walks forward again.

**Version 10.** **No more re-scanning on every launch** — the library (track tags +
album art) is cached to disk (`~/.config/cranberry-juice/`) and loaded instantly at
startup; it only scans when there's no cache or you hit Rescan. The Settings dialog
(Help → Settings…) already lets you change the music folder. (Mini Player is v11.)

**Version 9.** Album grid shows multiple per row (click still pops the cover
forward with the vinyl + tracklist); an **Up Next** queue button in the player
(top-middle) shows the upcoming songs; and when nothing is playing the player
shows the **Cranberry Juice icon** with no text.

**Version 8.** Narrower sidebar; **shuffle fixed** (it now picks a random next
track live, even toggled mid-playback — it used to bake the order in at play time,
so toggling did nothing); repeat/loop verified correct; and a **Settings** dialog
(under the Help menu) with music-folder / rescan / visuals shortcuts.

**Version 7.** Albums tab loads fast now — the grid shows instantly and covers
stream in lazily, with decoded artwork **cached** (re-opening Albums and album
detail is instant). Also fixed: **Help → About** now reports the correct version
(it was hard-coded, which made v6 look like v5).

**Version 6.** Album view now opens a detail page where a **vinyl record slides out
from behind the cover** and the **tracklist** appears; **← / →** slide between
albums. Plus: visuals **fullscreen** fixed and audio reactivity **boosted**, a
**narrower sidebar**, and Cranberry Juice can now be set as your **default music
player** (double-clicking a song opens it here). Mini Player is next in v7.

**Version 5.** Native window controls + a draggable window (real `Gtk.HeaderBar`),
a classic **menu bar** with **Audio-reactive visuals under the View menu**
(also `Ctrl+T`), a much faster library scan (batched inserts + album art de-duped
per album), `.m4a` confirmed supported, and the app now appears in elementary's
default-apps list. (Mini Player mode is coming in v6.)

**Version 4.** Build fix: the folder scanner uses a `GenericArray` (Vala forbids
growing an array *parameter* with `+=`).

**Version 3.** Build fix only: the playback position query now initializes its
locals (Vala flagged a possibly-unassigned variable in a short-circuited check).
No feature changes from v2.

**Version 2.** What's new since v1:
- **Composers** library view (alongside Songs, Albums, Artists, Genres).
- **Track Details** dialog (a song info / metadata view) — right-click a song → *Track Details*.
- All build fixes folded in, plus a full code re-verification pass.
- Distinctive menu terms given their own wording (see the table below).

---

## Features

- **Library from a folder** (defaults to `~/Music`): tags + embedded artwork are
  read with the GStreamer discoverer.
- **Classic player layout**: window controls + transport + volume on the left, a
  centred now-playing display with a scrubber and shuffle/repeat, search on the
  right, a Library/Playlists sidebar, and a sortable song table.
- **Views**: Songs (sortable `Gtk.ColumnView`), Albums (cover grid), Artists,
  Genres, Composers, and your Playlists. Click an album/artist/genre/composer to drill in.
- **Playback**: play/pause, next/previous, seek, volume, **shuffle**, **repeat**
  (off / all / one). Double-click a song to play its list.
- **Playlists**: create / rename / delete; right-click a song → *Add to Playlist*.
- **Right-click a song** (after selecting it) for Play, Add to Queue, Add to
  Playlist, *Track Details*, and *Show in Files*.
- **Themes**: seven looks — Dark Glass (default), Light, Cranberry Red, Leaf Green,
  Deep Blue, Just Peachy (salmon-pink frosted glass, with a gold-star click
  sparkle), and Grimace (dark purple with iridescent violet accents). Switch any
  time in Settings → Theme.
- **Audio-reactive visuals**: the reveal button (top-right) opens a
  fullscreen-capable window with **19 visuals** across *Classic*
  (Magnetosphere, Supernova, Plasma Drift, Lava Lamp, Aurora, Jelly),
  *Spectrum*, *Geometry*, and *Particles*. Browse them in a gallery, auto-cycle,
  or go fullscreen. They react to live frequency data from a GStreamer
  `spectrum` element. (The list is data-driven — adding more is a single
  `draw_*` method.)
- Remembers your folder, volume, shuffle/repeat, and playlists
  (`~/.config/cranberry-juice/settings.conf`).

---

## Menu terminology

Cranberry Juice uses a familiar music-player layout but gives its distinctive
features their own names:

| Typical player | Cranberry Juice |
|---|---|
| Visualizer | Audio-reactive visuals |
| Get Info | Track Details |
| Up Next | Play Queue |
| View As → Songs / Albums / Artists / Genres / Composers | same view names |

---

## Build & run

### Quick install (recommended)

From inside this folder, run the one-shot installer — it installs every
dependency, compiles the app, and adds it to your Applications menu:

```bash
./install.sh
```

Or to just try it without installing system-wide:

```bash
./run.sh
```

The manual steps below are equivalent, if you prefer to run them yourself.

### Dependencies (elementary OS 8 / Ubuntu 24.04)

```bash
sudo apt update
sudo apt install -y \
  meson ninja-build valac \
  libgtk-4-dev libgranite-7-dev \
  libgstreamer1.0-dev libgstreamer-plugins-base1.0-dev \
  libgdk-pixbuf-2.0-dev libcairo2-dev libpango1.0-dev \
  gstreamer1.0-plugins-good gstreamer1.0-plugins-bad \
  gstreamer1.0-plugins-ugly gstreamer1.0-libav
```

The `gstreamer1.0-plugins-*` packages provide the codecs (MP3/AAC/FLAC/…) and
the `spectrum` element the visuals use.

### Compile

```bash
cd "Cranberry Juice"
meson setup build
ninja -C build
```

### Run (without installing)

```bash
./build/io.github.cranberry.juice
```

### Install system-wide (optional)

```bash
sudo ninja -C build install
```

This installs the binary, the `.desktop` entry, the AppStream metainfo, and the
icon — so **Cranberry Juice** appears in the Applications menu.

---

## Uninstalling

Whichever you prefer:

- **From the menu:** right-click **Cranberry Juice** in your Applications list and
  choose **Uninstall Cranberry Juice**. One admin password prompt removes it.
- **One command (removes everything):** from this folder, run `./uninstall.sh` — it
  removes the Flatpak (your own and system-wide) and the native `/usr` build, and
  asks before deleting your settings.
- **Flatpak only:** `flatpak uninstall io.github.cranberry.juice` (or use AppCenter).

Your settings and library cache live in `~/.config/cranberry-juice` and are removed
only if you say yes when `uninstall.sh` asks.

---

## Keyboard shortcuts (visuals window)

| Key | Action |
|-----|--------|
| `← / →` | Previous / next visual |
| `G` | Toggle the visual gallery |
| `A` | Toggle auto-cycle |
| `F` | Toggle fullscreen |
| `Esc` | Close the gallery, then the window |

---

## Notes & limits

- **Glass look**: GTK can't do live backdrop blur the way a browser can, so the
  "glass" here is translucent panels + soft gradients over the themed base —
  the standard native approach.
- **Playable formats** depend on which GStreamer plugin packages you have
  installed (see the build deps above). Common formats work with
  plugins-good/bad/ugly + libav.
- **Album-artist** tags: GStreamer's discoverer doesn't expose a distinct
  album-artist field, so albums are grouped by the track artist. Compilations
  with many artists will therefore split per artist.
- **Right-click context menu** acts on the currently *selected* song — left-click
  to select, then right-click.

---

*Enjoy the juice.* 🧃🎶
