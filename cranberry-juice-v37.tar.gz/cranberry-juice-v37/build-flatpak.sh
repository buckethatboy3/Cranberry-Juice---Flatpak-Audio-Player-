#!/usr/bin/env bash
#
# Build and install Cranberry Juice (v37) as a Flatpak. A Flatpak install also
# exports the desktop file + MIME types into Flatpak's app database, which is what
# makes the app show up in System Settings -> Defaults -> Music Player.
#
set -euo pipefail

APP_ID="io.github.cranberry.juice"
RUNTIME_VER="8"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

bold() { printf "\033[1m%s\033[0m\n" "$1"; }

bold "==> [1/4] Installing Flatpak + flatpak-builder…"
sudo apt-get update -qq || true
sudo apt-get install -y flatpak flatpak-builder

bold "==> [2/4] Adding Flatpak remotes…"
# Flathub (general), and elementary's OWN repo — the elementary runtime that
# provides Granite is NOT on Flathub, which is why the previous run failed with
# "Nothing matches io.elementary.Platform in remote flathub".
flatpak remote-add --user --if-not-exists flathub https://flathub.org/repo/flathub.flatpakrepo
flatpak remote-add --user --if-not-exists appcenter https://flatpak.elementary.io/repo.flatpakrepo

bold "==> [3/4] Installing the elementary ${RUNTIME_VER} runtime + SDK (from appcenter)…"
if ! flatpak install --user -y appcenter \
      "io.elementary.Platform//${RUNTIME_VER}" \
      "io.elementary.Sdk//${RUNTIME_VER}"; then
  echo
  bold "Could not install io.elementary.Platform//${RUNTIME_VER}."
  echo "These versions are available on the elementary repo:"
  flatpak remote-info --user appcenter io.elementary.Platform 2>/dev/null \
    | grep -i version || flatpak remote-ls --user appcenter | grep -i elementary.Platform || true
  echo
  echo "Tell me which version is listed and I'll point the manifest + this script at it."
  exit 1
fi

bold "==> [4/5] Building + installing the Flatpak (a few minutes)…"
# --repo exports the build to a local OSTree repo so we can also make a bundle.
flatpak-builder --user --install --force-clean --repo=flatpak-repo build-flatpak "${APP_ID}.yml"

bold "==> [5/5] Creating a single shareable .flatpak file…"
flatpak build-bundle flatpak-repo "cranberry-juice.flatpak" "${APP_ID}"
BUNDLE="$(pwd)/cranberry-juice.flatpak"

echo
bold "✅ Cranberry Juice (v37) is installed as a Flatpak."
echo "   • Run it:        flatpak run ${APP_ID}"
echo "   • Set default:   System Settings -> Defaults -> Music Player -> Cranberry Juice"
echo "   • Open an audio file → it plays in the Mini Player. 🧃"
echo
bold "📦 A single shareable install file was created here:"
echo "   ${BUNDLE}"
echo "   Install it on any machine with:  flatpak install ./cranberry-juice.flatpak"
echo "   (That machine also needs the elementary 8 runtime; the script above adds it.)"
