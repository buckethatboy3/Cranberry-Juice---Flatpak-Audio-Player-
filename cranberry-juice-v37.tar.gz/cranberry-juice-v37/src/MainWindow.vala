/*
 * The main window: a classic transport + now-playing display, a library
 * sidebar, a sortable song list (Gtk.ColumnView), album grid, artist/genre
 * lists, and playlists. Owns the playback queue, shuffle/repeat, and search.
 */

namespace CranberryJuice {
    public delegate void PromptCb (string text);
    public delegate void Action ();
    public delegate void ImagePickedCb (GLib.Bytes bytes);

    // One gold star in the Just Peachy click-sparkle effect. Plain value struct
    // held in an array; advanced each frame and drawn on a transparent overlay.
    struct Star {
        double x;
        double y;
        double vx;
        double vy;
        double life;   // 1.0 at spawn, counts down to 0.0
        double rot;
        double spin;
        double size;
    }
}

public class CranberryJuice.MainWindow : Gtk.ApplicationWindow {

    private Library library;
    private Player player;
    private Visualizer? visuals = null;
    private Mpris? mpris = null;   // sound-indicator (MPRIS) bridge
    private Discogs discogs = new Discogs ();   // optional artist art + style tags

    // song-list models
    private Gtk.CustomFilter filter;
    private Gtk.FilterListModel filter_model;
    private Gtk.SortListModel sort_model;
    private Gtk.SingleSelection selection;
    private Gtk.ColumnView column_view;

    // navigation state
    private string view = "songs";          // songs | albums | artists | genres | playlist
    private string scope_type = "";         // "", artist, genre, album, playlist
    private string scope_value = "";
    private string scope_artist = "";
    private string[] scope_playlist_paths = {};
    private string search_text = "";

    // playback queue.  `order` holds queue indices in the actual play sequence
    // (shuffled or sequential), and `order_pos` is where we are within it — so
    // walking it backward is the real play history and the tail (order_pos+1 …)
    // is the true "Up Next", correct even under shuffle.
    private GenericArray<Track> queue = new GenericArray<Track> ();
    private int q_index = -1;       // current queue index == order[order_pos]
    private int[] order = {};       // play order: a permutation of queue indices
    private int order_pos = -1;     // current position within `order`
    private bool shuffle = false;
    private string repeat = "off";          // off | all | one
    private double volume = 0.8;
    private string music_folder = "";
    private Track? right_clicked_track = null;
    private AlbumInfo? right_clicked_album = null;
    private bool show_gloss = true;            // setting: gloss sheen on album covers
    private string startup_view = "songs";     // setting: which view opens at launch

    // widgets
    private Gtk.Box content_area;
    private Gtk.Widget? current_child = null;
    private Gtk.Box songs_widget;
    private Gtk.Label songs_title;
    private Gtk.Label songs_sub;
    private Gtk.Button songs_back;
    private Gtk.Box playlist_box;
    private Gtk.Label status_label;
    private Gtk.Box scan_card;
    private Gtk.Label scan_label;

    // bottom-left "cranberry cup" loading indicator
    private Gtk.DrawingArea? loading_area = null;
    private int loading_count = 0;          // ref-counted so overlapping loads nest
    private double loading_phase = 0.0;     // 0..1 animation cycle
    private int64 loading_last = 0;
    private Gtk.Box display_box;

    // album grid (virtualized) + a small cache so tab-switches don't recollect
    private GLib.ListStore? album_store = null;
    private AlbumInfo[] albums_cache = {};
    private string albums_cached_for = "";   // sentinel != any real search
    private bool albums_dirty = true;

    private Gtk.Image np_art;
    private Gtk.Label np_title;
    private Gtk.Label np_sub;
    private Gtk.Label cur_time;
    private Gtk.Label dur_time;
    private Gtk.Scale seek_scale;
    private Gtk.Button play_button;
    private Gtk.Button shuffle_button;
    private Gtk.Button repeat_button;
    private Gtk.Button[] nav_buttons = {};
    private string[] nav_targets = {};

    // mini-player state
    private bool mini_mode = false;
    private int saved_w = 1180;
    private int saved_h = 760;
    private Gtk.Widget? normal_titlebar = null;
    private Gtk.Widget? normal_content = null;
    private uint mini_hide_id = 0;

    // smooth progress interpolation
    private int64 anchor_pos_us = 0;
    private int64 anchor_dur_us = 0;
    private int64 anchor_at = 0;
    private Gtk.Scale? mini_seek = null;
    private Gtk.Label? mini_cur = null;
    private Gtk.Label? mini_rem = null;
    private Gtk.Picture? mini_art = null;   // mini-player cover, updated on track change
    private Gtk.Button? mini_play = null;    // mini-player play/pause, synced to state
    // now-playing display pieces, toggled for the empty state
    private Gtk.Box? np_text_col = null;
    private Gtk.Box? np_modes = null;
    private Gtk.Overlay? np_art_overlay = null;
    private bool np_empty = true;   // true until a song plays (gates the mini hint)

    // Gold-star click sparkle — only runs while the Just Peachy theme is active.
    private Gtk.DrawingArea? star_layer = null;
    private Star[] stars = {};
    private int64 star_last = 0;

    // album-detail state
    private AlbumInfo[] album_list = {};
    private int album_index = 0;
    private Gtk.Widget? album_detail_widget = null;
    private int cover_px = 240;
    private Gdk.Texture? vinyl_cache = null;

    public MainWindow (Gtk.Application app) {
        Object (application: app);
    }

    construct {
        library = new Library ();
        player = new Player ();

        default_width = 1180;
        default_height = 760;
        title = "Cranberry Juice";
        ((Gtk.Widget) this).add_css_class ("cranberry");

        build_songs_widget ();
        register_context_actions ();
        register_menu_actions ();

        normal_titlebar = build_headerbar ();
        set_titlebar (normal_titlebar);

        var toolbar = build_toolbar ();

        var body = new Gtk.Box (Gtk.Orientation.HORIZONTAL, 0);
        body.append (build_sidebar ());
        content_area = new Gtk.Box (Gtk.Orientation.VERTICAL, 0);
        content_area.hexpand = true;
        content_area.vexpand = true;
        body.append (content_area);

        status_label = new Gtk.Label ("No music loaded");
        status_label.add_css_class ("statusbar");

        var root = new Gtk.Box (Gtk.Orientation.VERTICAL, 0);
        root.append (toolbar);
        root.append (body);
        root.append (status_label);

        var overlay = new Gtk.Overlay ();
        overlay.set_child (root);
        scan_card = build_scan_card ();
        scan_card.visible = false;
        overlay.add_overlay (scan_card);
        overlay.add_overlay (build_loading_indicator ());   // bottom-left cranberry cup
        normal_content = overlay;
        set_child (overlay);

        // Gold-star click sparkle. A transparent, click-through DrawingArea sits
        // on top of everything; a window-wide click gesture spawns a little burst
        // of gold stars at the pointer — but only when the Just Peachy theme is on.
        star_layer = new Gtk.DrawingArea ();
        star_layer.can_target = false;          // never intercept input
        star_layer.set_draw_func (draw_stars);
        overlay.add_overlay (star_layer);
        var star_click = new Gtk.GestureClick ();
        star_click.button = 0;                   // react to any mouse button
        star_click.set_propagation_phase (Gtk.PropagationPhase.CAPTURE);
        star_click.pressed.connect ((n, x, y) => {
            if (Application.current_theme == "peachy") spawn_stars (x, y);
        });
        overlay.add_controller (star_click);
        ((Gtk.Widget) this).add_tick_callback (star_tick);

        wire_player ();
        wire_library ();
        mpris = new Mpris (this);   // expose to the OS sound indicator
        ((Gtk.Widget) this).add_tick_callback (loading_tick);

        // Left/Right arrows slide between albums while the album page is open.
        var keys = new Gtk.EventControllerKey ();
        keys.set_propagation_phase (Gtk.PropagationPhase.CAPTURE);
        keys.key_pressed.connect (on_window_key);
        ((Gtk.Widget) this).add_controller (keys);

        var s = Application.settings;
        music_folder = s.get_str ("music_folder", "");
        volume = s.get_num ("volume", 0.8);
        shuffle = s.get_flag ("shuffle", false);
        repeat = s.get_str ("repeat", "off");
        show_gloss = s.get_flag ("show_gloss", true);
        startup_view = s.get_str ("startup_view", "songs");
        ALBUM_COVER_PX = cover_px_for (s.get_str ("cover_size", "medium"));
        player.set_volume (volume);
        reflect_modes ();

        rebuild_playlists ();
        set_active_nav ("songs");

        if (music_folder != "") {
            // Load the cached library instantly; only scan if there's no cache yet
            // (or if "rescan on startup" is enabled in Settings).
            bool rescan_start = s.get_flag ("rescan_on_start", false);
            if (!rescan_start && library.load_cache ()) {
                update_status ();
            } else {
                library.scan (music_folder);
            }
            navigate (startup_view);
        } else {
            show_welcome ();
        }

        // First-run welcome tour — shown once per install. Deferred to idle so it
        // appears after the main window has mapped.
        if (!s.get_flag ("seen_welcome", false)) {
            s.set_flag ("seen_welcome", true);
            GLib.Idle.add (() => {
                show_welcome_tour ();
                return GLib.Source.REMOVE;
            });
        }
    }

    // =====================================================================
    //  Title bar
    // =====================================================================
    private Gtk.Widget build_toolbar () {
        var prev = transport_icon ("media-skip-backward-symbolic");
        prev.clicked.connect (prev_track);
        play_button = transport_icon ("media-playback-start-symbolic");
        play_button.add_css_class ("play-button");
        play_button.clicked.connect (() => player.toggle ());
        var next = transport_icon ("media-skip-forward-symbolic");
        next.clicked.connect (() => next_track ());

        var vol = new Gtk.Scale.with_range (Gtk.Orientation.HORIZONTAL, 0, 1, 0.01);
        vol.draw_value = false;
        vol.set_size_request (80, -1);
        vol.set_value (volume);
        vol.value_changed.connect (() => {
            volume = vol.get_value ();
            player.set_volume (volume);
            Application.settings.set_num ("volume", volume);
        });

        shuffle_button = new Gtk.Button.from_icon_name ("media-playlist-shuffle-symbolic");
        shuffle_button.add_css_class ("mode-button");
        shuffle_button.tooltip_text = "Shuffle";
        shuffle_button.clicked.connect (() => {
            shuffle = !shuffle;
            reshuffle_around_current ();
            reflect_modes ();
            Application.settings.set_flag ("shuffle", shuffle);
        });
        repeat_button = new Gtk.Button.from_icon_name ("media-playlist-repeat-symbolic");
        repeat_button.add_css_class ("mode-button");
        repeat_button.tooltip_text = "Repeat";
        repeat_button.clicked.connect (() => {
            repeat = (repeat == "off") ? "all" : (repeat == "all") ? "one" : "off";
            reflect_modes ();
            Application.settings.set_str ("repeat", repeat);
        });

        var left = new Gtk.Box (Gtk.Orientation.HORIZONTAL, 6);
        left.append (prev);
        left.append (play_button);
        left.append (next);
        left.append (vol);

        // centred now-playing display
        np_art = new Gtk.Image ();
        np_art.pixel_size = 38;
        // Empty state: the Cranberry Juice icon, no text, until something plays.
        np_art.set_from_paintable (Gdk.Texture.from_resource ("/io/github/cranberry/juice/appicon.png"));
        np_art.add_css_class ("np-art");
        // Album art: hover shows a Mini-Player hint, click opens the Mini Player.
        var art_hint = new Gtk.Image.from_icon_name ("view-restore-symbolic");
        art_hint.pixel_size = 16;
        art_hint.add_css_class ("art-hint");
        art_hint.halign = Gtk.Align.CENTER;
        art_hint.valign = Gtk.Align.CENTER;
        art_hint.opacity = 0;
        np_art_overlay = new Gtk.Overlay ();
        np_art_overlay.set_child (np_art);
        np_art_overlay.add_overlay (art_hint);
        np_art_overlay.tooltip_text = "Switch to Mini Player";
        var art_click = new Gtk.GestureClick ();
        // Only act on the album art of a playing song — never the empty-state icon.
        art_click.released.connect (() => { if (!np_empty) enter_mini (); });
        np_art_overlay.add_controller (art_click);
        var art_hover = new Gtk.EventControllerMotion ();
        np_art_overlay.add_controller (art_hover);
        art_hover.enter.connect ((x, y) => { if (!np_empty) art_hint.opacity = 1; });
        art_hover.leave.connect (() => { art_hint.opacity = 0; });

        np_title = new Gtk.Label ("");
        np_title.add_css_class ("np-title");
        np_title.ellipsize = Pango.EllipsizeMode.END;
        np_title.xalign = 0;
        np_sub = new Gtk.Label ("");
        np_sub.add_css_class ("np-sub");
        np_sub.ellipsize = Pango.EllipsizeMode.END;
        np_sub.xalign = 0;

        cur_time = new Gtk.Label ("0:00");
        cur_time.add_css_class ("np-time");
        dur_time = new Gtk.Label ("0:00");
        dur_time.add_css_class ("np-time");
        seek_scale = new Gtk.Scale.with_range (Gtk.Orientation.HORIZONTAL, 0, 1, 0.001);
        seek_scale.draw_value = false;
        seek_scale.add_css_class ("seek");
        seek_scale.hexpand = true;
        seek_scale.change_value.connect ((scroll, val) => {
            double f = val < 0 ? 0 : (val > 1 ? 1 : val);
            player.seek_fraction (f);
            return false;
        });

        var seek_row = new Gtk.Box (Gtk.Orientation.HORIZONTAL, 7);
        seek_row.append (cur_time);
        seek_row.append (seek_scale);
        seek_row.append (dur_time);

        np_text_col = new Gtk.Box (Gtk.Orientation.VERTICAL, 0);
        np_text_col.hexpand = true;
        np_text_col.valign = Gtk.Align.CENTER;
        np_text_col.append (np_title);
        np_text_col.append (np_sub);
        np_text_col.append (seek_row);

        np_modes = new Gtk.Box (Gtk.Orientation.HORIZONTAL, 0);
        np_modes.valign = Gtk.Align.CENTER;
        np_modes.append (shuffle_button);
        np_modes.append (repeat_button);
        var queue_btn = new Gtk.Button.from_icon_name ("view-list-symbolic");
        queue_btn.add_css_class ("mode-button");
        queue_btn.tooltip_text = "Up Next";
        queue_btn.clicked.connect (() => show_queue_popover (queue_btn));
        np_modes.append (queue_btn);

        display_box = new Gtk.Box (Gtk.Orientation.HORIZONTAL, 10);
        display_box.add_css_class ("np-display");
        display_box.append (np_art_overlay);
        display_box.append (np_text_col);
        display_box.append (np_modes);
        display_box.set_size_request (460, -1);
        set_empty_state (true);   // nothing playing yet → just the centred icon

        var search = new Gtk.SearchEntry ();
        search.placeholder_text = "Search";
        search.search_changed.connect (() => {
            search_text = search.text.strip ();
            refresh_current_view ();
        });

        var viz_button = transport_icon ("view-reveal-symbolic");
        viz_button.tooltip_text = "Audio-reactive visuals";
        viz_button.clicked.connect (open_visuals);

        var right = new Gtk.Box (Gtk.Orientation.HORIZONTAL, 8);
        right.append (viz_button);
        right.append (search);

        var bar = new Gtk.CenterBox ();
        bar.add_css_class ("cranberry-titlebar");
        bar.set_start_widget (left);
        bar.set_center_widget (display_box);
        bar.set_end_widget (right);
        return bar;
    }

    private Gtk.Button transport_icon (string icon) {
        var b = new Gtk.Button.from_icon_name (icon);
        b.add_css_class ("transport-button");
        return b;
    }

    // =====================================================================
    //  Header bar (native window controls + drag) + a classic menu bar
    // =====================================================================
    private Gtk.Widget build_headerbar () {
        var header = new Gtk.HeaderBar ();
        header.show_title_buttons = true;
        header.pack_start (new Gtk.PopoverMenuBar.from_model (build_menu_model ()));
        return header;
    }

    private GLib.MenuModel build_menu_model () {
        var menu = new GLib.Menu ();

        var file = new GLib.Menu ();
        file.append ("Open Music Folder…", "win.choosefolder");
        file.append ("Rescan Library", "win.rescan");
        file.append ("Quit", "win.quit");
        menu.append_submenu ("File", file);

        var song = new GLib.Menu ();
        song.append ("Play", "win.songplay");
        song.append ("Track Details", "win.songinfo");
        menu.append_submenu ("Song", song);

        var view = new GLib.Menu ();
        view.append ("Mini Player (Ctrl+Shift+M)", "win.miniplayer");
        view.append ("Audio-reactive visuals", "win.visuals");
        var viewopts = new GLib.Menu ();
        viewopts.append ("Songs", "win.view-songs");
        viewopts.append ("Albums", "win.view-albums");
        viewopts.append ("Artists", "win.view-artists");
        viewopts.append ("Genres", "win.view-genres");
        viewopts.append ("Composers", "win.view-composers");
        view.append_section (null, viewopts);
        menu.append_submenu ("View", view);

        var controls = new GLib.Menu ();
        controls.append ("Play / Pause", "win.playpause");
        controls.append ("Next", "win.next");
        controls.append ("Previous", "win.previous");
        controls.append ("Smart Shuffle", "win.smartshuffle");
        var modes = new GLib.Menu ();
        modes.append ("Shuffle", "win.shuffle");
        modes.append ("Repeat", "win.repeat");
        controls.append_section (null, modes);
        menu.append_submenu ("Controls", controls);

        var tools = new GLib.Menu ();
        tools.append ("Fix Album Grouping…", "win.fixalbums");
        tools.append ("Burn CD to Library…", "win.burncd");
        menu.append_submenu ("Tools", tools);

        var help = new GLib.Menu ();
        help.append ("Settings…", "win.settings");
        help.append ("About Cranberry Juice", "win.about");
        menu.append_submenu ("Help", help);

        return menu;
    }

    private void add_simple (string name, owned Action cb) {
        var act = new SimpleAction (name, null);
        act.activate.connect (() => cb ());
        add_action (act);
    }

    private void register_menu_actions () {
        add_simple ("choosefolder", () => choose_folder ());
        add_simple ("rescan", () => { if (music_folder != "") library.scan (music_folder); else choose_folder (); });
        add_simple ("quit", () => close ());
        add_simple ("songplay", () => { var t = selection.get_selected_item () as Track; if (t != null) play_paths_single (t); });
        add_simple ("songinfo", () => { var t = selection.get_selected_item () as Track; if (t != null) show_track_details (t); });
        add_simple ("visuals", () => open_visuals ());
        add_simple ("miniplayer", () => { if (mini_mode) exit_mini (); else enter_mini (); });
        add_simple ("view-songs", () => navigate ("songs"));
        add_simple ("view-albums", () => navigate ("albums"));
        add_simple ("view-artists", () => navigate ("artists"));
        add_simple ("view-genres", () => navigate ("genres"));
        add_simple ("view-composers", () => navigate ("composers"));
        add_simple ("playpause", () => player.toggle ());
        add_simple ("next", () => next_track ());
        add_simple ("previous", () => prev_track ());
        add_simple ("shuffle", () => { shuffle = !shuffle; reshuffle_around_current (); reflect_modes (); Application.settings.set_flag ("shuffle", shuffle); });
        add_simple ("repeat", () => { repeat = (repeat == "off") ? "all" : (repeat == "all") ? "one" : "off"; reflect_modes (); Application.settings.set_str ("repeat", repeat); });
        add_simple ("smartshuffle", () => smart_shuffle ());
        add_simple ("settings", () => show_settings ());
        add_simple ("about", () => show_about ());
        add_simple ("burncd", () => show_burn_cd ());
        add_simple ("fixalbums", () => show_fix_albums ());

        var app = application;
        if (app != null) {
            app.set_accels_for_action ("win.visuals", { "<Control>t" });
            app.set_accels_for_action ("win.miniplayer", { "<Control><Shift>m" });
            app.set_accels_for_action ("win.quit", { "<Control>q" });
        }
    }

    // =====================================================================
    //  First-run welcome tour
    // =====================================================================

    // A short, multi-page intro shown once on first launch. Four pages:
    // Notable Features (incl. a Discogs explainer), Your Music Folder, Themes,
    // and a closing welcome. No images beyond the app icon; plain text.
    private void show_welcome_tour () {
        var dialog = new Gtk.Window ();
        dialog.title = "Welcome";
        dialog.transient_for = this;
        dialog.modal = true;
        dialog.default_width = 540;
        dialog.default_height = 480;
        dialog.add_css_class ("cranberry");

        var stack = new Gtk.Stack ();
        stack.vexpand = true;
        stack.transition_type = Gtk.StackTransitionType.SLIDE_LEFT_RIGHT;
        stack.add_named (welcome_page_features (), "p0");
        stack.add_named (welcome_page_folder (dialog), "p1");
        stack.add_named (welcome_page_themes (), "p2");
        stack.add_named (welcome_page_hello (), "p3");

        int total = 4;
        int[] idx = { 0 };   // one-element array so the closures can mutate it

        var back = new Gtk.Button.with_label ("Back");
        back.add_css_class ("pill");
        var next = new Gtk.Button.with_label ("Next");
        next.add_css_class ("pill");
        next.add_css_class ("accent");
        var skip = new Gtk.Button.with_label ("Skip");
        skip.add_css_class ("pill");
        var step = new Gtk.Label ("");
        step.add_css_class ("content-sub");

        Action refresh = () => {
            stack.set_visible_child_name ("p" + idx[0].to_string ());
            back.sensitive = idx[0] > 0;
            back.opacity = idx[0] > 0 ? 1.0 : 0.0;
            next.label = (idx[0] == total - 1) ? "Get Started" : "Next";
            skip.visible = idx[0] < total - 1;
            step.label = "%d of %d".printf (idx[0] + 1, total);
        };

        back.clicked.connect (() => { if (idx[0] > 0) { idx[0]--; refresh (); } });
        next.clicked.connect (() => {
            if (idx[0] < total - 1) { idx[0]++; refresh (); }
            else dialog.destroy ();
        });
        skip.clicked.connect (() => dialog.destroy ());

        var nav = new Gtk.Box (Gtk.Orientation.HORIZONTAL, 8);
        nav.margin_start = 18; nav.margin_end = 18;
        nav.margin_top = 4; nav.margin_bottom = 16;
        nav.append (back);
        nav.append (skip);
        var sp1 = new Gtk.Box (Gtk.Orientation.HORIZONTAL, 0);
        sp1.hexpand = true;
        nav.append (sp1);
        nav.append (step);
        var sp2 = new Gtk.Box (Gtk.Orientation.HORIZONTAL, 0);
        sp2.hexpand = true;
        nav.append (sp2);
        nav.append (next);

        var root = new Gtk.Box (Gtk.Orientation.VERTICAL, 8);
        root.append (stack);
        root.append (nav);
        dialog.set_child (root);
        refresh ();
        dialog.present ();
    }

    // Wrap a page's widgets in a padded, vertically-scrolling box.
    private Gtk.Widget welcome_page (Gtk.Widget[] kids) {
        var box = new Gtk.Box (Gtk.Orientation.VERTICAL, 10);
        box.margin_top = 22; box.margin_bottom = 10;
        box.margin_start = 24; box.margin_end = 24;
        foreach (var k in kids) box.append (k);
        var scroller = new Gtk.ScrolledWindow ();
        scroller.vexpand = true;
        scroller.hscrollbar_policy = Gtk.PolicyType.NEVER;
        scroller.set_child (box);
        return scroller;
    }

    private Gtk.Widget welcome_page_features () {
        var title = new Gtk.Label ("Notable Features");
        title.add_css_class ("welcome-title");
        title.xalign = 0;

        var feats = new Gtk.Label (
            "• A native player for your local music — point it at a folder and it plays your files with GStreamer. No accounts, no cloud.\n" +
            "• Audio-reactive visuals — a gallery of fullscreen visualizers that move with the music.\n" +
            "• Browse by song, album, artist, or genre, with fast cached cover art.\n" +
            "• A compact Mini Player, shuffle with a reorderable Up Next queue, and sound-indicator (MPRIS) controls.\n" +
            "• Edit album and per-song info and cover art (right-click an album, or open a song's Properties).\n" +
            "• Seven themes, including Just Peachy (a gold-star click sparkle) and Grimace (dark purple).\n" +
            "• Burn a CD to your library — import an audio CD straight into your music folder (see below).");
        feats.add_css_class ("content-sub");
        feats.xalign = 0;
        feats.wrap = true;
        feats.max_width_chars = 54;

        var cd_h = new Gtk.Label ("Burning a CD to your library");
        cd_h.add_css_class ("side-title");
        cd_h.xalign = 0;
        cd_h.margin_top = 8;
        var cd = new Gtk.Label (
            "If your computer has a CD or DVD drive, open Tools → Burn CD to Library and insert an " +
            "audio CD, then detect it. Cranberry Juice reads the disc, pulls track titles from CD-TEXT " +
            "when the disc has them (you can edit everything first), and imports each track as a " +
            "lossless FLAC file into your music folder — organised as Album Artist / Album / NN Title.flac. " +
            "Your library refreshes automatically when it finishes.");
        cd.add_css_class ("content-sub");
        cd.xalign = 0;
        cd.wrap = true;
        cd.max_width_chars = 54;

        var disc_h = new Gtk.Label ("About Discogs");
        disc_h.add_css_class ("side-title");
        disc_h.xalign = 0;
        disc_h.margin_top = 8;
        var disc = new Gtk.Label (
            "Discogs is a large, community-run music database. It is optional: if you add a free " +
            "Discogs token in Settings, Cranberry Juice can fetch artist photos and richer genre " +
            "tags, and build a genre-based Smart Shuffle playlist. Without a token, nothing is sent " +
            "anywhere — the app stays fully offline.");
        disc.add_css_class ("content-sub");
        disc.xalign = 0;
        disc.wrap = true;
        disc.max_width_chars = 54;

        return welcome_page ({ title, feats, cd_h, cd, disc_h, disc });
    }

    private Gtk.Widget welcome_page_folder (Gtk.Window dialog) {
        var title = new Gtk.Label ("Your Music Folder");
        title.add_css_class ("welcome-title");
        title.xalign = 0;
        var body = new Gtk.Label (
            "Cranberry Juice plays music from one folder on your computer. Choose the folder where " +
            "your music lives and the app will scan it, cache the cover art, and play from there. " +
            "You can change it any time in Settings under General.");
        body.add_css_class ("content-sub");
        body.xalign = 0; body.wrap = true; body.max_width_chars = 54;

        var current = new Gtk.Label (
            music_folder == "" ? "No folder set yet." : "Current folder: " + music_folder);
        current.add_css_class ("content-sub");
        current.xalign = 0; current.wrap = true; current.max_width_chars = 54;
        current.margin_top = 4;

        var choose = new Gtk.Button.with_label ("Choose Music Folder…");
        choose.add_css_class ("pill");
        choose.add_css_class ("accent");
        choose.halign = Gtk.Align.START;
        choose.margin_top = 8;
        // Picking a folder finishes the tour and opens the folder chooser.
        choose.clicked.connect (() => { dialog.destroy (); choose_folder (); });

        return welcome_page ({ title, body, current, choose });
    }

    private Gtk.Widget welcome_page_themes () {
        var title = new Gtk.Label ("Themes");
        title.add_css_class ("welcome-title");
        title.xalign = 0;
        var body = new Gtk.Label (
            "Make it yours. Cranberry Juice ships with six looks:\n\n" +
            "• Dark Glass — the default translucent dark theme.\n" +
            "• Light — a clean, heavy white theme.\n" +
            "• Cranberry Red — bold and vivid.\n" +
            "• Leaf Green — a deep, dark green look.\n" +
            "• Deep Blue — a deep, dark blue look.\n" +
            "• Just Peachy — salmon-pink frosted glass that sends up a little gold-star sparkle on every click.\n\n" +
            "Switch themes any time in Settings under Theme.");
        body.add_css_class ("content-sub");
        body.xalign = 0; body.wrap = true; body.max_width_chars = 54;
        return welcome_page ({ title, body });
    }

    private Gtk.Widget welcome_page_hello () {
        var icon = new Gtk.Image.from_paintable (
            Gdk.Texture.from_resource ("/io/github/cranberry/juice/appicon.png"));
        icon.pixel_size = 88;
        icon.margin_top = 10;
        var title = new Gtk.Label ("Welcome to Cranberry Juice!");
        title.add_css_class ("welcome-title");
        title.justify = Gtk.Justification.CENTER;
        var body = new Gtk.Label ("You are all set. Press Get Started and enjoy your music.");
        body.add_css_class ("content-sub");
        body.wrap = true;
        body.justify = Gtk.Justification.CENTER;
        body.max_width_chars = 44;

        var box = new Gtk.Box (Gtk.Orientation.VERTICAL, 12);
        box.valign = Gtk.Align.CENTER;
        box.halign = Gtk.Align.CENTER;
        box.margin_top = 24; box.margin_bottom = 24;
        box.margin_start = 24; box.margin_end = 24;
        box.append (icon);
        box.append (title);
        box.append (body);
        return box;
    }

    // =====================================================================
    //  Gold-star click sparkle (Just Peachy theme only)
    // =====================================================================

    // Spawn a small burst of gold stars at (x, y), in star_layer coordinates.
    private void spawn_stars (double x, double y) {
        int n = 8 + (int) (Random.next_double () * 5);   // 8..12 stars
        for (int i = 0; i < n; i++) {
            double ang = Random.next_double () * Math.PI * 2.0;
            double spd = 40.0 + Random.next_double () * 130.0;   // px/s
            Star s = Star ();
            s.x = x;
            s.y = y;
            s.vx = Math.cos (ang) * spd;
            s.vy = Math.sin (ang) * spd - 70.0;              // bias upward
            s.life = 1.0;
            s.rot = Random.next_double () * Math.PI * 2.0;
            s.spin = (Random.next_double () - 0.5) * 9.0;
            s.size = 5.0 + Random.next_double () * 7.0;
            stars += s;
        }
        if (star_layer != null) star_layer.queue_draw ();
    }

    // Per-frame advance: move, fall, fade, drop dead stars, request a redraw.
    private bool star_tick (Gtk.Widget w, Gdk.FrameClock fc) {
        int64 now = fc.get_frame_time ();
        if (star_last == 0) star_last = now;
        double dt = (now - star_last) / 1000000.0;
        star_last = now;
        if (stars.length == 0) return true;          // idle, keep callback alive
        if (dt > 0.05) dt = 0.05;                     // clamp after a stall
        Star[] alive = {};
        foreach (Star s in stars) {
            s.x += s.vx * dt;
            s.y += s.vy * dt;
            s.vy += 240.0 * dt;                       // gravity
            s.rot += s.spin * dt;
            s.life -= dt / 0.9;                       // ~0.9s lifespan
            if (s.life > 0.0) alive += s;
        }
        stars = alive;
        if (star_layer != null) star_layer.queue_draw ();
        return true;
    }

    private void draw_stars (Gtk.DrawingArea da, Cairo.Context cr, int width, int height) {
        foreach (Star s in stars) {
            double a = (s.life > 1.0) ? 1.0 : s.life;
            cr.save ();
            cr.translate (s.x, s.y);
            cr.rotate (s.rot);
            star_path (cr, s.size);
            cr.set_source_rgba (1.0, 0.84, 0.0, a);            // gold fill
            cr.fill_preserve ();
            cr.set_source_rgba (1.0, 0.96, 0.7, a * 0.9);      // pale gold rim
            cr.set_line_width (1.0);
            cr.stroke ();
            cr.restore ();
        }
    }

    // Build a five-pointed star path of outer radius r, centred on the origin.
    private void star_path (Cairo.Context cr, double r) {
        double inner = r * 0.4;
        for (int i = 0; i < 10; i++) {
            double rad = (i % 2 == 0) ? r : inner;
            double ang = -Math.PI / 2.0 + i * Math.PI / 5.0;
            double px = Math.cos (ang) * rad;
            double py = Math.sin (ang) * rad;
            if (i == 0) cr.move_to (px, py);
            else cr.line_to (px, py);
        }
        cr.close_path ();
    }

    // A custom About window: app icon above a (non-selectable) title, version,
    // and a clickable Version History. Avoids Gtk.AboutDialog's selectable name.
    private void show_about () {
        var dialog = new Gtk.Window ();
        dialog.title = "About Cranberry Juice";
        dialog.transient_for = this;
        dialog.modal = true;
        dialog.default_width = 400;
        dialog.add_css_class ("cranberry");

        var icon = new Gtk.Image.from_paintable (
            Gdk.Texture.from_resource ("/io/github/cranberry/juice/appicon.png"));
        icon.pixel_size = 96;
        icon.margin_top = 6;

        var name = new Gtk.Label ("Cranberry Juice");
        name.add_css_class ("welcome-title");
        name.selectable = false;

        var ver = new Gtk.Label ("Version 37.0.0");
        ver.add_css_class ("content-sub");
        ver.selectable = false;

        var blurb = new Gtk.Label ("A native music player for elementary OS, with audio-reactive visuals.");
        blurb.add_css_class ("content-sub");
        blurb.wrap = true;
        blurb.justify = Gtk.Justification.CENTER;
        blurb.max_width_chars = 40;

        var history = new Gtk.Button.with_label ("Version History");
        history.add_css_class ("pill");
        history.clicked.connect (() => show_version_history ());
        var close = new Gtk.Button.with_label ("Close");
        close.add_css_class ("pill");
        close.add_css_class ("accent");
        close.clicked.connect (() => dialog.destroy ());
        var btns = new Gtk.Box (Gtk.Orientation.HORIZONTAL, 8);
        btns.halign = Gtk.Align.CENTER;
        btns.margin_top = 6;
        btns.append (history);
        btns.append (close);

        var box = new Gtk.Box (Gtk.Orientation.VERTICAL, 8);
        box.margin_top = 24; box.margin_bottom = 24;
        box.margin_start = 24; box.margin_end = 24;
        box.halign = Gtk.Align.CENTER;
        box.append (icon);
        box.append (name);
        box.append (ver);
        box.append (blurb);
        box.append (btns);
        dialog.set_child (box);
        dialog.present ();
    }

    private void show_version_history () {
        var dialog = new Gtk.Window ();
        dialog.title = "Version History";
        dialog.transient_for = this;
        dialog.modal = true;
        dialog.default_width = 540;
        dialog.default_height = 580;
        dialog.add_css_class ("cranberry");

        var text = new Gtk.Label (version_history_text ());
        text.use_markup = true;
        text.wrap = true;
        text.xalign = 0;
        text.yalign = 0;
        text.selectable = true;
        text.add_css_class ("content-sub");
        text.margin_top = 16; text.margin_bottom = 16;
        text.margin_start = 18; text.margin_end = 18;

        var scroller = new Gtk.ScrolledWindow ();
        scroller.vexpand = true;
        scroller.set_child (text);

        var close = new Gtk.Button.with_label ("Close");
        close.add_css_class ("pill");
        close.add_css_class ("accent");
        close.halign = Gtk.Align.END;
        close.margin_end = 18; close.margin_bottom = 14;
        close.clicked.connect (() => dialog.destroy ());

        var box = new Gtk.Box (Gtk.Orientation.VERTICAL, 8);
        box.append (scroller);
        box.append (close);
        dialog.set_child (box);
        dialog.present ();
    }

    // The running changelog shown in About → Version History. Keep this updated
    // each release (newest first). Pango markup; avoid raw & < > characters.
    private string version_history_text () {
        return
        "<b>Version 37</b>\n" +
        "Albums now stay together. Every song from the same album is grouped by its album folder, so a collaboration album whose tracks each have a different artist no longer splits into many — it shows as one album by \"Various Artists\". A real album-artist tag is used when present. Added Tools → Fix Album Grouping (with a one-click rescan to refresh grouping and artwork).\n\n" +
        "<b>Version 36</b>\n" +
        "Added an Uninstall option to the app's right-click menu in the Applications list — it removes the install with one admin password prompt. Also ships an uninstall.sh script that removes everything (Flatpak and native) in one go.\n\n" +
        "<b>Version 35</b>\n" +
        "Finalised the album-cover gloss so it fits the cover exactly (covers are now a fixed, clipped square — no more inset box). New Settings options: which view opens at startup, album cover size, a gloss on/off switch, rescan-library-on-startup, and CD rip format (FLAC / OGG / MP3) plus CD device. The View menu now shows the Mini Player shortcut (Ctrl+Shift+M).\n\n" +
        "<b>Version 34</b>\n" +
        "New Tools menu with Burn CD to Library — read an audio CD from your drive and import it into your music folder as lossless FLAC, organised as Album Artist / Album / NN Title.flac, with titles from CD-TEXT (editable) and metadata applied. Also fixed the album-cover gloss so it fills the whole cover instead of showing an inset box.\n\n" +
        "<b>Version 33</b>\n" +
        "Right-click an album to edit its info — album title, album artist, genre, year, and the cover art — and the change applies to every song in the album. The song Properties editor can now set per-song art too. Both editors show the current cover (or the Cranberry icon if there is none); click it to pick an image. Edits are saved to your library, not the original files.\n\n" +
        "<b>Version 32</b>\n" +
        "New Grimace theme — a deep, dark purple look with iridescent violet accents, tuned for comfortable contrast.\n\n" +
        "<b>Version 31</b>\n" +
        "A guided welcome tour now greets you on first launch — notable features, choosing your music folder, and themes. New Just Peachy theme: a salmon-pink frosted-glass look, with a little gold-star sparkle that follows your clicks. The blue theme is now called Deep Blue. Fixed a readability issue on the selected theme card in Settings so its name stays legible in every theme.\n\n" +
        "<b>Version 30</b>\n" +
        "Security and privacy pass. Confirmed the app makes no network connections at all unless Discogs is enabled and a token is entered (no telemetry, no update checks). Discogs downloads are now HTTPS-only and size-capped, and the Flatpak sandbox is tightened to read-only home so the app can never modify your files. Added SECURITY.md.\n\n" +
        "<b>Version 29</b>\n" +
        "Opening a single audio file now queues the whole folder, so Skip / Next in the Mini Player plays through the other songs alongside it. New Deep Blue theme (a deep, dark blue, sibling to Leaf Green).\n\n" +
        "<b>Version 28</b>\n" +
        "New Leaf Green theme. The song list and search box now follow the selected theme (were stuck on the dark default). The album cover gloss now spans the whole cover instead of a small box. The loading cup also shows during Discogs fetches. The Flatpak build now also produces a single shareable cranberry-juice.flatpak file.\n\n" +
        "<b>Version 27</b>\n" +
        "Verified checkpoint with a full sanity pass. Flatpak build script corrected to add elementary's own Flatpak repo (the runtime that provides Granite is not on Flathub) and to self-report the available runtime version if it differs.\n\n" +
        "<b>Version 26</b>\n" +
        "Light-theme fix: song titles in the album detail tracklist (and the Up Next list) are now near-black instead of grey.\n\n" +
        "<b>Version 25</b>\n" +
        "Flatpak packaging. Expanded Discogs settings: auto-apply artist photos, create a random playlist from a genre, and everything cached so your changes stay even if Discogs is turned off. About redesigned with the app icon and this Version History.\n\n" +
        "<b>Version 24</b>\n" +
        "Light-theme song names are now near-black. Registers as a default audio player (rebuilds the desktop/MIME database). Opening an audio file plays it in the Mini Player.\n\n" +
        "<b>Version 23</b>\n" +
        "Light theme polished (near-black text, themed content background). Discogs went live: artist photos in the Artists view and genre-based Smart Shuffle.\n\n" +
        "<b>Version 22</b>\n" +
        "Tabbed Settings. Three themes (Dark Glass, Light, Cranberry Red). Sound-indicator (MPRIS) integration. Discogs toggle and token.\n\n" +
        "<b>Version 21</b>\n" +
        "Album labels aligned under covers. Audio-reactive visuals sharpened cava-style (log bins, gravity smoothing, auto-sensitivity). Fireworks fixed.\n\n" +
        "<b>Version 20</b>\n" +
        "Borderless album covers with a gloss and drop shadow. Album grid virtualized for smooth scrolling with thousands of albums.\n\n" +
        "<b>Version 19</b>\n" +
        "Album covers shown as fixed full squares.\n\n" +
        "<b>Version 18</b>\n" +
        "Full square covers in exactly six columns. Ctrl+Shift+M Mini Player hotkey. Grey bubble around the mini progress bar.\n\n" +
        "<b>Version 17</b>\n" +
        "Albums view redesigned with large square covers.\n\n" +
        "<b>Version 16</b>\n" +
        "Spacebar play/pause. Mini Player live updates. Right-click Play Next and editable Properties. Faster Albums tab. Cranberry-cup loading indicator.\n\n" +
        "<b>Version 15</b>\n" +
        "Shuffle-aware Up Next with reordering. Slim icon sidebar. Mini Player shortcut and View-menu entry.\n\n" +
        "<b>Version 14</b>\n" +
        "Compact Mini Player (cover plus a hover glass panel). Empty-state now-playing.\n\n" +
        "<b>Version 13</b>\n" +
        "Mini Player hover hint. Window shrinks from fullscreen. Fluid progress bar.\n\n" +
        "<b>Version 12</b>\n" +
        "Audio-reactive visuals actually react to the music (fixed the spectrum wiring).\n\n" +
        "<b>Version 11</b>\n" +
        "Mini Player. Shuffle history so Previous walks back correctly.\n\n" +
        "<b>Version 10</b>\n" +
        "Library cached to disk, so no more re-scanning on every launch.\n\n" +
        "<b>Version 9</b>\n" +
        "Multi-album grid. Up Next queue button. Cranberry icon empty state.\n\n" +
        "<b>Version 8</b>\n" +
        "Narrower sidebar. Shuffle fixed. Settings dialog.\n\n" +
        "<b>Version 7</b>\n" +
        "Fast Albums loading with cached artwork. Correct About version.\n\n" +
        "<b>Version 6</b>\n" +
        "Album detail with the sliding vinyl record. Fullscreen visuals. Default-player support.\n\n" +
        "<b>Version 5</b>\n" +
        "Native window controls and menu bar. Faster scan. Appears in the applications menu.\n\n" +
        "<b>Versions 1 to 4</b>\n" +
        "Early builds: core library scanning, playback, and the first audio-reactive visuals.";
    }

    private void show_settings () {
        var dialog = new Gtk.Window ();
        dialog.title = "Settings";
        dialog.transient_for = this;
        dialog.modal = true;
        dialog.default_width = 520;
        dialog.default_height = 560;
        dialog.add_css_class ("cranberry");

        var stack = new Gtk.Stack ();
        stack.vexpand = true;
        stack.add_titled (build_settings_general (dialog), "general", "General");
        stack.add_titled (build_settings_theme (), "theme", "Theme");
        stack.add_titled (build_settings_discogs (), "discogs", "Discogs");

        var switcher = new Gtk.StackSwitcher ();
        switcher.stack = stack;
        switcher.halign = Gtk.Align.CENTER;
        switcher.margin_top = 14;

        var version = new Gtk.Label ("Cranberry Juice 37.0.0");
        version.add_css_class ("content-sub");
        version.xalign = 0;
        var close = new Gtk.Button.with_label ("Done");
        close.add_css_class ("pill");
        close.add_css_class ("accent");
        close.halign = Gtk.Align.END;
        close.clicked.connect (() => dialog.destroy ());
        var footer = new Gtk.Box (Gtk.Orientation.HORIZONTAL, 10);
        footer.margin_start = 20; footer.margin_end = 20; footer.margin_bottom = 16;
        footer.append (version);
        var spacer = new Gtk.Box (Gtk.Orientation.HORIZONTAL, 0);
        spacer.hexpand = true;
        footer.append (spacer);
        footer.append (close);

        var root = new Gtk.Box (Gtk.Orientation.VERTICAL, 8);
        root.append (switcher);
        root.append (stack);
        root.append (footer);
        dialog.set_child (root);
        dialog.present ();
    }

    private Gtk.Widget build_settings_general (Gtk.Window dialog) {
        var folder_caption = new Gtk.Label ("Music Folder");
        folder_caption.add_css_class ("side-title");
        folder_caption.xalign = 0;
        var folder_lbl = new Gtk.Label (music_folder == "" ? "(not set)" : music_folder);
        folder_lbl.add_css_class ("content-sub");
        folder_lbl.xalign = 0;
        folder_lbl.wrap = true;
        folder_lbl.selectable = true;
        var change = new Gtk.Button.with_label ("Change…");
        change.add_css_class ("pill");
        change.clicked.connect (() => { dialog.destroy (); choose_folder (); });
        var rescan = new Gtk.Button.with_label ("Rescan Library");
        rescan.add_css_class ("pill");
        rescan.clicked.connect (() => { if (music_folder != "") library.scan (music_folder); });
        var folder_btns = new Gtk.Box (Gtk.Orientation.HORIZONTAL, 8);
        folder_btns.append (change);
        folder_btns.append (rescan);

        var viz_caption = new Gtk.Label ("Audio-reactive visuals");
        viz_caption.add_css_class ("side-title");
        viz_caption.xalign = 0;
        var open_viz = new Gtk.Button.with_label ("Open Visuals (Ctrl+T)");
        open_viz.add_css_class ("pill");
        open_viz.halign = Gtk.Align.START;
        open_viz.clicked.connect (() => { dialog.destroy (); open_visuals (); });

        // ---- Library & display ----
        var disp_caption = new Gtk.Label ("Library & display");
        disp_caption.add_css_class ("side-title"); disp_caption.xalign = 0;

        string[] view_keys  = { "songs", "albums", "artists", "genres", "composers" };
        string[] view_names = { "Songs", "Albums", "Artists", "Genres", "Composers" };
        var startup_dd = new Gtk.DropDown.from_strings (view_names);
        startup_dd.selected = (uint) index_of (view_keys, Application.settings.get_str ("startup_view", "songs"));
        startup_dd.notify["selected"].connect (() => {
            int i = (int) startup_dd.selected;
            if (i >= 0 && i < view_keys.length) {
                startup_view = view_keys[i];
                Application.settings.set_str ("startup_view", view_keys[i]);
            }
        });

        string[] size_keys  = { "small", "medium", "large" };
        string[] size_names = { "Small", "Medium", "Large" };
        var size_dd = new Gtk.DropDown.from_strings (size_names);
        size_dd.selected = (uint) index_of (size_keys, Application.settings.get_str ("cover_size", "medium"));
        size_dd.notify["selected"].connect (() => {
            int i = (int) size_dd.selected;
            if (i >= 0 && i < size_keys.length) {
                Application.settings.set_str ("cover_size", size_keys[i]);
                ALBUM_COVER_PX = cover_px_for (size_keys[i]);
                grid_vinyl_cache = null;
                albums_dirty = true;
                if (view == "albums") show_albums ();
            }
        });

        var gloss_sw = new Gtk.Switch ();
        gloss_sw.active = show_gloss; gloss_sw.valign = Gtk.Align.CENTER;
        gloss_sw.state_set.connect ((st) => {
            show_gloss = st;
            Application.settings.set_flag ("show_gloss", st);
            albums_dirty = true;
            if (view == "albums") show_albums ();
            return false;
        });

        var rescan_sw = new Gtk.Switch ();
        rescan_sw.active = Application.settings.get_flag ("rescan_on_start", false);
        rescan_sw.valign = Gtk.Align.CENTER;
        rescan_sw.state_set.connect ((st) => {
            Application.settings.set_flag ("rescan_on_start", st);
            return false;
        });

        // ---- CD ripping ----
        var cd_caption = new Gtk.Label ("CD ripping");
        cd_caption.add_css_class ("side-title"); cd_caption.xalign = 0;

        string[] fmt_keys  = { "flac", "ogg", "mp3" };
        string[] fmt_names = { "FLAC (lossless)", "OGG Vorbis", "MP3" };
        var fmt_dd = new Gtk.DropDown.from_strings (fmt_names);
        fmt_dd.selected = (uint) index_of (fmt_keys, Application.settings.get_str ("rip_format", "flac"));
        fmt_dd.notify["selected"].connect (() => {
            int i = (int) fmt_dd.selected;
            if (i >= 0 && i < fmt_keys.length) Application.settings.set_str ("rip_format", fmt_keys[i]);
        });

        var dev_entry = new Gtk.Entry ();
        dev_entry.text = Application.settings.get_str ("cd_device", "/dev/cdrom");
        dev_entry.hexpand = true;
        dev_entry.changed.connect (() => Application.settings.set_str ("cd_device", dev_entry.text));

        var box = settings_page ();
        box.append (folder_caption);
        box.append (folder_lbl);
        box.append (folder_btns);
        box.append (new Gtk.Separator (Gtk.Orientation.HORIZONTAL));
        box.append (disp_caption);
        box.append (labeled_row ("Open at startup", startup_dd));
        box.append (labeled_row ("Album cover size", size_dd));
        box.append (labeled_row ("Gloss sheen on album covers", gloss_sw));
        box.append (labeled_row ("Rescan library on startup", rescan_sw));
        box.append (new Gtk.Separator (Gtk.Orientation.HORIZONTAL));
        box.append (cd_caption);
        box.append (labeled_row ("Rip format", fmt_dd));
        box.append (labeled_row ("CD device", dev_entry));
        box.append (new Gtk.Separator (Gtk.Orientation.HORIZONTAL));
        box.append (viz_caption);
        box.append (open_viz);

        var scroller = new Gtk.ScrolledWindow ();
        scroller.hscrollbar_policy = Gtk.PolicyType.NEVER;
        scroller.vexpand = true;
        scroller.set_child (box);
        return scroller;
    }

    // A label on the left and a control on the right, for a settings row.
    private Gtk.Widget labeled_row (string label, Gtk.Widget control) {
        var l = new Gtk.Label (label);
        l.add_css_class ("content-sub"); l.xalign = 0; l.hexpand = true;
        control.halign = Gtk.Align.END;
        control.valign = Gtk.Align.CENTER;
        var row = new Gtk.Box (Gtk.Orientation.HORIZONTAL, 10);
        row.append (l);
        row.append (control);
        return row;
    }

    private int index_of (string[] arr, string val) {
        for (int i = 0; i < arr.length; i++) if (arr[i] == val) return i;
        return 0;
    }

    private Gtk.Widget build_settings_theme () {
        var caption = new Gtk.Label ("Theme");
        caption.add_css_class ("side-title");
        caption.xalign = 0;

        var box = settings_page ();
        box.append (caption);

        string current = Application.settings.get_str ("theme", "dark");
        Gtk.Button[] btns = {};
        string[] keys = { "dark", "light", "cranberry", "leaf", "ocean", "peachy", "grimace" };
        string[] names = { "Dark Glass", "Light", "Cranberry Red", "Leaf Green", "Deep Blue", "Just Peachy", "Grimace" };
        string[] subs = {
            "The default translucent dark theme.",
            "A clean, heavy white theme.",
            "Bold, vivid cranberry red.",
            "A deep, dark green look.",
            "A deep, dark blue look.",
            "Salmon-pink frosted glass, with a little sparkle on every click.",
            "Dark purple with iridescent violet accents."
        };
        for (int i = 0; i < keys.length; i++) {
            var nm = new Gtk.Label (names[i]);
            nm.add_css_class ("album-name");
            nm.xalign = 0;
            var sub = new Gtk.Label (subs[i]);
            sub.add_css_class ("content-sub");
            sub.xalign = 0;
            sub.wrap = true;
            sub.max_width_chars = 40;
            var col = new Gtk.Box (Gtk.Orientation.VERTICAL, 0);
            col.append (nm);
            col.append (sub);
            var b = new Gtk.Button ();
            b.add_css_class ("pill");
            // A selection RING (not a filled background) marks the active theme.
            // The old code added ".accent", which flips the card to a light fill
            // while the card's title/subtitle keep their per-theme colour — in
            // Cranberry/dark themes that left white text on a white card. The ring
            // keeps the normal pill background, so the text stays readable.
            b.set_child (col);
            if (keys[i] == current) b.add_css_class ("theme-active");
            btns += b;
            box.append (b);
        }
        // Clicking a theme applies it live and marks it active.
        for (int i = 0; i < keys.length; i++) {
            string key = keys[i];
            var clicked = btns[i];
            clicked.clicked.connect (() => {
                Application.apply_theme (key);
                foreach (var bb in btns) bb.remove_css_class ("theme-active");
                clicked.add_css_class ("theme-active");
            });
        }
        return box;
    }

    private Gtk.Widget build_settings_discogs () {
        var caption = new Gtk.Label ("Discogs");
        caption.add_css_class ("side-title");
        caption.xalign = 0;

        var blurb = new Gtk.Label (
            "Use the Discogs music database to fetch artist photos (shown in the Artists " +
            "view as you play) and richer genre/style tags. It needs a free personal token " +
            "from discogs.com → Settings → Developers. Smart Shuffle (Controls menu) builds " +
            "a sensible random playlist from a song's genre.");
        blurb.add_css_class ("content-sub");
        blurb.xalign = 0;
        blurb.wrap = true;
        blurb.max_width_chars = 52;

        var enabled = new Gtk.Switch ();
        enabled.active = Application.settings.get_flag ("discogs_enabled", false);
        enabled.valign = Gtk.Align.CENTER;
        enabled.state_set.connect ((st) => {
            Application.settings.set_flag ("discogs_enabled", st);
            return false;
        });
        var enable_lbl = new Gtk.Label ("Enable Discogs");
        enable_lbl.xalign = 0;
        enable_lbl.hexpand = true;
        var enable_row = new Gtk.Box (Gtk.Orientation.HORIZONTAL, 10);
        enable_row.append (enable_lbl);
        enable_row.append (enabled);

        var token_caption = new Gtk.Label ("API token");
        token_caption.add_css_class ("content-sub");
        token_caption.xalign = 0;
        var token = new Gtk.PasswordEntry ();
        token.show_peek_icon = true;
        token.text = Application.settings.get_str ("discogs_token", "");
        token.changed.connect (() => Application.settings.set_str ("discogs_token", token.text));

        // Auto-apply artist photos.
        var auto_art = new Gtk.Switch ();
        auto_art.active = Application.settings.get_flag ("discogs_auto_art", true);
        auto_art.valign = Gtk.Align.CENTER;
        auto_art.state_set.connect ((st) => {
            Application.settings.set_flag ("discogs_auto_art", st);
            return false;
        });
        var auto_lbl = new Gtk.Label ("Auto-apply artist photos");
        auto_lbl.xalign = 0;
        auto_lbl.hexpand = true;
        var auto_row = new Gtk.Box (Gtk.Orientation.HORIZONTAL, 10);
        auto_row.append (auto_lbl);
        auto_row.append (auto_art);

        // Create a random playlist from a chosen genre.
        var pl_caption = new Gtk.Label ("Random playlist by genre");
        pl_caption.add_css_class ("side-title");
        pl_caption.xalign = 0;
        pl_caption.margin_top = 6;
        var genres = library_genres ();
        var picker = (genres.length > 0)
            ? new Gtk.DropDown.from_strings (genres)
            : new Gtk.DropDown.from_strings ({ "(scan your library first)" });
        picker.hexpand = true;
        var make_pl = new Gtk.Button.with_label ("Create");
        make_pl.add_css_class ("pill");
        make_pl.add_css_class ("accent");
        make_pl.sensitive = genres.length > 0;
        make_pl.clicked.connect (() => {
            uint sel = picker.selected;
            if (sel < genres.length) create_genre_playlist (genres[sel]);
        });
        var pl_row = new Gtk.Box (Gtk.Orientation.HORIZONTAL, 8);
        pl_row.append (picker);
        pl_row.append (make_pl);

        var cache_note = new Gtk.Label (
            "Artist photos and any playlists you create are saved on disk — they stay " +
            "applied even if you turn Discogs off or remove your token.");
        cache_note.add_css_class ("content-sub");
        cache_note.xalign = 0;
        cache_note.wrap = true;
        cache_note.max_width_chars = 52;
        cache_note.margin_top = 4;

        var box = settings_page ();
        box.append (caption);
        box.append (blurb);
        box.append (enable_row);
        box.append (token_caption);
        box.append (token);
        box.append (auto_row);
        box.append (pl_caption);
        box.append (pl_row);
        box.append (cache_note);
        return box;
    }

    private Gtk.Box settings_page () {
        var box = new Gtk.Box (Gtk.Orientation.VERTICAL, 10);
        box.margin_top = 16;
        box.margin_bottom = 10;
        box.margin_start = 20;
        box.margin_end = 20;
        return box;
    }

    // =====================================================================
    //  Sidebar
    // =====================================================================
    // A slim icon rail. Labels are intentionally dropped (shown as tooltips):
    // a Gtk.Box sizes to its widest child, so text labels were what kept the
    // sidebar wide no matter the width request. Icon-only collapses it for real.
    private Gtk.Widget build_sidebar () {
        var box = new Gtk.Box (Gtk.Orientation.VERTICAL, 2);
        box.add_css_class ("sidebar");
        box.add_css_class ("sidebar-slim");
        box.set_size_request (58, -1);
        box.hexpand = false;

        var rescan = new Gtk.Button.from_icon_name ("view-refresh-symbolic");
        rescan.add_css_class ("nav-row");
        rescan.tooltip_text = "Rescan library folder";
        rescan.clicked.connect (() => {
            if (music_folder != "") library.scan (music_folder);
            else choose_folder ();
        });
        box.append (rescan);

        box.append (nav_button ("audio-x-generic-symbolic", "Songs", "songs"));
        box.append (nav_button ("media-optical-symbolic", "Albums", "albums"));
        box.append (nav_button ("avatar-default-symbolic", "Artists", "artists"));
        box.append (nav_button ("emblem-music-symbolic", "Genres", "genres"));
        box.append (nav_button ("view-list-symbolic", "Composers", "composers"));

        var sep = new Gtk.Separator (Gtk.Orientation.HORIZONTAL);
        sep.add_css_class ("side-sep");
        sep.margin_top = 6;
        sep.margin_bottom = 6;
        box.append (sep);

        var add_pl = new Gtk.Button.from_icon_name ("list-add-symbolic");
        add_pl.add_css_class ("nav-row");
        add_pl.tooltip_text = "New playlist";
        add_pl.clicked.connect (() => {
            prompt_text ("New Playlist", "", (n) => create_playlist (n));
        });
        box.append (add_pl);

        playlist_box = new Gtk.Box (Gtk.Orientation.VERTICAL, 2);
        var scroller = new Gtk.ScrolledWindow ();
        scroller.vexpand = true;
        scroller.hscrollbar_policy = Gtk.PolicyType.NEVER;
        scroller.set_child (playlist_box);
        box.append (scroller);

        return box;
    }

    private Gtk.Button nav_button (string icon, string label, string target) {
        var img = new Gtk.Image.from_icon_name (icon);
        var b = new Gtk.Button ();
        b.add_css_class ("nav-row");
        b.set_child (img);
        b.tooltip_text = label;        // label lives in the tooltip on the slim rail
        b.clicked.connect (() => navigate (target));
        nav_buttons += b;
        nav_targets += target;
        return b;
    }

    private void set_active_nav (string target) {
        for (int i = 0; i < nav_buttons.length; i++) {
            if (nav_targets[i] == target) nav_buttons[i].add_css_class ("selected");
            else nav_buttons[i].remove_css_class ("selected");
        }
        var child = playlist_box.get_first_child ();
        while (child != null) {
            child.remove_css_class ("selected");
            child = child.get_next_sibling ();
        }
    }

    // =====================================================================
    //  Song list (ColumnView)
    // =====================================================================
    private void build_songs_widget () {
        filter = new Gtk.CustomFilter ((obj) => song_matches ((Track) obj));
        filter_model = new Gtk.FilterListModel (library.store, filter);
        sort_model = new Gtk.SortListModel (filter_model, null);
        selection = new Gtk.SingleSelection (sort_model);
        selection.autoselect = false;
        selection.can_unselect = true;

        column_view = new Gtk.ColumnView (selection);
        column_view.add_css_class ("song-list");
        column_view.hexpand = true;
        column_view.vexpand = true;

        add_text_column ("Name", "title", false, true);
        add_text_column ("Time", "duration", true, false);
        add_text_column ("Artist", "artist", false, false);
        add_text_column ("Album", "album", false, false);
        add_text_column ("Genre", "genre", false, false);
        add_text_column ("Year", "year", true, false);

        sort_model.set_sorter (column_view.get_sorter ());

        column_view.activate.connect ((pos) => play_from_model ((int) pos));

        var rc = new Gtk.GestureClick ();
        rc.button = Gdk.BUTTON_SECONDARY;
        rc.pressed.connect ((n, x, y) => {
            right_clicked_track = selection.get_selected_item () as Track;
            if (right_clicked_track != null) show_context_menu (x, y);
        });
        column_view.add_controller (rc);

        songs_back = new Gtk.Button.from_icon_name ("go-previous-symbolic");
        songs_back.add_css_class ("transport-button");
        songs_back.visible = false;
        songs_back.clicked.connect (on_songs_back);
        songs_title = new Gtk.Label ("Songs");
        songs_title.add_css_class ("content-title");
        songs_title.xalign = 0;
        songs_sub = new Gtk.Label ("");
        songs_sub.add_css_class ("content-sub");
        songs_sub.xalign = 0;
        var titles = new Gtk.Box (Gtk.Orientation.VERTICAL, 0);
        titles.append (songs_title);
        titles.append (songs_sub);
        var play_all = new Gtk.Button.with_label ("Play");
        play_all.add_css_class ("play-all");
        play_all.valign = Gtk.Align.CENTER;
        play_all.clicked.connect (() => {
            if (selection.get_n_items () > 0) play_from_model (0);
        });
        var header = new Gtk.Box (Gtk.Orientation.HORIZONTAL, 10);
        header.add_css_class ("content-header");
        header.append (songs_back);
        header.append (titles);
        var spacer = new Gtk.Box (Gtk.Orientation.HORIZONTAL, 0);
        spacer.hexpand = true;
        header.append (spacer);
        header.append (play_all);

        var scroller = new Gtk.ScrolledWindow ();
        scroller.vexpand = true;
        scroller.set_child (column_view);

        songs_widget = new Gtk.Box (Gtk.Orientation.VERTICAL, 0);
        songs_widget.append (header);
        songs_widget.append (scroller);
    }

    private void add_text_column (string title, string key, bool numeric, bool expand) {
        var factory = new Gtk.SignalListItemFactory ();
        factory.setup.connect ((obj) => {
            var li = (Gtk.ListItem) obj;
            var label = new Gtk.Label ("");
            label.xalign = 0;
            label.ellipsize = Pango.EllipsizeMode.END;
            // The title (song name) gets its own class so its colour is set
            // explicitly per theme instead of inheriting the dark-theme text.
            label.add_css_class (key == "title" ? "cell-title" : "cell-dim");
            li.set_child (label);
        });
        factory.bind.connect ((obj) => {
            var li = (Gtk.ListItem) obj;
            var t = (Track) li.item;
            var label = (Gtk.Label) li.child;
            label.label = cell_text (t, key);
        });

        var col = new Gtk.ColumnViewColumn (title, factory);
        col.expand = expand;
        if (numeric) {
            col.set_sorter (new Gtk.CustomSorter ((a, b) => num_cmp ((Track) a, (Track) b, key)));
        } else {
            col.set_sorter (new Gtk.CustomSorter ((a, b) => str_cmp ((Track) a, (Track) b, key)));
        }
        column_view.append_column (col);
    }

    private string cell_text (Track t, string key) {
        switch (key) {
            case "title":    return t.title;
            case "duration": return t.duration_str ();
            case "artist":   return t.artist;
            case "album":    return t.album;
            case "genre":    return t.genre;
            case "year":     return t.year > 0 ? t.year.to_string () : "";
            default:         return "";
        }
    }

    private int str_cmp (Track a, Track b, string key) {
        return cell_text (a, key).collate (cell_text (b, key));
    }

    private int num_cmp (Track a, Track b, string key) {
        int64 x = key == "duration" ? a.duration : a.year;
        int64 y = key == "duration" ? b.duration : b.year;
        return x < y ? -1 : (x > y ? 1 : 0);
    }

    private bool song_matches (Track t) {
        if (scope_type == "artist" && t.album_artist != scope_value && t.artist != scope_value) return false;
        if (scope_type == "genre" && t.genre != scope_value) return false;
        if (scope_type == "composer") {
            var cmp = t.composer == "" ? "Unknown Composer" : t.composer;
            if (cmp != scope_value) return false;
        }
        if (scope_type == "album" && (t.album != scope_value || t.album_artist != scope_artist)) return false;
        if (scope_type == "playlist" && !path_in_scope (t.path)) return false;
        if (search_text != "") {
            string q = search_text.down ();
            if (!(t.title.down ().contains (q) || t.artist.down ().contains (q) || t.album.down ().contains (q))) {
                return false;
            }
        }
        return true;
    }

    private bool path_in_scope (string p) {
        foreach (var x in scope_playlist_paths) if (x == p) return true;
        return false;
    }

    // =====================================================================
    //  View switching
    // =====================================================================
    private void show_widget (Gtk.Widget w) {
        if (current_child == w) return;
        if (current_child != null) content_area.remove (current_child);
        content_area.append (w);
        current_child = w;
    }

    private void navigate (string target) {
        view = target;
        scope_type = "";
        scope_value = "";
        scope_artist = "";
        set_active_nav (target);
        if (target == "songs") show_songs ();
        else if (target == "albums") show_albums ();
        else if (target == "artists") show_artists ();
        else if (target == "genres") show_genres ();
        else if (target == "composers") show_composers ();
    }

    private void on_songs_back () {
        var grp = view;
        scope_type = "";
        scope_value = "";
        scope_artist = "";
        if (grp == "albums") show_albums ();
        else if (grp == "artists") show_artists ();
        else if (grp == "genres") show_genres ();
        else if (grp == "composers") show_composers ();
        else navigate ("songs");
    }

    private void refresh_current_view () {
        if (current_child == songs_widget) show_songs ();
        else if (view == "albums") show_albums ();
        else if (view == "artists") show_artists ();
        else if (view == "genres") show_genres ();
        else if (view == "composers") show_composers ();
    }

    private void show_songs () {
        filter.changed (Gtk.FilterChange.DIFFERENT);

        string t_title = "Songs";
        string t_sub = "";
        bool back = false;
        if (scope_type == "artist" || scope_type == "genre" || scope_type == "composer") {
            t_title = scope_value; back = true;
        } else if (scope_type == "album") {
            t_title = scope_value; t_sub = scope_artist; back = true;
        } else if (scope_type == "playlist") {
            t_title = scope_value;
        }
        uint n = selection.get_n_items ();
        if (t_sub == "") t_sub = "%u song%s".printf (n, n == 1 ? "" : "s");

        songs_title.label = t_title;
        songs_sub.label = t_sub;
        songs_back.visible = back;

        show_widget (songs_widget);
    }

    private void show_welcome () {
        var note = new Gtk.Label ("♪");
        note.add_css_class ("welcome-note");
        var t = new Gtk.Label ("Welcome to Cranberry Juice");
        t.add_css_class ("welcome-title");
        var p = new Gtk.Label ("Point Cranberry Juice at a folder of music and it will build your library — artwork, albums, artists and all.");
        p.add_css_class ("welcome-body");
        p.wrap = true;
        p.max_width_chars = 44;
        p.justify = Gtk.Justification.CENTER;

        var use_default = new Gtk.Button.with_label ("Use ~/Music");
        use_default.add_css_class ("pill");
        use_default.add_css_class ("accent");
        use_default.clicked.connect (() => set_folder (Path.build_filename (Environment.get_home_dir (), "Music")));
        var choose = new Gtk.Button.with_label ("Choose Folder…");
        choose.add_css_class ("pill");
        choose.clicked.connect (choose_folder);
        var row = new Gtk.Box (Gtk.Orientation.HORIZONTAL, 10);
        row.halign = Gtk.Align.CENTER;
        row.append (use_default);
        row.append (choose);

        var box = new Gtk.Box (Gtk.Orientation.VERTICAL, 16);
        box.valign = Gtk.Align.CENTER;
        box.halign = Gtk.Align.CENTER;
        box.vexpand = true;
        box.append (note);
        box.append (t);
        box.append (p);
        box.append (row);
        show_widget (box);
    }

    // ----- Albums grid (virtualized) -----
    private void show_albums () {
        // Collect once, then reuse across tab switches (only recollect when the
        // library changed or the search term changed).
        if (albums_dirty || albums_cached_for != search_text) {
            albums_cache = collect_albums ();
            albums_cached_for = search_text;
            albums_dirty = false;
        }
        var albums = albums_cache;
        album_list = albums;

        var header = simple_header ("Albums", "%u album%s".printf (albums.length, albums.length == 1 ? "" : "s"));

        // A Gtk.GridView only builds the covers that are actually on screen, so
        // even a 1000+ album library scrolls smoothly (the old grid built every card).
        if (album_store == null) album_store = new GLib.ListStore (typeof (AlbumInfo));
        album_store.remove_all ();
        foreach (var a in albums) album_store.append (a);

        var factory = new Gtk.SignalListItemFactory ();
        factory.setup.connect (on_album_setup);
        factory.bind.connect (on_album_bind);

        var grid = new Gtk.GridView (new Gtk.NoSelection (album_store), factory);
        grid.add_css_class ("album-grid");
        grid.min_columns = 6;
        grid.max_columns = 6;
        grid.single_click_activate = true;
        grid.vexpand = true;
        grid.margin_start = 20;
        grid.margin_end = 20;
        grid.margin_top = 4;
        grid.margin_bottom = 20;
        grid.activate.connect ((pos) => show_album_detail ((int) pos));

        var scroller = new Gtk.ScrolledWindow ();
        scroller.vexpand = true;
        scroller.hscrollbar_policy = Gtk.PolicyType.NEVER;
        scroller.set_child (grid);

        var box = new Gtk.Box (Gtk.Orientation.VERTICAL, 0);
        box.append (header);
        box.append (scroller);
        show_widget (box);
    }

    // Build one reusable album card; the factory recycles it for many albums.
    private void on_album_setup (GLib.Object obj) {
        var li = (Gtk.ListItem) obj;

        var pic = new Gtk.Picture ();
        pic.content_fit = Gtk.ContentFit.COVER;   // fill the square — only the image, no frame
        pic.set_size_request (ALBUM_COVER_PX, ALBUM_COVER_PX);
        pic.halign = Gtk.Align.FILL;
        pic.valign = Gtk.Align.FILL;
        pic.add_css_class ("album-cover");

        // FINAL gloss fix: the cover is a fixed square that CLIPS its contents.
        // The album texture (and the vinyl fallback) are loaded at exactly this size
        // in on_album_bind, so the Picture's natural size equals the cover and never
        // grows past it. With overflow=HIDDEN and a fixed size, the gloss overlay
        // fills the identical square — it can no longer render as a smaller inset box.
        var cover = new Gtk.Overlay ();
        cover.set_size_request (ALBUM_COVER_PX, ALBUM_COVER_PX);
        cover.halign = Gtk.Align.CENTER;
        cover.valign = Gtk.Align.START;
        cover.hexpand = false;
        cover.vexpand = false;
        cover.overflow = Gtk.Overflow.HIDDEN;
        cover.set_child (pic);

        if (show_gloss) {
            var gloss = new Gtk.Box (Gtk.Orientation.VERTICAL, 0);
            gloss.add_css_class ("album-gloss");
            gloss.can_target = false;
            gloss.halign = Gtk.Align.FILL;
            gloss.valign = Gtk.Align.FILL;
            cover.add_overlay (gloss);
        }

        // Labels are width-pinned to the cover so they line up exactly under it.
        var name = new Gtk.Label ("");
        name.add_css_class ("album-name");
        name.ellipsize = Pango.EllipsizeMode.END;
        name.xalign = 0;
        name.halign = Gtk.Align.FILL;
        name.set_size_request (ALBUM_COVER_PX, -1);
        name.max_width_chars = 0;
        var artist = new Gtk.Label ("");
        artist.add_css_class ("album-artist");
        artist.ellipsize = Pango.EllipsizeMode.END;
        artist.xalign = 0;
        artist.halign = Gtk.Align.FILL;
        artist.set_size_request (ALBUM_COVER_PX, -1);
        artist.max_width_chars = 0;

        // The whole card is exactly the cover width and centred in its grid cell,
        // so the cover and both labels share the same left edge (lined up).
        var card = new Gtk.Box (Gtk.Orientation.VERTICAL, 6);
        card.add_css_class ("album-card");
        card.set_size_request (ALBUM_COVER_PX, -1);
        card.halign = Gtk.Align.CENTER;
        card.append (cover);    // child 0: cover overlay (Picture is its first child)
        card.append (name);     // child 1
        card.append (artist);   // child 2

        // Right-click an album → context menu (Play / Edit Album Info). li.item
        // always reflects the album currently bound to this recycled card.
        var rc = new Gtk.GestureClick ();
        rc.button = 3;   // secondary (right) button
        rc.pressed.connect ((n, x, y) => {
            right_clicked_album = li.item as AlbumInfo;
            if (right_clicked_album != null) show_album_menu (card, x, y);
        });
        card.add_controller (rc);
        li.set_child (card);
    }

    // Fill a recycled card with the album it now represents (decodes only the
    // covers actually on screen). Widgets are found by their fixed positions.
    private void on_album_bind (GLib.Object obj) {
        var li = (Gtk.ListItem) obj;
        var a = (AlbumInfo) li.item;
        var card = (Gtk.Box) li.child;
        var cover = (Gtk.Overlay) card.get_first_child ();
        var pic = (Gtk.Picture) cover.get_first_child ();
        var name = (Gtk.Label) cover.get_next_sibling ();
        var artist = (Gtk.Label) name.get_next_sibling ();
        name.label = a.album;
        artist.label = a.artist;
        var tex = library.get_texture (a.key, ALBUM_COVER_PX);
        pic.paintable = tex != null ? tex : grid_vinyl ();
    }

    private class AlbumInfo : GLib.Object {
        public string album;
        public string artist;
        public string key;
        public GenericArray<Track> tracks = new GenericArray<Track> ();
    }

    private AlbumInfo[] collect_albums () {
        var map = new GLib.HashTable<string, AlbumInfo> (str_hash, str_equal);
        AlbumInfo[] list = {};
        uint n = library.store.get_n_items ();
        for (uint i = 0; i < n; i++) {
            var t = (Track) library.store.get_item (i);
            if (search_text != "") {
                string q = search_text.down ();
                if (!(t.album.down ().contains (q) || t.album_artist.down ().contains (q))) continue;
            }
            var ai = map.lookup (t.album_key);
            if (ai == null) {
                ai = new AlbumInfo ();
                ai.album = t.album;
                ai.artist = t.album_artist;
                ai.key = t.album_key;
                map.insert (t.album_key, ai);
                list += ai;
            }
            ai.tracks.add (t);
        }
        // Show "Various Artists" when an album's tracks don't share one artist
        // (a collaboration album); otherwise show the common album artist.
        foreach (var ai in list) {
            string a0 = "";
            bool various = false;
            for (int j = 0; j < ai.tracks.length; j++) {
                var aa = ai.tracks[j].album_artist;
                if (j == 0) a0 = aa;
                else if (aa != a0) { various = true; break; }
            }
            ai.artist = various ? "Various Artists" : a0;
        }
        return list;
    }

    private int ALBUM_COVER_PX = 168;   // grid cover side (set from the "cover_size" setting)
    private Gdk.Texture? grid_vinyl_cache = null;

    // The vinyl fallback, pre-scaled to the cover size so it never enlarges a card.
    private Gdk.Texture grid_vinyl () {
        if (grid_vinyl_cache == null) {
            try {
                var pix = new Gdk.Pixbuf.from_resource_at_scale (
                    "/io/github/cranberry/juice/vinyl.png", ALBUM_COVER_PX, ALBUM_COVER_PX, true);
                grid_vinyl_cache = Gdk.Texture.for_pixbuf (pix);
            } catch (Error e) {
                grid_vinyl_cache = Gdk.Texture.from_resource ("/io/github/cranberry/juice/vinyl.png");
            }
        }
        return grid_vinyl_cache;
    }

    private int cover_px_for (string size) {
        return (size == "small") ? 140 : (size == "large") ? 208 : 168;
    }

    // ----- Album detail: cover + a vinyl record sliding out + tracklist -----
    private Gdk.Texture? load_vinyl () {
        if (vinyl_cache == null) {
            vinyl_cache = Gdk.Texture.from_resource ("/io/github/cranberry/juice/vinyl.png");
        }
        return vinyl_cache;
    }

    private void play_album (GenericArray<Track> list, int start) {
        queue = new GenericArray<Track> ();
        for (int i = 0; i < list.length; i++) queue.add (list[i]);
        start_queue_at (start);
    }

    private void show_album_detail (int index) {
        if (album_list.length == 0) return;
        album_index = ((index % album_list.length) + album_list.length) % album_list.length;
        var a = album_list[album_index];

        var back = new Gtk.Button.from_icon_name ("go-previous-symbolic");
        back.add_css_class ("transport-button");
        back.clicked.connect (() => { album_detail_widget = null; show_albums (); });
        var head_title = new Gtk.Label (a.album);
        head_title.add_css_class ("content-title");
        head_title.xalign = 0;
        var head = new Gtk.Box (Gtk.Orientation.HORIZONTAL, 10);
        head.add_css_class ("content-header");
        head.append (back);
        head.append (head_title);

        // cover + vinyl stage (Gtk.Fixed so we can animate the vinyl sliding out)
        var stage = new Gtk.Fixed ();
        stage.set_size_request ((int) (cover_px * 1.62), cover_px + 20);

        var vtex = load_vinyl ();
        var vinyl = (vtex != null) ? new Gtk.Picture.for_paintable (vtex) : new Gtk.Picture ();
        vinyl.content_fit = Gtk.ContentFit.CONTAIN;
        vinyl.set_size_request (cover_px, cover_px);
        stage.put (vinyl, cover_px * 0.12, 10);

        var cover = new Gtk.Box (Gtk.Orientation.VERTICAL, 0);
        cover.add_css_class ("album-cover");
        cover.set_size_request (cover_px, cover_px);
        var ctex = library.get_texture (a.key, 600);
        if (ctex != null) {
            var cp = new Gtk.Picture.for_paintable (ctex);
            cp.content_fit = Gtk.ContentFit.COVER;
            cp.set_size_request (cover_px, cover_px);
            cover.append (cp);
        }
        stage.put (cover, 0, 10);

        var info_title = new Gtk.Label (a.album);
        info_title.add_css_class ("content-title");
        info_title.xalign = 0;
        info_title.wrap = true;
        info_title.max_width_chars = 26;
        var info_artist = new Gtk.Label (a.artist);
        info_artist.add_css_class ("content-sub");
        info_artist.xalign = 0;
        int secs = 0;
        for (int i = 0; i < a.tracks.length; i++) secs += (int) a.tracks[i].duration;
        var info_meta = new Gtk.Label ("%u songs · %d min".printf (a.tracks.length, secs / 60));
        info_meta.add_css_class ("content-sub");
        info_meta.xalign = 0;
        var play_all = new Gtk.Button.with_label ("Play Album");
        play_all.add_css_class ("play-all");
        play_all.halign = Gtk.Align.START;
        play_all.clicked.connect (() => play_album (a.tracks, 0));
        var info = new Gtk.Box (Gtk.Orientation.VERTICAL, 8);
        info.valign = Gtk.Align.CENTER;
        info.append (info_title);
        info.append (info_artist);
        info.append (info_meta);
        info.append (play_all);

        var top = new Gtk.Box (Gtk.Orientation.HORIZONTAL, 26);
        top.append (stage);
        top.append (info);

        var list = new Gtk.Box (Gtk.Orientation.VERTICAL, 2);
        for (int i = 0; i < a.tracks.length; i++) {
            var tk = a.tracks[i];
            int idx = i;
            var num = new Gtk.Label (tk.track_no > 0 ? tk.track_no.to_string () : (i + 1).to_string ());
            num.add_css_class ("cell-dim");
            num.set_size_request (28, -1);
            num.xalign = 1;
            var nm = new Gtk.Label (tk.title);
            nm.add_css_class ("cell-title");   // explicit per-theme colour (was inheriting)
            nm.xalign = 0;
            nm.hexpand = true;
            nm.ellipsize = Pango.EllipsizeMode.END;
            var dur = new Gtk.Label (tk.duration_str ());
            dur.add_css_class ("cell-dim");
            var row_inner = new Gtk.Box (Gtk.Orientation.HORIZONTAL, 12);
            row_inner.add_css_class ("list-tile");
            row_inner.append (num);
            row_inner.append (nm);
            row_inner.append (dur);
            var row = new Gtk.Button ();
            row.add_css_class ("album-card");
            row.set_child (row_inner);
            row.clicked.connect (() => play_album (a.tracks, idx));
            list.append (row);
        }

        var content = new Gtk.Box (Gtk.Orientation.VERTICAL, 18);
        content.margin_start = 22;
        content.margin_end = 16;
        content.margin_top = 10;
        content.append (top);
        content.append (list);

        var scroller = new Gtk.ScrolledWindow ();
        scroller.vexpand = true;
        scroller.set_child (content);

        var page = new Gtk.Box (Gtk.Orientation.VERTICAL, 0);
        page.append (head);
        page.append (scroller);

        album_detail_widget = page;
        show_widget (page);

        // animate the vinyl sliding out from behind the cover
        int64 start = 0;
        stage.add_tick_callback ((w, fc) => {
            int64 now = fc.get_frame_time ();
            if (start == 0) start = now;
            double t = (now - start) / 1000000.0 / 0.45;
            if (t > 1) t = 1;
            double e = 1 - Math.pow (1 - t, 3);
            double sx = cover_px * 0.12, ex = cover_px * 0.60;
            stage.move (vinyl, sx + (ex - sx) * e, 10);
            return t < 1;
        });
    }

    private bool on_window_key (uint keyval, uint keycode, Gdk.ModifierType state) {
        // Ctrl+Shift+M toggles the Mini Player — a deliberate chord, so handle it
        // first (works even with a text field focused; the menu item also shows it).
        if ((state & Gdk.ModifierType.CONTROL_MASK) != 0 &&
            (state & Gdk.ModifierType.SHIFT_MASK) != 0 &&
            (keyval == Gdk.Key.m || keyval == Gdk.Key.M)) {
            if (mini_mode) exit_mini (); else enter_mini ();
            return true;
        }

        // Never steal keys while typing in a search box, playlist name, metadata field, etc.
        if (get_focus () is Gtk.Editable) return false;

        // Spacebar = play / pause, everywhere. Consume it (capture phase) so it
        // never reaches a focused scrubber/list that would otherwise seek.
        if (keyval == Gdk.Key.space) { player.toggle (); return true; }

        // ← / → slide between albums, but only on the album detail page.
        if (album_detail_widget != null && current_child == album_detail_widget) {
            if (keyval == Gdk.Key.Left)  { show_album_detail (album_index - 1); return true; }
            if (keyval == Gdk.Key.Right) { show_album_detail (album_index + 1); return true; }
        }
        return false;
    }

    // ----- Artists / Genres -----
    private void show_artists () {
        var map = new GLib.HashTable<string, int> (str_hash, str_equal);
        string[] groups = {};
        uint n = library.store.get_n_items ();
        for (uint i = 0; i < n; i++) {
            var t = (Track) library.store.get_item (i);
            var name = t.album_artist;
            if (search_text != "" && !name.down ().contains (search_text.down ())) continue;
            if (!map.contains (name)) { map.insert (name, 0); groups += name; }
            map.replace (name, map.lookup (name) + 1);
        }

        var list = new Gtk.Box (Gtk.Orientation.VERTICAL, 2);
        list.margin_start = 10;
        list.margin_end = 10;
        foreach (var name in groups) {
            int c = map.lookup (name);
            string nm = name;
            list.append (make_list_row (name.substring (0, 1).up (), name,
                "%d song%s".printf (c, c == 1 ? "" : "s"),
                () => { scope_type = "artist"; scope_value = nm; show_songs (); }));
        }
        wrap_list ("Artists", "%u artist%s".printf (groups.length, groups.length == 1 ? "" : "s"), list);
    }

    private void show_genres () {
        var map = new GLib.HashTable<string, int> (str_hash, str_equal);
        string[] groups = {};
        uint n = library.store.get_n_items ();
        for (uint i = 0; i < n; i++) {
            var t = (Track) library.store.get_item (i);
            var g = t.genre == "" ? "Unknown Genre" : t.genre;
            if (search_text != "" && !g.down ().contains (search_text.down ())) continue;
            if (!map.contains (g)) { map.insert (g, 0); groups += g; }
            map.replace (g, map.lookup (g) + 1);
        }

        var list = new Gtk.Box (Gtk.Orientation.VERTICAL, 2);
        list.margin_start = 10;
        list.margin_end = 10;
        foreach (var g in groups) {
            int c = map.lookup (g);
            string gn = g;
            list.append (make_list_row ("♫", g,
                "%d song%s".printf (c, c == 1 ? "" : "s"),
                () => { scope_type = "genre"; scope_value = gn; show_songs (); }));
        }
        wrap_list ("Genres", "%u genre%s".printf (groups.length, groups.length == 1 ? "" : "s"), list);
    }

    private void show_composers () {
        var map = new GLib.HashTable<string, int> (str_hash, str_equal);
        string[] groups = {};
        uint n = library.store.get_n_items ();
        for (uint i = 0; i < n; i++) {
            var t = (Track) library.store.get_item (i);
            var cmp = t.composer == "" ? "Unknown Composer" : t.composer;
            if (search_text != "" && !cmp.down ().contains (search_text.down ())) continue;
            if (!map.contains (cmp)) { map.insert (cmp, 0); groups += cmp; }
            map.replace (cmp, map.lookup (cmp) + 1);
        }

        var list = new Gtk.Box (Gtk.Orientation.VERTICAL, 2);
        list.margin_start = 10;
        list.margin_end = 10;
        foreach (var cmp in groups) {
            int c = map.lookup (cmp);
            string cn = cmp;
            list.append (make_list_row (cmp.substring (0, 1).up (), cmp,
                "%d song%s".printf (c, c == 1 ? "" : "s"),
                () => { scope_type = "composer"; scope_value = cn; show_songs (); }));
        }
        wrap_list ("Composers", "%u composer%s".printf (groups.length, groups.length == 1 ? "" : "s"), list);
    }

    private Gtk.Button make_list_row (string initial, string name, string meta, owned Action cb) {
        // Show a Discogs artist photo if we have one cached; otherwise the letter avatar.
        Gtk.Widget avatar;
        var atex = library.get_artist_texture (name, 88);
        if (atex != null) {
            var pic = new Gtk.Picture ();
            pic.content_fit = Gtk.ContentFit.COVER;
            pic.set_size_request (44, 44);
            pic.paintable = atex;
            pic.add_css_class ("list-avatar");
            avatar = pic;
        } else {
            var lbl = new Gtk.Label (initial);
            lbl.add_css_class ("list-avatar");
            avatar = lbl;
        }
        var name_lbl = new Gtk.Label (name);
        name_lbl.add_css_class ("album-name");
        name_lbl.xalign = 0;
        name_lbl.hexpand = true;
        var meta_lbl = new Gtk.Label (meta);
        meta_lbl.add_css_class ("album-artist");
        meta_lbl.xalign = 0;
        var text = new Gtk.Box (Gtk.Orientation.VERTICAL, 0);
        text.hexpand = true;
        text.append (name_lbl);
        text.append (meta_lbl);
        var inner = new Gtk.Box (Gtk.Orientation.HORIZONTAL, 12);
        inner.add_css_class ("list-tile");
        inner.append (avatar);
        inner.append (text);
        var b = new Gtk.Button ();
        b.add_css_class ("album-card");
        b.set_child (inner);
        b.clicked.connect (() => cb ());
        return b;
    }

    private void wrap_list (string title, string sub, Gtk.Widget list) {
        var header = simple_header (title, sub);
        var scroller = new Gtk.ScrolledWindow ();
        scroller.vexpand = true;
        scroller.set_child (list);
        var box = new Gtk.Box (Gtk.Orientation.VERTICAL, 0);
        box.append (header);
        box.append (scroller);
        show_widget (box);
    }

    private Gtk.Widget simple_header (string title, string sub) {
        var t = new Gtk.Label (title);
        t.add_css_class ("content-title");
        t.xalign = 0;
        var s = new Gtk.Label (sub);
        s.add_css_class ("content-sub");
        s.xalign = 0;
        var box = new Gtk.Box (Gtk.Orientation.VERTICAL, 0);
        box.add_css_class ("content-header");
        box.append (t);
        box.append (s);
        return box;
    }

    // =====================================================================
    //  Playlists
    // =====================================================================
    private void rebuild_playlists () {
        var child = playlist_box.get_first_child ();
        while (child != null) {
            var nxt = child.get_next_sibling ();
            playlist_box.remove (child);
            child = nxt;
        }
        foreach (var name in Application.settings.list_playlists ()) {
            playlist_box.append (make_playlist_button (name));
        }
    }

    private Gtk.Button make_playlist_button (string name) {
        var icon = new Gtk.Image.from_icon_name ("emblem-music-symbolic");
        int count = Application.settings.get_playlist (name).length;
        var b = new Gtk.Button ();
        b.add_css_class ("nav-row");
        b.set_child (icon);
        b.tooltip_text = "%s · %d %s".printf (name, count, count == 1 ? "song" : "songs");
        b.clicked.connect (() => open_playlist (name, b));

        var rc = new Gtk.GestureClick ();
        rc.button = Gdk.BUTTON_SECONDARY;
        rc.pressed.connect ((n, x, y) => show_playlist_menu (b, name, x, y));
        b.add_controller (rc);
        return b;
    }

    private void open_playlist (string name, Gtk.Button b) {
        view = "playlist";
        scope_type = "playlist";
        scope_value = name;
        scope_playlist_paths = Application.settings.get_playlist (name);
        foreach (var nb in nav_buttons) nb.remove_css_class ("selected");
        var child = playlist_box.get_first_child ();
        while (child != null) { child.remove_css_class ("selected"); child = child.get_next_sibling (); }
        b.add_css_class ("selected");
        show_songs ();
    }

    private void create_playlist (string name) {
        if (name == "") return;
        Application.settings.set_playlist (name, new string[0]);
        rebuild_playlists ();
    }

    private void add_to_playlist (string name, Track t) {
        var paths = Application.settings.get_playlist (name);
        foreach (var p in paths) if (p == t.path) return;
        paths += t.path;
        Application.settings.set_playlist (name, paths);
        rebuild_playlists ();
        if (scope_type == "playlist" && scope_value == name) {
            scope_playlist_paths = paths;
            show_songs ();
        }
    }

    private void show_playlist_menu (Gtk.Button anchor, string name, double x, double y) {
        var play = new Gtk.Button.with_label ("Play");
        play.add_css_class ("flat");
        var rename = new Gtk.Button.with_label ("Rename…");
        rename.add_css_class ("flat");
        var del = new Gtk.Button.with_label ("Delete");
        del.add_css_class ("flat");

        var box = new Gtk.Box (Gtk.Orientation.VERTICAL, 2);
        box.append (play);
        box.append (rename);
        box.append (del);
        var pop = new Gtk.Popover ();
        pop.set_child (box);
        pop.set_parent (anchor);
        pop.set_pointing_to ({ (int) x, (int) y, 1, 1 });

        play.clicked.connect (() => {
            pop.popdown ();
            play_paths (Application.settings.get_playlist (name));
        });
        rename.clicked.connect (() => {
            pop.popdown ();
            prompt_text ("Rename Playlist", name, (newname) => {
                var paths = Application.settings.get_playlist (name);
                Application.settings.remove_playlist (name);
                Application.settings.set_playlist (newname, paths);
                rebuild_playlists ();
            });
        });
        del.clicked.connect (() => {
            pop.popdown ();
            Application.settings.remove_playlist (name);
            if (scope_type == "playlist" && scope_value == name) navigate ("songs");
            rebuild_playlists ();
        });
        pop.popup ();
    }

    // =====================================================================
    //  Context menu (song right-click)
    // =====================================================================
    private void register_context_actions () {
        var play = new SimpleAction ("ctxplay", null);
        play.activate.connect (() => { if (right_clicked_track != null) play_paths_single (right_clicked_track); });
        add_action (play);

        var playnext = new SimpleAction ("ctxplaynext", null);
        playnext.activate.connect (() => { if (right_clicked_track != null) play_next (right_clicked_track); });
        add_action (playnext);

        var queue_a = new SimpleAction ("ctxqueue", null);
        queue_a.activate.connect (() => {
            if (right_clicked_track != null) {
                if (queue.length == 0) play_paths_single (right_clicked_track);
                else queue.add (right_clicked_track);
            }
        });
        add_action (queue_a);

        var props = new SimpleAction ("ctxprops", null);
        props.activate.connect (() => { if (right_clicked_track != null) edit_properties (right_clicked_track); });
        add_action (props);

        var reveal = new SimpleAction ("ctxreveal", null);
        reveal.activate.connect (() => {
            if (right_clicked_track != null) {
                var f = File.new_for_path (right_clicked_track.path);
                var launcher = new Gtk.FileLauncher (f);
                launcher.open_containing_folder.begin (this, null);
            }
        });
        add_action (reveal);

        var addpl = new SimpleAction ("ctxaddpl", VariantType.STRING);
        addpl.activate.connect ((param) => {
            if (right_clicked_track != null && param != null) {
                add_to_playlist (param.get_string (), right_clicked_track);
            }
        });
        add_action (addpl);

        var newpl = new SimpleAction ("ctxnewpl", null);
        newpl.activate.connect (() => {
            var t = right_clicked_track;
            prompt_text ("New Playlist", "", (name) => {
                create_playlist (name);
                if (t != null) add_to_playlist (name, t);
            });
        });
        add_action (newpl);

        var info = new SimpleAction ("ctxinfo", null);
        info.activate.connect (() => {
            if (right_clicked_track != null) show_track_details (right_clicked_track);
        });
        add_action (info);

        var editalbum = new SimpleAction ("ctxeditalbum", null);
        editalbum.activate.connect (() => {
            if (right_clicked_album != null) edit_album (right_clicked_album);
        });
        add_action (editalbum);

        var playalbum = new SimpleAction ("ctxplayalbum", null);
        playalbum.activate.connect (() => {
            if (right_clicked_album != null) play_album (right_clicked_album.tracks, 0);
        });
        add_action (playalbum);
    }

    private void show_context_menu (double x, double y) {
        var menu = new GLib.Menu ();
        menu.append ("Play", "win.ctxplay");
        menu.append ("Play Next", "win.ctxplaynext");
        menu.append ("Add to Queue", "win.ctxqueue");

        var plmenu = new GLib.Menu ();
        plmenu.append ("New Playlist…", "win.ctxnewpl");
        foreach (var name in Application.settings.list_playlists ()) {
            plmenu.append (name, "win.ctxaddpl::" + name);
        }
        menu.append_submenu ("Add to Playlist", plmenu);
        menu.append ("Properties…", "win.ctxprops");
        menu.append ("Track Details", "win.ctxinfo");
        menu.append ("Show in Files", "win.ctxreveal");

        var pop = new Gtk.PopoverMenu.from_model (menu);
        pop.set_parent (column_view);
        pop.set_pointing_to ({ (int) x, (int) y, 1, 1 });
        pop.popup ();
    }

    private void show_track_details (Track t) {
        var dialog = new Gtk.Window ();
        dialog.title = "Track Details";
        dialog.transient_for = this;
        dialog.modal = true;
        dialog.default_width = 440;
        dialog.add_css_class ("cranberry");

        var grid = new Gtk.Grid ();
        grid.row_spacing = 8;
        grid.column_spacing = 14;
        grid.margin_top = 20;
        grid.margin_start = 20;
        grid.margin_end = 20;

        int row = 0;
        add_detail (grid, ref row, "Title", t.title);
        add_detail (grid, ref row, "Artist", t.artist);
        add_detail (grid, ref row, "Album", t.album);
        add_detail (grid, ref row, "Composer", t.composer);
        add_detail (grid, ref row, "Genre", t.genre);
        add_detail (grid, ref row, "Year", t.year > 0 ? t.year.to_string () : "");
        add_detail (grid, ref row, "Track", t.track_no > 0 ? t.track_no.to_string () : "");
        add_detail (grid, ref row, "Duration", t.duration_str ());
        add_detail (grid, ref row, "Format", format_of (t.path));
        add_detail (grid, ref row, "File", t.path);

        var close = new Gtk.Button.with_label ("Done");
        close.add_css_class ("pill");
        close.add_css_class ("accent");
        close.halign = Gtk.Align.END;
        close.clicked.connect (() => dialog.destroy ());

        var box = new Gtk.Box (Gtk.Orientation.VERTICAL, 14);
        box.margin_bottom = 18;
        box.margin_end = 20;
        box.append (grid);
        box.append (close);
        dialog.set_child (box);
        dialog.present ();
    }

    private void add_detail (Gtk.Grid grid, ref int row, string label, string value) {
        var k = new Gtk.Label (label);
        k.add_css_class ("content-sub");
        k.xalign = 1;
        k.valign = Gtk.Align.START;
        var v = new Gtk.Label (value == "" ? "—" : value);
        v.xalign = 0;
        v.wrap = true;
        v.max_width_chars = 40;
        v.selectable = true;
        grid.attach (k, 0, row, 1, 1);
        grid.attach (v, 1, row, 1, 1);
        row++;
    }

    private string format_of (string path) {
        int dot = path.last_index_of_char ('.');
        return dot >= 0 ? path.substring (dot + 1).up () : "";
    }

    // Editable metadata. Updates the song in the library and persists it; the
    // original audio file's embedded tags are left untouched (see the note).
    private void edit_properties (Track t) {
        var dialog = new Gtk.Window ();
        dialog.title = "Properties";
        dialog.transient_for = this;
        dialog.modal = true;
        dialog.default_width = 460;
        dialog.add_css_class ("cranberry");

        var grid = new Gtk.Grid ();
        grid.row_spacing = 8;
        grid.column_spacing = 14;
        grid.margin_top = 20;
        grid.margin_start = 20;
        grid.margin_end = 20;

        int row = 0;
        var e_title  = prop_field (grid, ref row, "Title", t.title);
        var e_artist = prop_field (grid, ref row, "Artist", t.artist);
        var e_albart = prop_field (grid, ref row, "Album Artist", t.album_artist);
        var e_album  = prop_field (grid, ref row, "Album", t.album);
        var e_comp   = prop_field (grid, ref row, "Composer", t.composer);
        var e_genre  = prop_field (grid, ref row, "Genre", t.genre);
        var e_year   = prop_field (grid, ref row, "Year", t.year > 0 ? t.year.to_string () : "");
        var e_track  = prop_field (grid, ref row, "Track", t.track_no > 0 ? t.track_no.to_string () : "");

        // Clickable cover preview — shows this song's current art (or the Cranberry
        // icon if none); click it to pick an image just for this song.
        var art_img = new Gtk.Picture ();
        art_img.content_fit = Gtk.ContentFit.COVER;
        art_img.set_size_request (120, 120);
        art_img.margin_top = 20;
        art_img.add_css_class ("album-cover");
        set_track_preview (art_img, t);
        var art_click = new Gtk.GestureClick ();
        art_click.pressed.connect ((n, x, y) => {
            pick_image ((bytes) => {
                library.set_art ("track:" + t.path, bytes);
                set_track_preview (art_img, t);
                if (q_index >= 0 && q_index < queue.length && queue[q_index] == t) update_now_playing (t);
                refresh_current_view ();
            });
        });
        art_img.add_controller (art_click);
        var art_hint = new Gtk.Label ("Click to set this song's art.");
        art_hint.add_css_class ("content-sub");
        art_hint.wrap = true; art_hint.max_width_chars = 16; art_hint.xalign = 0;
        var art_col = new Gtk.Box (Gtk.Orientation.VERTICAL, 6);
        art_col.append (art_img);
        art_col.append (art_hint);
        var top = new Gtk.Box (Gtk.Orientation.HORIZONTAL, 16);
        top.append (art_col);
        top.append (grid);

        var note = new Gtk.Label ("Saved to your library and kept across restarts. The original file's embedded tags aren't modified.");
        note.add_css_class ("content-sub");
        note.xalign = 0;
        note.wrap = true;
        note.max_width_chars = 44;

        var cancel = new Gtk.Button.with_label ("Cancel");
        cancel.add_css_class ("pill");
        cancel.clicked.connect (() => dialog.destroy ());
        var save = new Gtk.Button.with_label ("Save");
        save.add_css_class ("pill");
        save.add_css_class ("accent");
        save.clicked.connect (() => {
            t.title = e_title.text.strip ();
            t.artist = e_artist.text.strip ();
            t.album_artist = e_albart.text.strip ();
            t.album = e_album.text.strip ();
            t.composer = e_comp.text.strip ();
            t.genre = e_genre.text.strip ();
            t.year = int.parse (e_year.text.strip ());
            t.track_no = int.parse (e_track.text.strip ());
            library.save_now ();
            albums_dirty = true;   // album/artist may have changed — rebuild album grid
            refresh_current_view ();
            if (q_index >= 0 && q_index < queue.length && queue[q_index] == t) update_now_playing (t);
            dialog.destroy ();
        });
        var btns = new Gtk.Box (Gtk.Orientation.HORIZONTAL, 8);
        btns.halign = Gtk.Align.END;
        btns.append (cancel);
        btns.append (save);

        var box = new Gtk.Box (Gtk.Orientation.VERTICAL, 14);
        box.margin_bottom = 18;
        box.margin_start = 20;
        box.margin_end = 20;
        box.append (top);
        box.append (note);
        box.append (btns);
        dialog.set_child (box);
        dialog.present ();
    }

    private Gtk.Entry prop_field (Gtk.Grid grid, ref int row, string label, string val) {
        var k = new Gtk.Label (label);
        k.add_css_class ("content-sub");
        k.xalign = 1;
        var e = new Gtk.Entry ();
        e.text = val;
        e.hexpand = true;
        grid.attach (k, 0, row, 1, 1);
        grid.attach (e, 1, row, 1, 1);
        row++;
        return e;
    }

    // =====================================================================
    //  Album right-click: edit album-wide metadata + cover art
    // =====================================================================

    private void show_album_menu (Gtk.Widget anchor, double x, double y) {
        var menu = new GLib.Menu ();
        menu.append ("Play Album", "win.ctxplayalbum");
        menu.append ("Edit Album Info…", "win.ctxeditalbum");
        var pop = new Gtk.PopoverMenu.from_model (menu);
        pop.set_parent (anchor);
        pop.set_pointing_to ({ (int) x, (int) y, 1, 1 });
        pop.popup ();
    }

    // Album editor: every field applies to ALL tracks in the album, and the cover
    // preview (click to choose an image) sets album-wide art. The internal
    // album_key is left unchanged so grouping + existing art stay associated.
    private void edit_album (AlbumInfo a) {
        var dialog = new Gtk.Window ();
        dialog.title = "Edit Album Info";
        dialog.transient_for = this;
        dialog.modal = true;
        dialog.default_width = 500;
        dialog.add_css_class ("cranberry");

        Track? rep = a.tracks.length > 0 ? a.tracks[0] : null;
        string g0 = rep != null ? rep.genre : "";
        string y0 = (rep != null && rep.year > 0) ? rep.year.to_string () : "";

        // Clickable cover preview (current album art, or the Cranberry icon).
        var art_img = new Gtk.Picture ();
        art_img.content_fit = Gtk.ContentFit.COVER;
        art_img.set_size_request (132, 132);
        art_img.add_css_class ("album-cover");
        set_album_preview (art_img, a);
        var art_click = new Gtk.GestureClick ();
        art_click.pressed.connect ((n, x, y) => {
            pick_image ((bytes) => {
                library.set_art (a.key, bytes);   // album_key → applies to all songs
                set_album_preview (art_img, a);
                albums_dirty = true;
                refresh_current_view ();
            });
        });
        art_img.add_controller (art_click);
        var art_hint = new Gtk.Label ("Click the cover to choose album art.");
        art_hint.add_css_class ("content-sub");
        art_hint.wrap = true; art_hint.max_width_chars = 22; art_hint.xalign = 0;
        var art_col = new Gtk.Box (Gtk.Orientation.VERTICAL, 6);
        art_col.append (art_img);
        art_col.append (art_hint);

        var grid = new Gtk.Grid ();
        grid.row_spacing = 8;
        grid.column_spacing = 14;
        grid.hexpand = true;
        int row = 0;
        var e_album  = prop_field (grid, ref row, "Album", a.album);
        var e_artist = prop_field (grid, ref row, "Album Artist", a.artist);
        var e_genre  = prop_field (grid, ref row, "Genre", g0);
        var e_year   = prop_field (grid, ref row, "Year", y0);

        var top = new Gtk.Box (Gtk.Orientation.HORIZONTAL, 16);
        top.append (art_col);
        top.append (grid);

        var note = new Gtk.Label (
            "Changes apply to all %u song%s in this album. Saved to your library; the original files aren't modified."
            .printf (a.tracks.length, a.tracks.length == 1 ? "" : "s"));
        note.add_css_class ("content-sub");
        note.xalign = 0; note.wrap = true; note.max_width_chars = 54;

        var cancel = new Gtk.Button.with_label ("Cancel");
        cancel.add_css_class ("pill");
        cancel.clicked.connect (() => dialog.destroy ());
        var save = new Gtk.Button.with_label ("Save");
        save.add_css_class ("pill");
        save.add_css_class ("accent");
        save.clicked.connect (() => {
            string nalbum  = e_album.text.strip ();
            string nartist = e_artist.text.strip ();
            string ngenre  = e_genre.text.strip ();
            string nyear   = e_year.text.strip ();
            for (int i = 0; i < a.tracks.length; i++) {
                var t = a.tracks[i];
                if (nalbum != "")  t.album = nalbum;
                if (nartist != "") t.album_artist = nartist;
                if (ngenre != "")  t.genre = ngenre;
                if (nyear != "")   t.year = int.parse (nyear);
            }
            library.save_now ();
            albums_dirty = true;
            refresh_current_view ();
            dialog.destroy ();
        });
        var btns = new Gtk.Box (Gtk.Orientation.HORIZONTAL, 8);
        btns.halign = Gtk.Align.END;
        btns.append (cancel);
        btns.append (save);

        var box = new Gtk.Box (Gtk.Orientation.VERTICAL, 14);
        box.margin_top = 20; box.margin_bottom = 18;
        box.margin_start = 20; box.margin_end = 20;
        box.append (top);
        box.append (note);
        box.append (btns);
        dialog.set_child (box);
        dialog.present ();
    }

    private void set_album_preview (Gtk.Picture pic, AlbumInfo a) {
        var tex = library.get_texture (a.key, 264);
        pic.paintable = tex != null ? tex
            : Gdk.Texture.from_resource ("/io/github/cranberry/juice/appicon.png");
    }

    private void set_track_preview (Gtk.Picture pic, Track t) {
        var tex = library.get_texture_for_track (t, 264);
        pic.paintable = tex != null ? tex
            : Gdk.Texture.from_resource ("/io/github/cranberry/juice/appicon.png");
    }

    // Open a native image picker; on success, hand the chosen file's bytes to cb.
    private void pick_image (owned ImagePickedCb cb) {
        var dialog = new Gtk.FileDialog ();
        dialog.title = "Choose an image";
        var filter = new Gtk.FileFilter ();
        filter.name = "Images";
        filter.add_mime_type ("image/png");
        filter.add_mime_type ("image/jpeg");
        filter.add_mime_type ("image/webp");
        filter.add_mime_type ("image/gif");
        filter.add_mime_type ("image/bmp");
        var filters = new GLib.ListStore (typeof (Gtk.FileFilter));
        filters.append (filter);
        dialog.filters = filters;
        dialog.default_filter = filter;
        dialog.open.begin (this, null, (obj, res) => {
            try {
                var file = dialog.open.end (res);
                if (file == null) return;
                uint8[] data;
                string etag;
                file.load_contents (null, out data, out etag);
                cb (new Bytes (data));
            } catch (Error e) {
                // cancelled or unreadable — ignore
            }
        });
    }

    // =====================================================================
    //  Tools: Fix Album Grouping (keep collaboration albums together)
    // =====================================================================
    private void show_fix_albums () {
        var dialog = new Gtk.Window ();
        dialog.title = "Fix Album Grouping";
        dialog.transient_for = this;
        dialog.modal = true;
        dialog.default_width = 480;
        dialog.add_css_class ("cranberry");   // follows the active theme

        var box = new Gtk.Box (Gtk.Orientation.VERTICAL, 12);
        box.margin_top = 20; box.margin_bottom = 18; box.margin_start = 20; box.margin_end = 20;

        var heading = new Gtk.Label ("Fix Album Grouping");
        heading.add_css_class ("welcome-title");
        heading.xalign = 0;

        var body = new Gtk.Label (
            "Cranberry Juice keeps every song from the same album together — even " +
            "collaboration albums where each track has a different artist — by grouping " +
            "them by their album folder. Those albums show as \"Various Artists\".\n\n" +
            "Your library is already grouped this way. If an album still looks split, or a " +
            "cover looks wrong, rescan to rebuild the grouping and refresh the artwork.");
        body.add_css_class ("content-sub");
        body.xalign = 0; body.wrap = true; body.max_width_chars = 54;

        var rescan = new Gtk.Button.with_label ("Rescan Library Now");
        rescan.add_css_class ("pill"); rescan.add_css_class ("accent");
        rescan.sensitive = music_folder != "";
        rescan.clicked.connect (() => {
            if (music_folder != "") library.scan (music_folder);
            dialog.destroy ();
        });
        var close = new Gtk.Button.with_label ("Close");
        close.add_css_class ("pill");
        close.clicked.connect (() => dialog.destroy ());

        var spacer = new Gtk.Box (Gtk.Orientation.HORIZONTAL, 0);
        spacer.hexpand = true;
        var btns = new Gtk.Box (Gtk.Orientation.HORIZONTAL, 8);
        btns.append (rescan);
        btns.append (spacer);
        btns.append (close);

        box.append (heading);
        box.append (body);
        box.append (btns);
        dialog.set_child (box);
        dialog.present ();
    }

    // =====================================================================
    //  Tools: Burn CD to Library (read an audio CD into the music folder)
    // =====================================================================
    private void show_burn_cd () {
        var dialog = new Gtk.Window ();
        dialog.title = "Burn CD to Library";
        dialog.transient_for = this;
        dialog.modal = true;
        dialog.default_width = 540;
        dialog.default_height = 540;
        dialog.add_css_class ("cranberry");   // follows the active theme

        var box = new Gtk.Box (Gtk.Orientation.VERTICAL, 12);
        box.margin_top = 20; box.margin_bottom = 18; box.margin_start = 20; box.margin_end = 20;

        var heading = new Gtk.Label ("Burn CD to Library");
        heading.add_css_class ("welcome-title");
        heading.xalign = 0;
        box.append (heading);

        // Guard 1: a music folder must be set (that's where ripped tracks go).
        if (music_folder == "") {
            var msg = new Gtk.Label ("Set your music folder first (File → Open Music Folder), then come back to import a CD.");
            msg.add_css_class ("content-sub"); msg.wrap = true; msg.xalign = 0; msg.max_width_chars = 54;
            var pick = new Gtk.Button.with_label ("Choose Music Folder…");
            pick.add_css_class ("pill"); pick.add_css_class ("accent"); pick.halign = Gtk.Align.START;
            pick.clicked.connect (() => { dialog.destroy (); choose_folder (); });
            box.append (msg); box.append (pick);
            dialog.set_child (box); dialog.present (); return;
        }

        // Guard 2: the GStreamer CD + FLAC plugins must be present.
        if (!CdRip.supported ()) {
            var msg = new Gtk.Label ("CD ripping needs the GStreamer cdparanoia and FLAC plugins, which don't appear to be installed. On elementary OS / Ubuntu:\n\n    sudo apt install gstreamer1.0-plugins-base gstreamer1.0-plugins-good\n\n(The native install.sh build already pulls these in.)");
            msg.add_css_class ("content-sub"); msg.wrap = true; msg.xalign = 0; msg.max_width_chars = 58;
            var close = new Gtk.Button.with_label ("Close");
            close.add_css_class ("pill"); close.add_css_class ("accent"); close.halign = Gtk.Align.END;
            close.clicked.connect (() => dialog.destroy ());
            box.append (msg); box.append (close);
            dialog.set_child (box); dialog.present (); return;
        }

        var ripper = new CdRip ();

        var intro = new Gtk.Label ("Insert an audio CD and detect it. Tracks import into your library (format set in Settings → CD ripping; FLAC by default), organised as Album Artist / Album / NN Title. Titles come from CD-TEXT when present — edit anything below before ripping.");
        intro.add_css_class ("content-sub"); intro.wrap = true; intro.xalign = 0; intro.max_width_chars = 58;
        box.append (intro);

        var dev_lbl = new Gtk.Label ("CD device"); dev_lbl.add_css_class ("content-sub");
        var dev_entry = new Gtk.Entry ();
        dev_entry.text = Application.settings.get_str ("cd_device", "/dev/cdrom");
        dev_entry.hexpand = true;
        var dev_row = new Gtk.Box (Gtk.Orientation.HORIZONTAL, 8);
        dev_row.append (dev_lbl); dev_row.append (dev_entry);
        box.append (dev_row);

        var detect_btn = new Gtk.Button.with_label ("Detect Disc");
        detect_btn.add_css_class ("pill"); detect_btn.halign = Gtk.Align.START;
        box.append (detect_btn);

        var status = new Gtk.Label ("");
        status.add_css_class ("content-sub"); status.xalign = 0; status.wrap = true; status.max_width_chars = 58;
        box.append (status);

        var grid = new Gtk.Grid (); grid.row_spacing = 8; grid.column_spacing = 14;
        int r = 0;
        var e_artist = prop_field (grid, ref r, "Album Artist", "");
        var e_album  = prop_field (grid, ref r, "Album", "");
        grid.visible = false;
        box.append (grid);

        var titles_box = new Gtk.Box (Gtk.Orientation.VERTICAL, 4);
        var titles_scroller = new Gtk.ScrolledWindow ();
        titles_scroller.vexpand = true;
        titles_scroller.min_content_height = 120;
        titles_scroller.hscrollbar_policy = Gtk.PolicyType.NEVER;
        titles_scroller.set_child (titles_box);
        titles_scroller.visible = false;
        box.append (titles_scroller);

        Gtk.Entry[] title_entries = {};

        var progress = new Gtk.ProgressBar ();
        progress.visible = false;
        box.append (progress);

        var close_btn = new Gtk.Button.with_label ("Close");
        close_btn.add_css_class ("pill"); close_btn.halign = Gtk.Align.END;
        close_btn.clicked.connect (() => dialog.destroy ());
        var rip_btn = new Gtk.Button.with_label ("Rip to Library");
        rip_btn.add_css_class ("pill"); rip_btn.add_css_class ("accent");
        rip_btn.halign = Gtk.Align.END; rip_btn.sensitive = false;
        var btns = new Gtk.Box (Gtk.Orientation.HORIZONTAL, 8); btns.halign = Gtk.Align.END;
        btns.append (close_btn); btns.append (rip_btn);
        box.append (btns);

        detect_btn.clicked.connect (() => {
            ripper.device = dev_entry.text.strip ();
            status.label = "Reading disc…";
            detect_btn.sensitive = false;
            ripper.detect_async ();
        });

        ripper.detected.connect ((disc) => {
            detect_btn.sensitive = true;
            if (disc == null) {
                status.label = "No audio CD found, or the drive couldn't be read. Check that a disc is inserted and the device path is correct.";
                return;
            }
            status.label = "Found %d track%s.".printf (disc.n_tracks, disc.n_tracks == 1 ? "" : "s");
            e_artist.text = disc.artist;
            e_album.text = disc.album;
            grid.visible = true;

            Gtk.Widget? c = titles_box.get_first_child ();
            while (c != null) { var nx = c.get_next_sibling (); titles_box.remove (c); c = nx; }
            title_entries = {};
            for (int i = 0; i < disc.n_tracks; i++) {
                var row = new Gtk.Box (Gtk.Orientation.HORIZONTAL, 8);
                var num = new Gtk.Label ("%02d".printf (i + 1));
                num.add_css_class ("content-sub");
                var te = new Gtk.Entry (); te.hexpand = true;
                te.text = (i < disc.titles.length && disc.titles[i] != "")
                    ? disc.titles[i] : "Track %d".printf (i + 1);
                row.append (num); row.append (te);
                titles_box.append (row);
                title_entries += te;
            }
            titles_scroller.visible = true;
            rip_btn.sensitive = true;
        });

        rip_btn.clicked.connect (() => {
            string[] titles = {};
            foreach (var te in title_entries) titles += te.text.strip ();
            ripper.device = dev_entry.text.strip ();
            ripper.format = Application.settings.get_str ("rip_format", "flac");
            Application.settings.set_str ("cd_device", dev_entry.text.strip ());
            rip_btn.sensitive = false; detect_btn.sensitive = false;
            progress.visible = true; progress.fraction = 0;
            status.label = "Ripping… this can take a few minutes.";
            ripper.rip_async (music_folder, e_artist.text.strip (), e_album.text.strip (), titles);
        });

        ripper.progress.connect ((done, total, frac) => {
            progress.fraction = frac;
            status.label = "Ripping… track %d of %d.".printf (done, total);
        });

        ripper.failed.connect ((m) => {
            status.label = m;
            rip_btn.sensitive = true; detect_btn.sensitive = true;
        });

        ripper.finished.connect ((ripped, dir) => {
            progress.fraction = 1.0;
            status.label = "Imported %d track%s into your library. Refreshing…".printf (ripped, ripped == 1 ? "" : "s");
            library.scan (music_folder);   // pick up the new album
            detect_btn.sensitive = true;
        });

        dialog.set_child (box);
        dialog.present ();
    }

    // =====================================================================
    //  Playback
    // =====================================================================
    private void play_from_model (int pos) {
        queue = new GenericArray<Track> ();
        uint n = selection.get_n_items ();
        for (uint i = 0; i < n; i++) queue.add ((Track) selection.get_item (i));
        start_queue_at (pos);
    }

    private void play_paths (string[] paths) {
        var by_path = build_path_map ();
        queue = new GenericArray<Track> ();
        foreach (var p in paths) {
            var t = by_path.lookup (p);
            if (t != null) queue.add (t);
        }
        if (queue.length > 0) start_queue_at (0);
    }

    // Play files handed to us by the OS (default-music-player open).
    public void play_files (File[] files) {
        queue = new GenericArray<Track> ();
        foreach (var f in files) {
            var t = new Track ();
            t.path = f.get_path () ?? "";
            t.uri = f.get_uri ();
            t.title = f.get_basename () ?? "Audio";
            queue.add (t);
        }
        if (queue.length > 0) start_queue_at (0);
    }

    // Open external files straight into the compact Mini Player (default-player path).
    public void play_files_in_mini (File[] files) {
        // Opening a single file: queue its whole folder so Skip/Next walks through
        // the other audio files alongside it. Multiple files: just queue those.
        if (files.length == 1) play_folder_of (files[0]);
        else play_files (files);

        if (queue.length > 0 && !mini_mode) {
            // Defer so the window is presented/mapped before it collapses.
            Idle.add (() => { if (!mini_mode) enter_mini (); return false; });
        }
    }

    // Queue every audio file in the opened file's folder (sorted by name) and
    // start playback at the opened file, so Skip/Next plays through the folder.
    private void play_folder_of (File file) {
        string target = file.get_path () ?? "";
        var parent = file.get_parent ();
        string[] paths = {};
        if (parent != null) {
            try {
                var en = parent.enumerate_children ("standard::name,standard::type",
                    FileQueryInfoFlags.NONE, null);
                FileInfo info;
                while ((info = en.next_file (null)) != null) {
                    if (info.get_file_type () != FileType.REGULAR) continue;
                    if (is_audio_name (info.get_name ()))
                        paths += parent.get_child (info.get_name ()).get_path ();
                }
            } catch (Error e) { /* fall through to single-file */ }
        }
        if (paths.length == 0) { play_files ({ file }); return; }

        // Sort by path so the folder plays in a sensible order.
        for (int i = 0; i < paths.length; i++)
            for (int j = i + 1; j < paths.length; j++)
                if (GLib.strcmp (paths[j], paths[i]) < 0) { var t = paths[i]; paths[i] = paths[j]; paths[j] = t; }

        queue = new GenericArray<Track> ();
        int start = 0;
        for (int i = 0; i < paths.length; i++) {
            var tk = new Track ();
            tk.path = paths[i];
            tk.uri = File.new_for_path (paths[i]).get_uri ();
            tk.title = Path.get_basename (paths[i]);
            queue.add (tk);
            if (paths[i] == target) start = i;
        }
        start_queue_at (start);
    }

    private bool is_audio_name (string name) {
        string n = name.down ();
        return n.has_suffix (".mp3") || n.has_suffix (".m4a") || n.has_suffix (".m4b")
            || n.has_suffix (".flac") || n.has_suffix (".ogg") || n.has_suffix (".oga")
            || n.has_suffix (".opus") || n.has_suffix (".wav") || n.has_suffix (".aac")
            || n.has_suffix (".wma") || n.has_suffix (".aiff") || n.has_suffix (".aif");
    }

    private void play_paths_single (Track t) {
        queue = new GenericArray<Track> ();
        queue.add (t);
        start_queue_at (0);
    }

    // Insert a track so it plays right after the current one (in play order).
    private void play_next (Track t) {
        if (order.length == 0 || order_pos < 0) { play_paths_single (t); return; }
        queue.add (t);
        int new_qi = (int) queue.length - 1;
        int[] no = {};
        for (int i = 0; i < order.length; i++) {
            no += order[i];
            if (i == order_pos) no += new_qi;   // splice the new track in just after current
        }
        order = no;
    }

    // Smart Shuffle — a "sensible random" playlist: seed from the current (or a
    // random) song and gather tracks that share its genre, then shuffle them.
    // (Discogs styles can enrich the seed's genre when enabled.)
    private void smart_shuffle () {
        uint n = library.store.get_n_items ();
        if (n == 0) return;

        Track? seed = (q_index >= 0 && q_index < queue.length) ? queue[q_index] : null;
        if (seed == null) seed = (Track) library.store.get_item (Random.int_range (0, (int) n));
        string genre = seed.genre;

        var pool = new GenericArray<Track> ();
        for (uint i = 0; i < n; i++) {
            var t = (Track) library.store.get_item (i);
            if (genre != "" && t.genre == genre) pool.add (t);
        }
        if (pool.length < 8) {   // genre missing/too narrow — widen to the whole library
            pool = new GenericArray<Track> ();
            for (uint i = 0; i < n; i++) pool.add ((Track) library.store.get_item (i));
        }

        // Shuffle the pool (Fisher–Yates), keeping the seed first.
        int[] idx = {};
        for (int i = 0; i < pool.length; i++) if (pool[i] != seed) idx += i;
        for (int i = idx.length - 1; i > 0; i--) {
            int j = Random.int_range (0, i + 1);
            int tmp = idx[i]; idx[i] = idx[j]; idx[j] = tmp;
        }

        queue = new GenericArray<Track> ();
        queue.add (seed);
        foreach (int i in idx) queue.add (pool[i]);

        shuffle = false;               // the queue is already a sensible random order
        reflect_modes ();
        Application.settings.set_flag ("shuffle", false);
        start_queue_at (0);
        status_label.label = "Smart Shuffle · %d songs".printf ((int) queue.length);
    }

    // Distinct genres present in the library (for the Discogs settings picker).
    private string[] library_genres () {
        var seen = new GLib.HashTable<string, bool> (str_hash, str_equal);
        string[] g = {};
        uint n = library.store.get_n_items ();
        for (uint i = 0; i < n; i++) {
            var gen = ((Track) library.store.get_item (i)).genre;
            if (gen != "" && !seen.contains (gen)) { seen.insert (gen, true); g += gen; }
        }
        return g;
    }

    // Build and save a random playlist of up to `limit` songs from one genre.
    // Saved as a normal playlist so it persists even with Discogs turned off.
    private void create_genre_playlist (string genre) {
        if (genre == "") return;
        uint n = library.store.get_n_items ();
        int[] idxs = {};
        for (uint i = 0; i < n; i++) {
            if (((Track) library.store.get_item (i)).genre == genre) idxs += (int) i;
        }
        if (idxs.length == 0) return;
        for (int i = idxs.length - 1; i > 0; i--) {   // Fisher–Yates
            int j = Random.int_range (0, i + 1);
            int tmp = idxs[i]; idxs[i] = idxs[j]; idxs[j] = tmp;
        }
        int take = idxs.length < 40 ? idxs.length : 40;
        string[] paths = {};
        for (int i = 0; i < take; i++) paths += ((Track) library.store.get_item (idxs[i])).path;

        string name = "Random · " + genre;
        Application.settings.set_playlist (name, paths);
        rebuild_playlists ();
        status_label.label = "Created playlist \"%s\" · %d songs".printf (name, paths.length);
    }

    private GLib.HashTable<string, Track> build_path_map () {
        var map = new GLib.HashTable<string, Track> (str_hash, str_equal);
        uint n = library.store.get_n_items ();
        for (uint i = 0; i < n; i++) {
            var t = (Track) library.store.get_item (i);
            map.insert (t.path, t);
        }
        return map;
    }

    private void start_queue_at (int idx) {
        if (queue.length == 0) return;
        build_order (idx);
        play_current ();
    }

    // Build the play order around `start_qi`. Shuffle = that track first, then a
    // random permutation of the rest; sequential = natural order, positioned at it.
    private void build_order (int start_qi) {
        int n = (int) queue.length;
        order = new int[n];
        for (int i = 0; i < n; i++) order[i] = i;
        if (shuffle && n > 1) {
            // Fisher–Yates, then bring start_qi to the front.
            for (int i = n - 1; i > 0; i--) {
                int j = Random.int_range (0, i + 1);
                int tmp = order[i]; order[i] = order[j]; order[j] = tmp;
            }
            for (int i = 0; i < n; i++) {
                if (order[i] == start_qi) {
                    int tmp = order[0]; order[0] = order[i]; order[i] = tmp;
                    break;
                }
            }
            order_pos = 0;
        } else {
            order_pos = (start_qi >= 0 && start_qi < n) ? start_qi : 0;
        }
    }

    // Re-derive the order around the current track when shuffle is toggled, so
    // "Up Next" reflects the new mode immediately without interrupting playback.
    private void reshuffle_around_current () {
        if (queue.length == 0 || order_pos < 0) return;
        build_order (q_index);
    }

    // Jump to an absolute position within `order` (used by the Up Next list).
    private void jump_to (int oi) {
        if (oi < 0 || oi >= order.length) return;
        order_pos = oi;
        play_current ();
    }

    private void play_current () {
        if (order_pos < 0 || order_pos >= order.length) return;
        q_index = order[order_pos];
        if (q_index < 0 || q_index >= queue.length) return;
        var t = queue[q_index];
        anchor_pos_us = 0;
        anchor_dur_us = 0;
        seek_scale.set_value (0);
        player.load_and_play (t.uri);
        update_now_playing (t);
    }

    // "Up Next" — the upcoming songs in the real play order (shuffle-aware),
    // each reorderable with move up/down, openable from the player.
    private void show_queue_popover (Gtk.Widget anchor) {
        var outer = new Gtk.Box (Gtk.Orientation.VERTICAL, 2);
        outer.margin_top = 8;
        outer.margin_bottom = 8;
        outer.margin_start = 8;
        outer.margin_end = 8;
        var title = new Gtk.Label ("Up Next");
        title.add_css_class ("side-title");
        title.xalign = 0;
        outer.append (title);

        var list = new Gtk.Box (Gtk.Orientation.VERTICAL, 2);
        outer.append (list);
        populate_up_next (list);

        var scroller = new Gtk.ScrolledWindow ();
        scroller.set_child (outer);
        scroller.set_size_request (320, 340);
        scroller.propagate_natural_height = true;

        var pop = new Gtk.Popover ();
        pop.set_child (scroller);
        pop.set_parent (anchor);
        pop.popup ();
    }

    // Fill (or refill) the Up Next list from order[order_pos+1 …].
    private void populate_up_next (Gtk.Box list) {
        Gtk.Widget? c;
        while ((c = list.get_first_child ()) != null) list.remove (c);

        int shown = 0;
        for (int oi = order_pos + 1; oi < order.length && shown < 80; oi++) {
            int qi = order[oi];
            if (qi < 0 || qi >= (int) queue.length) continue;
            var tk = queue[qi];

            var nm = new Gtk.Label (tk.title);
            nm.add_css_class ("cell-title");
            nm.xalign = 0;
            nm.ellipsize = Pango.EllipsizeMode.END;
            var sub = new Gtk.Label (tk.artist);
            sub.add_css_class ("content-sub");
            sub.xalign = 0;
            sub.ellipsize = Pango.EllipsizeMode.END;
            var rb = new Gtk.Box (Gtk.Orientation.VERTICAL, 0);
            rb.hexpand = true;
            rb.append (nm);
            rb.append (sub);
            var btn = new Gtk.Button ();
            btn.add_css_class ("album-card");
            btn.hexpand = true;
            btn.set_child (rb);
            int target = oi;
            btn.clicked.connect (() => jump_to (target));

            var up = new Gtk.Button.from_icon_name ("go-up-symbolic");
            up.add_css_class ("mode-button");
            up.tooltip_text = "Move up";
            up.sensitive = oi > order_pos + 1;
            int here = oi;
            up.clicked.connect (() => { move_in_order (here, here - 1); populate_up_next (list); });

            var down = new Gtk.Button.from_icon_name ("go-down-symbolic");
            down.add_css_class ("mode-button");
            down.tooltip_text = "Move down";
            down.sensitive = oi < order.length - 1;
            down.clicked.connect (() => { move_in_order (here, here + 1); populate_up_next (list); });

            var row = new Gtk.Box (Gtk.Orientation.HORIZONTAL, 4);
            row.append (btn);
            row.append (up);
            row.append (down);
            list.append (row);
            shown++;
        }
        if (shown == 0) {
            var none = new Gtk.Label ("Nothing queued");
            none.add_css_class ("content-sub");
            none.xalign = 0;
            list.append (none);
        }
    }

    // Swap two upcoming entries in `order` (both must be after the current pos).
    private void move_in_order (int a, int b) {
        if (a <= order_pos || b <= order_pos) return;
        if (a < 0 || b < 0 || a >= order.length || b >= order.length) return;
        int tmp = order[a]; order[a] = order[b]; order[b] = tmp;
    }

    // =====================================================================
    //  Mini Player — the whole window collapses to the album cover
    // =====================================================================
    private Gtk.Widget mini_titlebar () {
        var h = new Gtk.WindowHandle ();
        var b = new Gtk.Box (Gtk.Orientation.HORIZONTAL, 0);
        b.set_size_request (-1, 1);
        h.set_child (b);
        return h;
    }

    private void enter_mini () {
        if (mini_mode) return;
        mini_mode = true;
        saved_w = get_width ();
        saved_h = get_height ();
        if (saved_w < 200) saved_w = 1180;
        if (saved_h < 200) saved_h = 760;
        unfullscreen ();   // crucial: a fullscreen window ignores resize requests
        unmaximize ();
        set_titlebar (mini_titlebar ());
        set_child (build_mini_player ());
        set_default_size (300, 340);
        set_resizable (false);   // snap the window down to the mini content's size
    }

    private void exit_mini () {
        if (!mini_mode) return;
        mini_mode = false;
        mini_seek = null;
        mini_cur = null;
        mini_rem = null;
        mini_art = null;
        mini_play = null;
        if (mini_hide_id != 0) { Source.remove (mini_hide_id); mini_hide_id = 0; }
        set_resizable (true);
        set_titlebar (normal_titlebar);
        set_child (normal_content);
        set_default_size (saved_w, saved_h);
    }

    private Gtk.Widget build_mini_player () {
        var art = new Gtk.Picture ();
        art.content_fit = Gtk.ContentFit.COVER;
        art.set_size_request (300, 300);
        mini_art = art;
        Track? t = (q_index >= 0 && q_index < queue.length) ? queue[q_index] : null;
        Gdk.Texture? tex = (t != null) ? library.get_texture_for_track (t, 600) : null;
        if (tex == null) tex = Gdk.Texture.from_resource ("/io/github/cranberry/juice/appicon.png");
        art.paintable = tex;

        var overlay = new Gtk.Overlay ();
        overlay.set_child (art);

        // Cranberry icon, top-right → switch back to the full window.
        var icon_img = new Gtk.Image.from_paintable (Gdk.Texture.from_resource ("/io/github/cranberry/juice/appicon.png"));
        icon_img.pixel_size = 22;
        var close_btn = new Gtk.Button ();
        close_btn.set_child (icon_img);
        close_btn.add_css_class ("mini-close");
        close_btn.halign = Gtk.Align.END;
        close_btn.valign = Gtk.Align.START;
        close_btn.margin_top = 8;
        close_btn.margin_end = 8;
        close_btn.tooltip_text = "Switch to the full window";
        close_btn.clicked.connect (exit_mini);
        overlay.add_overlay (close_btn);

        // Progress row (current time · scrubber · remaining).
        mini_cur = new Gtk.Label ("0:00");
        mini_cur.add_css_class ("mini-time");
        mini_rem = new Gtk.Label ("0:00");
        mini_rem.add_css_class ("mini-time");
        mini_seek = new Gtk.Scale.with_range (Gtk.Orientation.HORIZONTAL, 0, 1, 0.001);
        mini_seek.draw_value = false;
        mini_seek.add_css_class ("seek");
        mini_seek.hexpand = true;
        mini_seek.change_value.connect ((scroll, val) => {
            player.seek_fraction (val < 0 ? 0 : (val > 1 ? 1 : val));
            return false;
        });
        var prog_row = new Gtk.Box (Gtk.Orientation.HORIZONTAL, 8);
        prog_row.add_css_class ("mini-prog-bubble");   // grey translucent bubble, progress + times only
        prog_row.append (mini_cur);
        prog_row.append (mini_seek);
        prog_row.append (mini_rem);

        // Control row.
        var prev = new Gtk.Button.from_icon_name ("media-skip-backward-symbolic");
        prev.add_css_class ("mini-btn");
        prev.clicked.connect (prev_track);
        var play = new Gtk.Button.from_icon_name (player.is_playing ? "media-playback-pause-symbolic" : "media-playback-start-symbolic");
        play.add_css_class ("mini-btn");
        play.add_css_class ("mini-play");
        mini_play = play;
        // Just toggle — the player's playing_changed signal updates the icon, so
        // it stays correct however playback is changed (here, the main bar, or space).
        play.clicked.connect (() => player.toggle ());
        var next = new Gtk.Button.from_icon_name ("media-skip-forward-symbolic");
        next.add_css_class ("mini-btn");
        next.clicked.connect (() => next_track ());
        var qbtn = new Gtk.Button.from_icon_name ("view-list-symbolic");
        qbtn.add_css_class ("mini-btn");
        qbtn.tooltip_text = "Open the Up Next list";
        qbtn.clicked.connect (() => show_queue_popover (qbtn));
        var ctrl_row = new Gtk.Box (Gtk.Orientation.HORIZONTAL, 10);
        ctrl_row.halign = Gtk.Align.CENTER;
        ctrl_row.append (prev);
        ctrl_row.append (play);
        ctrl_row.append (next);
        ctrl_row.append (qbtn);

        // Glass panel that slides over the bottom of the cover on hover.
        var panel = new Gtk.Box (Gtk.Orientation.VERTICAL, 6);
        panel.add_css_class ("mini-panel");
        panel.valign = Gtk.Align.END;
        panel.append (prog_row);
        panel.append (ctrl_row);
        overlay.add_overlay (panel);

        // Idle = just the cover; hovering reveals the panel + close button.
        close_btn.opacity = 0;
        panel.opacity = 0;
        var motion = new Gtk.EventControllerMotion ();
        overlay.add_controller (motion);
        motion.motion.connect ((x, y) => {
            close_btn.opacity = 1;
            panel.opacity = 1;
            if (mini_hide_id != 0) Source.remove (mini_hide_id);
            mini_hide_id = Timeout.add (2400, () => {
                close_btn.opacity = 0;
                panel.opacity = 0;
                mini_hide_id = 0;
                return false;
            });
        });

        var handle = new Gtk.WindowHandle ();
        handle.set_child (overlay);
        return handle;
    }

    private void set_empty_state (bool empty) {
        np_empty = empty;
        if (np_text_col == null) return;
        np_text_col.visible = !empty;
        np_modes.visible = !empty;
        np_art_overlay.hexpand = empty;
        np_art_overlay.halign = empty ? Gtk.Align.CENTER : Gtk.Align.START;
        np_art.pixel_size = empty ? 60 : 38;
        if (empty) {
            np_art.set_from_paintable (Gdk.Texture.from_resource ("/io/github/cranberry/juice/appicon.png"));
            np_title.label = "";
            np_sub.label = "";
        }
    }

    private void next_track (bool auto = false) {
        if (order.length == 0) return;
        if (auto && repeat == "one") { player.seek_fraction (0); player.resume (); return; }
        // Advance through the fixed play order (the upcoming songs the user sees).
        if (order_pos < order.length - 1) {
            order_pos++;
            play_current ();
        } else if (repeat == "all") {
            order_pos = 0;
            play_current ();
        } else {
            player.stop ();
        }
    }

    private void prev_track () {
        if (order.length == 0) return;
        // Walk back through the order = the songs actually played (shuffle too).
        if (order_pos > 0) {
            order_pos--;
            play_current ();
        } else {
            player.seek_fraction (0);   // already first — restart current
        }
    }

    private void update_now_playing (Track t) {
        set_empty_state (false);   // a song is playing — show the full display
        np_title.label = t.title;
        np_sub.label = t.album != "" ? "%s — %s".printf (t.artist, t.album) : t.artist;
        dur_time.label = t.duration_str ();
        var tex = library.get_texture_for_track (t, 80);
        if (tex != null) np_art.set_from_paintable (tex);
        else np_art.set_from_icon_name ("audio-x-generic-symbolic");

        // Keep the Mini Player cover in step with the current song.
        if (mini_art != null) {
            var big = library.get_texture_for_track (t, 600);
            mini_art.paintable = big != null
                ? big : Gdk.Texture.from_resource ("/io/github/cranberry/juice/appicon.png");
        }

        push_mpris ();
        maybe_fetch_artist_image (t.artist);
    }

    // Pull an artist photo from Discogs (if enabled) the first time we hear them.
    private void maybe_fetch_artist_image (string artist) {
        if (!discogs.available ()) return;
        if (!Application.settings.get_flag ("discogs_auto_art", true)) return;
        if (library.has_artist_art (artist)) return;
        begin_loading ();   // network fetch — show the cranberry-cup indicator
        discogs.fetch_artist_image (artist, (bytes) => {
            end_loading ();
            if (bytes == null) return;
            library.put_art ("artist:" + artist, bytes);
            if (view == "artists") refresh_current_view ();   // show it if that page is open
        });
    }

    // ----- MPRIS bridge (sound indicator) -----
    private void push_mpris () {
        if (mpris == null) return;
        if (q_index < 0 || q_index >= queue.length) {
            mpris.update ("Stopped", "", "", "", null);
            return;
        }
        var t = queue[q_index];
        string status = player.is_playing ? "Playing" : "Paused";
        mpris.update (status, t.title, t.artist, t.album, library.art_url (t.album_key));
    }

    public void mpris_play_pause () { player.toggle (); }
    public void mpris_next () { next_track (); }
    public void mpris_previous () { prev_track (); }

    private void reflect_modes () {
        if (shuffle) shuffle_button.add_css_class ("active");
        else shuffle_button.remove_css_class ("active");
        if (repeat != "off") repeat_button.add_css_class ("active");
        else repeat_button.remove_css_class ("active");
        repeat_button.icon_name = (repeat == "one")
            ? "media-playlist-repeat-song-symbolic" : "media-playlist-repeat-symbolic";
    }

    // =====================================================================
    //  Wiring
    // =====================================================================
    private void wire_player () {
        player.playing_changed.connect ((playing) => {
            string ic = playing ? "media-playback-pause-symbolic" : "media-playback-start-symbolic";
            play_button.icon_name = ic;
            if (mini_play != null) mini_play.icon_name = ic;   // keep the mini player in sync
            push_mpris ();   // reflect play/pause in the sound indicator
        });
        player.position_changed.connect ((pos, dur) => {
            // pos/dur are nanoseconds; anchor them and let the tick interpolate.
            anchor_pos_us = pos / 1000;
            anchor_dur_us = dur / 1000;
            anchor_at = get_monotonic_time ();
            if (dur > 0) {
                int dsec = (int) (dur / 1000000000);
                dur_time.label = "%d:%02d".printf (dsec / 60, dsec % 60);
            }
        });
        player.track_finished.connect (() => next_track (true));

        // Animate the progress at the frame rate. Attach to the window (always
        // mapped) so it keeps ticking in Mini Player mode too, where the main
        // scrubber is detached from the tree.
        ((Gtk.Widget) this).add_tick_callback (progress_tick);
    }

    private bool progress_tick (Gtk.Widget w, Gdk.FrameClock fc) {
        if (player.is_playing && anchor_dur_us > 0) {
            int64 est = anchor_pos_us + (get_monotonic_time () - anchor_at);
            if (est < 0) est = 0;
            if (est > anchor_dur_us) est = anchor_dur_us;
            double frac = (double) est / anchor_dur_us;
            seek_scale.set_value (frac);
            int s = (int) (est / 1000000);
            cur_time.label = "%d:%02d".printf (s / 60, s % 60);
            if (mini_seek != null) {
                mini_seek.set_value (frac);
                mini_cur.label = "%d:%02d".printf (s / 60, s % 60);
                int rem = (int) ((anchor_dur_us - est) / 1000000);
                mini_rem.label = "-%d:%02d".printf (rem / 60, rem % 60);
            }
        }
        return true;
    }

    private void wire_library () {
        library.scan_started.connect ((total) => {
            scan_card.visible = true;
            begin_loading ();
            scan_label.label = total > 0 ? "Reading %u tracks…".printf (total) : "Looking for music…";
        });
        library.scan_progress.connect ((done, total) => {
            scan_label.label = "Reading tracks… %u / %u".printf (done, total);
        });
        library.scan_finished.connect ((count) => {
            scan_card.visible = false;
            end_loading ();
            albums_dirty = true;   // library changed — recollect albums on next view
            update_status ();
            refresh_current_view ();
        });
    }

    private void update_status () {
        uint n = library.store.get_n_items ();
        int64 total = 0;
        for (uint i = 0; i < n; i++) total += ((Track) library.store.get_item (i)).duration;
        int hrs = (int) (total / 3600);
        int mins = (int) ((total % 3600) / 60);
        string time = hrs > 0 ? "%d hr %d min".printf (hrs, mins) : "%d min".printf (mins);
        status_label.label = "%u songs · %s".printf (n, time);
    }

    private Gtk.Box build_scan_card () {
        var spinner = new Gtk.Spinner ();
        spinner.spinning = true;
        spinner.set_size_request (32, 32);
        scan_label = new Gtk.Label ("Scanning…");
        scan_label.add_css_class ("welcome-body");
        var card = new Gtk.Box (Gtk.Orientation.VERTICAL, 12);
        card.add_css_class ("welcome-note");
        card.halign = Gtk.Align.CENTER;
        card.valign = Gtk.Align.CENTER;
        card.append (spinner);
        card.append (scan_label);
        return card;
    }

    // =====================================================================
    //  Loading indicator — a cranberry cup that fills from a floating jug
    // =====================================================================
    private Gtk.Widget build_loading_indicator () {
        loading_area = new Gtk.DrawingArea ();
        loading_area.content_width = 58;
        loading_area.content_height = 66;
        loading_area.halign = Gtk.Align.START;
        loading_area.valign = Gtk.Align.END;
        loading_area.margin_start = 12;
        loading_area.margin_bottom = 34;     // float just above the status bar
        loading_area.can_target = false;     // decorative — never block clicks
        loading_area.visible = false;
        loading_area.set_draw_func (draw_loading);
        return loading_area;
    }

    private void begin_loading () {
        loading_count++;
        if (loading_area != null) loading_area.visible = true;
    }

    private void end_loading () {
        if (loading_count > 0) loading_count--;
        if (loading_count == 0 && loading_area != null) loading_area.visible = false;
    }

    private bool loading_tick (Gtk.Widget w, Gdk.FrameClock fc) {
        if (loading_count > 0 && loading_area != null) {
            int64 now = get_monotonic_time ();
            if (loading_last == 0) loading_last = now;
            loading_phase += (now - loading_last) / 1000000.0 / 2.0;   // ~2s per loop
            loading_last = now;
            while (loading_phase >= 1.0) loading_phase -= 1.0;
            loading_area.queue_draw ();
        } else {
            loading_last = 0;
        }
        return true;   // keep the tick alive for the next loading spell
    }

    // The loop: jug pours → cup fills (jug drains); then cup drains while the
    // jug refills — then around again. Pure Cairo, cranberry red throughout.
    private void draw_loading (Gtk.DrawingArea area, Cairo.Context cr, int width, int height) {
        double w = width, h = height;
        double p = loading_phase;
        double cup, jug; bool pouring;
        if (p < 0.5) { double f = p / 0.5; cup = f;           jug = 1.0 - 0.7 * f; pouring = true;  }
        else         { double f = (p - 0.5) / 0.5; cup = 1.0 - f; jug = 0.3 + 0.7 * f; pouring = false; }

        double R = 0.98, G = 0.176, B = 0.294;   // cranberry

        // ----- floating jug (top) -----
        double jx = w * 0.30, jy = h * 0.05, jw = w * 0.40, jh = h * 0.28;
        cr.rectangle (jx, jy, jw, jh);
        cr.set_source_rgba (1, 1, 1, 0.14); cr.fill ();
        double fill_h = jh * 0.80 * jug;
        cr.rectangle (jx, jy + jh - fill_h, jw, fill_h);
        cr.set_source_rgba (R, G, B, 0.90); cr.fill ();
        cr.set_line_width (1.4);
        cr.rectangle (jx, jy, jw, jh);
        cr.set_source_rgba (1, 1, 1, 0.5); cr.stroke ();

        // spout under the jug
        double sx = jx + jw * 0.5;
        double spout_bottom = jy + jh + h * 0.06;
        cr.rectangle (sx - 1.4, jy + jh, 2.8, h * 0.06);
        cr.set_source_rgba (1, 1, 1, 0.5); cr.fill ();

        // ----- cup (trapezoid, bottom) -----
        double cup_top = h * 0.50, cup_bot = h * 0.92;
        double cx = w * 0.5, top_w = w * 0.42, bot_w = w * 0.30;
        double tlx = cx - top_w / 2, trx = cx + top_w / 2;
        double blx = cx - bot_w / 2, brx = cx + bot_w / 2;

        // pour stream into the cup
        if (pouring) {
            cr.rectangle (sx - 1.2, spout_bottom, 2.4, cup_top - spout_bottom);
            cr.set_source_rgba (R, G, B, 0.90); cr.fill ();
        }

        // juice inside the cup (clipped to the cup outline, filled from the base)
        double level_y = cup_bot - (cup_bot - cup_top) * cup;
        cr.save ();
        cr.move_to (tlx, cup_top); cr.line_to (trx, cup_top);
        cr.line_to (brx, cup_bot); cr.line_to (blx, cup_bot); cr.close_path ();
        cr.clip ();
        cr.rectangle (tlx, level_y, top_w, cup_bot - level_y);
        cr.set_source_rgba (R, G, B, 0.92); cr.fill ();
        cr.restore ();

        // cup outline
        cr.set_line_width (1.6);
        cr.move_to (tlx, cup_top); cr.line_to (trx, cup_top);
        cr.line_to (brx, cup_bot); cr.line_to (blx, cup_bot); cr.close_path ();
        cr.set_source_rgba (1, 1, 1, 0.7); cr.stroke ();
    }

    // =====================================================================
    //  Folder selection & visuals
    // =====================================================================
    private void choose_folder () {
        var dialog = new Gtk.FileDialog ();
        dialog.title = "Choose your Music folder";
        dialog.select_folder.begin (this, null, (obj, res) => {
            try {
                var folder = dialog.select_folder.end (res);
                if (folder != null && folder.get_path () != null) set_folder (folder.get_path ());
            } catch (Error e) {
                // cancelled
            }
        });
    }

    private void set_folder (string path) {
        music_folder = path;
        Application.settings.set_str ("music_folder", path);
        show_songs ();
        library.scan (path);
    }

    private void open_visuals () {
        if (visuals == null) {
            visuals = new Visualizer (player);
            // Deliberately NOT transient-for-the-main-window: some compositors
            // refuse true fullscreen on transient windows.
        }
        visuals.open ();
    }

    // =====================================================================
    //  Simple text prompt dialog
    // =====================================================================
    private void prompt_text (string title, string initial, owned PromptCb cb) {
        var dialog = new Gtk.Window ();
        dialog.title = title;
        dialog.transient_for = this;
        dialog.modal = true;
        dialog.default_width = 320;
        dialog.add_css_class ("cranberry");

        var entry = new Gtk.Entry ();
        entry.text = initial;
        entry.hexpand = true;

        var ok = new Gtk.Button.with_label ("OK");
        ok.add_css_class ("pill");
        ok.add_css_class ("accent");
        var cancel = new Gtk.Button.with_label ("Cancel");
        cancel.add_css_class ("pill");
        var actions = new Gtk.Box (Gtk.Orientation.HORIZONTAL, 10);
        actions.halign = Gtk.Align.END;
        actions.append (cancel);
        actions.append (ok);

        var box = new Gtk.Box (Gtk.Orientation.VERTICAL, 14);
        box.margin_top = 18; box.margin_bottom = 18;
        box.margin_start = 18; box.margin_end = 18;
        box.append (entry);
        box.append (actions);
        dialog.set_child (box);

        ok.clicked.connect (() => {
            var txt = entry.text.strip ();
            dialog.destroy ();
            if (txt != "") cb (txt);
        });
        cancel.clicked.connect (() => dialog.destroy ());
        entry.activate.connect (() => ok.activate ());
        dialog.present ();
    }
}
